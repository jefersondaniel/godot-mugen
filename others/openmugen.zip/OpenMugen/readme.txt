OpenMugen PreAlpha Demo
-----------------------

This is the OpenMugen PreAlpha Demo.
It is the current compiled Win32 and linux bin 
and shows you the progress of OpenMUgen.

What is new?
-----------
Added sound to OpenMugen and supports MP3 mid and OGG files thanx to SDL_Mixer lib
Corrected some hitdef releated stuff
All physics are implemented (AIR,STAND AND CROUCHING)
Single step mode is implemented.First press pause and to perfrom a single step press scroll lock
Fixed Air file reading.
Fixed bug in linked Sff sprites.
Add Explod controller ( not complete )
Add GameMakeAnim controller
Add 2 Player input
Add engine states





Keys for this version are
-------------------------

Player1
-------
UP	= ARROWUP
DOWN	= ARROWDOWN
LEFT	= ARROWLEFT
RIGHT	= ARROWRIGHT
A	= NUM4	
B	= NUM5
C	= NUM6
X	= NUM7
Y	= NUM8
Z	= NUM9
Start	= Enter

Player2
-------
UP	= W
DOWN	= S
LEFT	= A
RIGHT	= D
A	= G	
B	= H
C	= J
X	= T
Y	= Z
Z	= U
Start	= space


Pause   = Pause key
Single step in pause = scroll lock ( link in M.U.G.E.N )

Or try your gamepad ;-)


Credits
-------------------------------------------
Sahin Vardar 	aka SakirSoft       main coder
Nate Pendelton	aka n8n8babay	    co-coder
Sahas 		aka ??		    snd, fnt coder
Filo 		aka Filosophie	    Web-desing
Tim		aka Marv	    Linux Porter CVS guy



visit us at 
http://openmugen.sourceforge.net/

