#!/bin/sh

rm /usr/bin/nomen
rm /usr/bin/nomen-tpar
rm /usr/share/nomen/docs/*
rmdir /usr/share/nomen/docs
rmdir /usr/share/nomen


