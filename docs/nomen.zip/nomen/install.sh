#!/bin/sh

chmod 755 ./build/usr/bin/*
cp ./build/usr/bin/* /usr/bin
mkdir /usr/share/nomen
mkdir /usr/share/nomen/docs
cp ./build/usr/share/nomen/docs/* /usr/share/nomen/docs

echo 
echo installation finished!
echo 

