#!/bin/sh

# you could need to change it
QMAKE=qmake

# making libpcx
cd libpcx
$QMAKE pcx.pro
make
cd ..

# making nomen-tpar
cd nomen-tpar
$QMAKE nomen-tpar.pro
make
cd ..

# making nomen
cd nomen
$QMAKE nomen.pro
make
cd ..

#create "build"
mkdir ./build
mkdir ./build/usr
mkdir ./build/usr/bin
mkdir ./build/usr/share
mkdir ./build/usr/share/nomen
mkdir ./build/usr/share/nomen/docs
cp ./nomen/build/bin/nomen ./build/usr/bin
cp ./nomen-tpar/build/bin/nomen-tpar ./build/usr/bin
cp ./docs/*.* ./build/usr/share/nomen/docs
cp ./nomen-tpar/docs/*.* ./build/usr/share/nomen/docs

# cleaning libpcx
rm ./libpcx/Makefile
rm ./libpcx/bin/*.*
rm ./libpcx/obj/*.*
rmdir ./libpcx/bin
rmdir ./libpcx/obj

# cleaning tricky parser
rm ./nomen-tpar/Makefile
rm ./nomen-tpar/qrc_qrc.cpp
rm ./nomen-tpar/build/bin/nomen-tpar
rmdir ./nomen-tpar/build/bin
rm ./nomen-tpar/build/moc/*.*
rmdir ./nomen-tpar/build/moc
rm ./nomen-tpar/build/obj/*.*
rmdir ./nomen-tpar/build/obj
rm ./nomen-tpar/build/ui/*.*
rmdir ./nomen-tpar/build/ui
rmdir ./nomen-tpar/build


# cleaning nomen
rm ./nomen/Makefile
rm ./nomen/qrc_nomen.cpp
rm ./nomen/build/bin/nomen
rmdir ./nomen/build/bin
rm ./nomen/build/moc/*.*
rmdir ./nomen/build/moc
rm ./nomen/build/obj/*.*
rmdir ./nomen/build/obj
rm ./nomen/build/ui/*.*
rmdir ./nomen/build/ui
rmdir ./nomen/build

