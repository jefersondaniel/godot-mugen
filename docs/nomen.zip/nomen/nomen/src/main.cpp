/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#include <QApplication>
#include <QtPlugin>
#include <QDir>
 
Q_IMPORT_PLUGIN(pcx)

#include "gvars.h"
#include "frmMain.h"
 
int main(int argc, char *argv[])
{	
	QApplication app(argc, argv);
	
    #ifdef Q_WS_WIN
      mainpath = QCoreApplication::applicationDirPath (); //under windows: mainpath = program folder
    #endif
    
    #ifdef Q_WS_X11
    {
       QDir qd;
       mainpath = QDir::homePath();
       mainpath.append("/.nomen"); //under linux: mainpath = $HOME/.nomen
       if(qd.exists(mainpath) == false) qd.mkpath(mainpath); //if not exist create it
    }  
    #endif
	
    /*
    QString locale = QLocale::system().name();
    QTranslator translator;
    translator.load(QString("wrfix_") + locale);
    app.installTranslator(&translator); 
    */
    
    frmMain frm_Main;
    { QString version("0.1.1 RC2 (beta)");
      //QString version("SVN 2011.07.20 (beta)");
      frm_Main.defineNomenVersion(version);
    }
    frm_Main.show();
    return app.exec();
}

