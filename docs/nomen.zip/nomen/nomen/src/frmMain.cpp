/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#include <QtGui> 
//#include <QtCore/QTranslator>
#include "gvars.h"
#include "frmMain.h"
#include "frmMain_dialogs.h"
//sff modules
#include "sff/SffWidget.h"
#include "sff/nomenSffFunctions.h"
#include "sff/SffHandler.h"


 
frmMain::frmMain()
{
    ui.setupUi(this);
    //signals/slots mechanism in action (menu items)
    //toolbar
    connect(ui.actionSaveAll, SIGNAL( triggered() ), this, SLOT( slotSaveAll() ) );
    connect(ui.actionCloseAll, SIGNAL( triggered() ),this, SLOT( slotCloseAll() ) );
    connect(ui.actionSffSection, SIGNAL( triggered() ),this, SLOT( slotSffSection() ) );
    //sff
    connect(ui.action_sffNew, SIGNAL( triggered() ), this, SLOT( slotNewSff() ) );
    connect(ui.action_sffLoad, SIGNAL( triggered() ), this, SLOT( slotLoadSff() ) );
    connect(ui.action_sffSave, SIGNAL( triggered() ), this, SLOT( slotSffSave() ) );
    connect(ui.action_sffSaveas, SIGNAL( triggered() ), this, SLOT( slotSffSaveAs() ) );
    connect(ui.action_sffDuplicates, SIGNAL( toggled(bool) ), this, SLOT( slotSffRemoveDuplicates(bool) ) );
    connect(ui.action_sffFormat, SIGNAL( triggered() ), this, SLOT( slotSffSelectFormat() ) );
    connect(ui.action_sffExtractAll, SIGNAL( triggered() ), this, SLOT( slotSffExtractAll() ) );
    connect(ui.action_sffExtractOne, SIGNAL( triggered() ), this, SLOT( slotSffExtractOne() ) );
    connect(ui.action_sffExtractPal, SIGNAL( triggered() ), this, SLOT( slotSffExtractPal() ) );
    //help
    connect(ui.action_About, SIGNAL( triggered() ), this, SLOT( About() ) );
    
     //signals/slots mechanism in action (others)
    //connect(ui.pushButton, SIGNAL( clicked() ), this, SLOT( slotLoadSff() ) ); //da modificare
}



void frmMain::defineNomenVersion(QString &version) {
  nomenVersion = version;
  QString tmp = QString("Nomen v. %1") .arg(version);
  this->setWindowTitle(tmp);
}



void frmMain::closeEvent(QCloseEvent * event) {
  //under development
  bool k = true;
  if(sff.isSaved == false) { //missing "OR" cases for def, air, cmd, cns, snd
    k = false;
    QMessageBox msgBox;
    msgBox.setIcon(QMessageBox::Warning);
    msgBox.setText(tr("If you close Nomen now any unsaved changes will be lost. Are you sure that you want to close Nomen now?"));
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    msgBox.setDefaultButton(QMessageBox::No);
    int ret = msgBox.exec();
    switch (ret) {
      case QMessageBox::Yes: k=true; break;
    }
  }
  
  if(k == true) event->accept();
  if(k == false) event->ignore();
}



void frmMain::About() {
  QMessageBox::about(this,"About Nomen",
                QString("N.O.M.E.N.\n"
                "Version  %1\n"
                "Copyright (C) Nobun  2010-2011\n\n"
                "http://mugenrebirth.forumfree.it\n\n"
                "http://nomeneditor.sourceforge.net\n\n\n"
                "A VERY SPECIAL THANK to serio for his very professional beta-testing and for his ideas that perhaps will be applied in a future\n\n"
                "A VERY SPECIAL THANK to Tunglashor for helping me a lot to understand better Sffv2 and contributing with observations when I reported my problems during sffv2 decoding process\n\n"
                "A VERY SPECIAL THANK also to www.qt-italia.org for answering my questions about qt\n\n"
                "------------------------\n\n"
                "This program is free software: you can redistribute it and/or modify\n"
                "it under the terms of the GNU General Public License as published by\n"
                "the Free Software Foundation, either version 3 of the License, or\n"
                "(at your option) any later version.\n\n"
                "This program is distributed in the hope that it will be useful,\n"
                "but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
                "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
                "GNU General Public License for more details.\n\n"
                "You should have received a copy of the GNU General Public License\n"
                "along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.\n" )
                 .arg(nomenVersion) );
}



/*********************************************************************************
 * Tool Bar Actions (Missing a lot of functions)
 *********************************************************************************/

 

//missing: newChar, newStage, loadChar (and stage)

 
void frmMain::slotSaveAll() {
  //under development. Sff Part Included only
  //saving Sff
  if(sff.isSaved == false) this->slotSffSave();
}



bool frmMain::slotCloseAll() {
  //under development. Sff Part Included only
  if(sff.isSaved == false) { //missing "OR" cases for def, air, cmd, cns, snd
    QMessageBox msgBox;
    msgBox.setIcon(QMessageBox::Warning);
    msgBox.setText(tr("If you continue any unsaved changes will be lost. Are you sure that you want to close all?"));
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    msgBox.setDefaultButton(QMessageBox::No);
    int ret = msgBox.exec();
    switch (ret) {
      case QMessageBox::Yes: break;
      default: return false;
    }
  }
  //mdiArea
  ui.mdiArea->closeAllSubWindows();
  
  //Sff
  sff.clear();
  ui.action_sffSave->setEnabled(false); ui.action_sffSaveas->setEnabled(false);
  ui.action_sffExtractAll->setEnabled(false); ui.action_sffExtractOne->setEnabled(false);
  ui.action_sffExtractPal->setEnabled(false);
  
  //toolbar
  ui.actionSaveAll->setEnabled(false); ui.actionCloseAll->setEnabled(false);
  ui.actionSffSection->setEnabled(false); //missing a lot of toolbar options
  
  return true;
}



//missing: refresh, def



void frmMain::slotSffSection() {
  //can be modifyed in future. I am not sure this can be a nice solution one time text editors will be added
  ui.mdiArea->closeAllSubWindows();
  SffWidget * sffwid = new SffWidget(this, &sff);
  if(sff.sffdata.size() > 0) {
	sffwid->ui.imgscroll->setRange(1, sff.sffdata.size());
	sffwid->ui.imgscroll->setValue(1);
  }
  if(sff.sffdata.size() == 0) {
	sffwid->ui.imgscroll->setRange(0, 0);
    sffwid->ui.imgscroll->setValue(0);	  
  }
  sffwid->setAttribute(Qt::WA_DeleteOnClose);
  ui.mdiArea->addSubWindow(sffwid);
  sffwid->setWindowState(Qt::WindowMaximized);
  sffwid->show();
}



//missing: air, cmd, cns, snd



/*********************************************************************************
 * Menu Sff
 *********************************************************************************/
 
 
 
void frmMain::slotNewSff() {
  bool k = true;
  if(sff.isSaved == false) { //missing "OR" cases for def, air, cmd, cns, snd
    k = false;
    QMessageBox msgBox;
    msgBox.setIcon(QMessageBox::Warning);
    msgBox.setText(tr("If create now a new sff any unsaved changes in the actual sff will be lost. Are you sure that you want to discard all changes and create a new sff?"));
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    msgBox.setDefaultButton(QMessageBox::No);
    int ret = msgBox.exec();
    switch (ret) {
      case QMessageBox::Yes: k=true; break;
    }
  }
  if(k == true) {
    sff.clear();
    //Enable "Save / Extract" Menu Items
    ui.action_sffSave->setEnabled(true); ui.action_sffSaveas->setEnabled(true);
    //ExtractAll, ExtractOne, ExtractPalette will not enabled in case of new sff until it will not be saved
    //Enable Toolbar Items for sff only
    ui.actionSaveAll->setEnabled(true); ui.actionCloseAll->setEnabled(true);
    ui.actionSffSection->setEnabled(true);
    //Open Sff Editor
    this->slotSffSection();
  }
}



void frmMain::slotLoadSff() {
  bool k = true;
  if(sff.isSaved == false) {
    k = false;
    QMessageBox msgBox;
    msgBox.setIcon(QMessageBox::Warning);
    msgBox.setText(tr("If load now a sff any unsaved changes in the actual sff will be lost. Are you sure that you want to discard all changes and open another sff?"));
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    msgBox.setDefaultButton(QMessageBox::No);
    int ret = msgBox.exec();
    switch (ret) {
      case QMessageBox::Yes: k=true; break;
    }
  }
  if(k == true) {
    QString filename;  
    filename = QFileDialog::getOpenFileName(this, tr("Open a Sff File"), QString::null, QString("(*.sff *.sffv1 *.sffv2 *.nomspr)"));
    if(filename != "") {
      bool sffLoaded = sff.loadSff(filename);
      if(sffLoaded == true) {
	    sff.filename = filename;
	    //Enable "Save / Extract" Menu Items
	    ui.action_sffSave->setEnabled(true); ui.action_sffSaveas->setEnabled(true);
	    ui.action_sffExtractAll->setEnabled(true); ui.action_sffExtractOne->setEnabled(true);
	    ui.action_sffExtractPal->setEnabled(true);
	    //Enable Toolbar Items for sff only
	    ui.actionSaveAll->setEnabled(true); ui.actionCloseAll->setEnabled(true);
	    ui.actionSffSection->setEnabled(true);
	    //Open Sff Editor
	    SffWidget * sffwid = new SffWidget(this, &sff);
	    sffwid->ui.imgscroll->setRange(1, sff.sffdata.size() );
	    {
		  QString str = QString("1 / %1") .arg( sff.sffdata.size() );
	      sffwid->ui.le_scroll->setText(str);
        }
        sffwid->ui.imgscroll->setValue(1);
        sffwid->setAttribute(Qt::WA_DeleteOnClose);
        ui.mdiArea->addSubWindow(sffwid);
        sffwid->setWindowState(Qt::WindowMaximized);
        sffwid->show();
      } //end if sffLoaded == true
    } //end if filename != ""
  }//end book k
}	



void frmMain::slotSffSave() {
  if(sff.filename=="") this->slotSffSaveAs();	
  else sff.saveSff(sff.filename, sff.format);
}



void frmMain::slotSffSaveAs() {
  QString filename = QFileDialog::getSaveFileName(this, tr("Save As..."), QString::null, tr("Sff Files (*.sff);;(*.nomspr)") );
  if(filename != "") {
    bool k = sff.saveSff(filename, sff.format);
    if(k == true) { 
	  ui.action_sffExtractAll->setEnabled(true); 
	  ui.action_sffExtractOne->setEnabled(true); 
	  ui.action_sffExtractPal->setEnabled(true); 
	  if(sff.filename == "") sff.filename = filename;
    }
  } //end filename != ""
}



void frmMain::slotSffRemoveDuplicates (bool checked) {
  sff.removeDuplicates = checked;
}



void frmMain::slotSffSelectFormat() {
  int val = (int) (sff.format -1);
  dlgSffChooseFormat * dcf = new dlgSffChooseFormat(this, val);
  dcf->setAttribute(Qt::WA_DeleteOnClose);
  dcf->show();
}



void frmMain::slotSffExtractAll() {
  dlgSffExtract * dse = new dlgSffExtract(this, -555); //-555 is reserved number for All Images
  dse->setAttribute(Qt::WA_DeleteOnClose);
  dse->show();
}



void frmMain::slotSffExtractOne() {
  dlgSffExtract * dse = new dlgSffExtract(this, sff.actualImage); //mark image to extract. If -1 is invalid
  dse->setAttribute(Qt::WA_DeleteOnClose);
  dse->disablePal();
  dse->show();
}



void frmMain::slotSffExtractPal() {
  dlgSffExtract * dse = new dlgSffExtract(this, -333); //-333 is reserved number for Palettes Only
  dse->setAttribute(Qt::WA_DeleteOnClose);
  dse->disableImg();
  dse->show();
}



void frmMain::SffExtract(int what, const QString & imageFormat, const QString & palFormat, QString & resultPath) {
  //this function is called by the child dlgSffExtract  

  //case 1: Single (valid) image
  if(what != -555 && what != -333 && what >=0) { 
  	      //-555 is reserved number for "All Images". 
  	      //-333 is reserved numver for "Palettes Only"
  	      //Any value >=0 it will extract only one image (what = image index)
    //calculating filename....
    QString file_name;
    //if resultPath not assigned calculated it
    if(resultPath == "") {
      resultPath = mainpath;
      resultPath.append("/snap/");
      { QFileInfo inf(sff.filename);
        QString qstr = inf.baseName();
	    resultPath.append(qstr); //the base sff filename is added (result example for "kfm.sff" -> .../snap/kfm/...
      }
      { QDir qdir;
        if(qdir.exists(resultPath) == false) qdir.mkpath(resultPath);
      }
    }
    //calculate filename...
    file_name = resultPath; file_name.append("/");
    if(sff.sffdata[what].groupno < 1000) file_name.append("0");
    if(sff.sffdata[what].groupno < 100) file_name.append("0");
    if(sff.sffdata[what].groupno < 10) file_name.append("0");
    {
	  QString t = QString("%1") .arg(sff.sffdata[what].groupno);
	  file_name.append(t);    
    }
    file_name.append("-");
    if(sff.sffdata[what].imageno < 10) file_name.append("0");
    {
	  QString t = QString("%1") .arg(sff.sffdata[what].imageno);
	  file_name.append(t);    
    }
    file_name.append("."); file_name.append(imageFormat);
    //filename calculated.
    //saving image...
    sff.sffdata[what].image.save(file_name);    
  }
  
  //Case 2: Extract Palettes
  if(what == -333) {
    //if resultPath not assigned calculated it
    if(resultPath == "") {
      resultPath = mainpath;
      resultPath.append("/snap/");
      { QFileInfo inf(sff.filename);
        QString qstr = inf.baseName();
	    resultPath.append(qstr); //the base sff filename is added (result example for "kfm.sff" -> .../snap/kfm/...
      }
      { QDir qdir;
        if(qdir.exists(resultPath) == false) qdir.mkpath(resultPath);
      }
    }
     
	//now extracting pals  
    for(int a = 0; a < sff.paldata.size(); a++) {
	   //calculating filename
	   QString file_name = resultPath;
       file_name.append("/");
       if(sff.paldata[a].groupno < 1000) file_name.append("0");
       if(sff.paldata[a].groupno < 100) file_name.append("0");
       if(sff.paldata[a].groupno < 10) file_name.append("0");
       {
	     QString t = QString("%1") .arg(sff.paldata[a].groupno);
	     file_name.append(t);    
       }
       file_name.append("-");
       if(sff.paldata[a].itemno < 10) file_name.append("0");
       {
	     QString t = QString("%1") .arg(sff.paldata[a].itemno);
	     file_name.append(t);    
       }
       //file name calculated.
       //extracting Pal: case 1 - Both pal and act
       if(palFormat.compare("PalAct") == 0) {
	     QString t = file_name;
	     t.append(".pal");
	     nomenSavePal_pal(t, sff.paldata[a].pal);
	     t = file_name;
	     t.append(".act");
	     nomenSavePal_act(t, sff.paldata[a].pal);    
       }
       //extracting Pal: case 2 - Pal
       if(palFormat.compare("pal") == 0) {
	     QString t = file_name;
	     t.append(".pal");
	     nomenSavePal_pal(t, sff.paldata[a].pal);   
       }
       //extracting Pal: case 3 - Act
       if(palFormat.compare("act") == 0) {
	     QString t = file_name;
	     t.append(".act");
	     nomenSavePal_act(t, sff.paldata[a].pal);   
       }  
     }
  }
  
  //Case 3: ALL IMAGES AND PALS
  if(what == -555) {
	 resultPath = mainpath;
	 { 
       resultPath.append("/snap/");   
       { QFileInfo inf(sff.filename);
         QString qstr = inf.baseName();
	     resultPath.append(qstr); //the base sff filename is added (result example for "kfm.sff" -> .../snap/kfm/...
       }
       { QDir qdir;
         if(qdir.exists(resultPath) == false) qdir.mkpath(resultPath);
       }
       /*QDir td (resultPath);
       QFileInfoList flist = td.entryInfoList();
       for(int a = 0; a <flist.size(); a++) {
	     td.remove(flist[a].fileName());    
       }*/
     }
     
     //extracting texts...
     exec_sff_plugin_wText(resultPath, imageFormat, palFormat, sff.sffdata, sff.paldata);
     
     //extracting pals...
     this->SffExtract(-333, imageFormat, palFormat, resultPath); // -333 is the marker for palettes only
     
     //extracting images... 
     for(int a = 0; a < sff.sffdata.count(); a++) this->SffExtract(a, imageFormat, palFormat, resultPath);
     
  }
  
  //If what < 0 && what != 555 -> invalid image => does nothing
  
} //end SffExtract

