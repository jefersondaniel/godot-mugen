/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#ifndef FRMMAIN_H
#define FRMMAIN_H
 
#include "ui_frmMain.h"
#include "sff/Sff.h"
 
//! The class that contains the code for Nomen main window
/*!
    It is full of (undocumented) slots
*/
class frmMain : public QMainWindow
{
    Q_OBJECT
    
protected:
    //! This function will allert you if you are closing Nomen with unsaved changes
    void closeEvent(QCloseEvent * event);
    
private:
    //! This variable is setted in main.cpp. It will define Nomen Version 
    /*!
        example: 

        QString version("0.1  (beta)");
        frm_Main.defineNomenVersion(version);
    */
    QString nomenVersion;
 
public:
    Ui::frmMainDLG ui;
    frmMain();
    
public:
    //! "sff" is the variable that contains the sff datas (sprites and palettes).
    Sff sff;
    
public:
    //Sff
    void SffExtract(int what, const QString & imageFormat, const QString & palFormat, QString & resultPath);
    //! This function allows you to set variable nomenVersion.
    /*!
        example:

        QString version("0.1  (beta)");
        frm_Main.defineNomenVersion(version);
    */
    void defineNomenVersion(QString &version);
    
private slots:
    //Toolbar
    void slotSaveAll();
    bool slotCloseAll();
    void slotSffSection();
    //Sff
    void slotNewSff();
    void slotLoadSff();
    void slotSffSave();
    void slotSffSaveAs();
    void slotSffRemoveDuplicates(bool checked);
    void slotSffSelectFormat();
    void slotSffExtractAll();
    void slotSffExtractOne();
    void slotSffExtractPal();
    //help
    void About();
};
 
 
#endif

