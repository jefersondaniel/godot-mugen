/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/
 
#include "dlgSffExtract.h"


dlgSffExtract::dlgSffExtract(frmMain * _parent, int _val) : QDialog(_parent) {
  parent = _parent;
  val = _val;
  this->resize(259,210);
  this->setWindowTitle(tr("Extract Options"));
  grp1 = new QGroupBox(this);	
  grp1->setGeometry(QRect(10,10,231,61));
  grp1->setTitle(tr("Save Images As..."));
  pcx = new QRadioButton(grp1);
  pcx->setGeometry(QRect(20,30,51,17));
  pcx->setText("PCX");
  png = new QRadioButton(grp1);
  png->setGeometry(QRect(90,30,51,17));
  png->setText("PNG");
  png->setChecked(true);
  bmp = new QRadioButton(grp1);
  bmp->setGeometry(QRect(160,30,51,17));
  bmp->setText("BMP");
  
  grp2 = new QGroupBox(this);
  grp2->setGeometry(QRect(10,90,231,61));
  grp2->setTitle(tr("Save Palettes As..."));
  palact = new QRadioButton(grp2);
  palact->setGeometry(QRect(20,30,91,17));
  palact->setText("PAL and ACT");
  palact->setChecked(true);
  pal = new QRadioButton(grp2);
  pal->setGeometry(QRect(120,30,51,17));
  pal->setText("PAL");
  act = new QRadioButton(grp2);
  act->setGeometry(QRect(180,30,51,17));
  act->setText("ACT");
  
  btnCancel = new QPushButton(this);
  btnCancel->setGeometry(QRect(90,170,75,23));
  btnCancel->setText(tr("&Cancel"));
  btnOk = new QPushButton(this);
  btnOk->setGeometry(QRect(170,170,75,23));
  btnOk->setText(tr("&Ok"));
  
  connect(btnCancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
  connect(btnOk, SIGNAL( clicked() ), this, SLOT( slotOk() ) );
}


void dlgSffExtract::disablePal() {
  this->grp2->setEnabled(false);
  this->palact->setVisible(false);
  this->pal->setVisible(false);
  this->act->setVisible(false);	
}


void dlgSffExtract::disableImg() {
  this->grp1->setEnabled(false);
  this->pcx->setVisible(false);
  this->png->setVisible(false);
  this->bmp->setVisible(false);
}


void dlgSffExtract::slotOk() {
  QString t1, t2, t3;
  if(pcx->isChecked()==true) t1 = "pcx";
  if(png->isChecked()==true) t1 = "png";
  if(bmp->isChecked()==true) t1 = "bmp";
  if(palact->isChecked() ==true) t2 = "PalAct";
  if(pal->isChecked()==true) t2 = "pal";
  if(act->isChecked()==true) t2 = "act";
  t3.clear();
  parent->SffExtract(val, t1, t2, t3);
  this->accept();
}

