/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/
 
#include "dlgSffChooseFormat.h"


dlgSffChooseFormat::dlgSffChooseFormat(frmMain * _parent, int val) : QDialog(_parent) {
  parent = _parent;
  this->resize(310,194);
  this->setWindowTitle(tr("Choose Sff Output Format"));
  
  box = new QComboBox(this);
  box->setGeometry(QRect(20,10,271,22));
  this->defineList();
  box->setCurrentIndex(val);
  
  btnCancel = new QPushButton(this);
  btnCancel->setGeometry(QRect(120,160,75,23));
  btnCancel->setText(tr("&Cancel"));
  btnOk = new QPushButton(this);
  btnOk->setGeometry(QRect(210,160,75,23));
  btnOk->setText(tr("&Ok"));
  
  connect(btnCancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
  connect(btnOk, SIGNAL( clicked() ), this, SLOT( slotOk() ) );
}


void dlgSffChooseFormat::defineList() {
  #ifdef ADD_SFF_PLUGIN
  #undef ADD_SFF_PLUGIN
  #endif
  
  #define ADD_SFF_PLUGIN(SFF_PLUGIN_CLASS, SFF_PLUGIN_DESCRIPTION) box->addItem(tr(SFF_PLUGIN_DESCRIPTION));
      
  #include "../../sff/SffPluginsList.h"    
  #undef ADD_SFF_PLUGIN
}


void dlgSffChooseFormat::slotOk() {
  parent->sff.format = (char) (box->currentIndex() +1);
  this->accept();	
}

