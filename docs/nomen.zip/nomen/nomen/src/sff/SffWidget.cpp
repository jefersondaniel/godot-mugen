/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#include <QtGui>
//#include <QtCore/QTranslator>
//#include "frmMain.h"
#include "SffWidget.h"
#include "dialogs/dlgSearchImage.h"
#include "dialogs/dlgAddImage.h"
#include "dialogs/dlgPaletteSection.h"
#include "dialogs/DlgCurrentSpriteChangePal.h"


SffWidget::SffWidget(QWidget * parent, Sff * _sff) : QWidget(parent)
{
    ui.setupUi(this);
    actualSffItem = new SffItem;
    zoomfactor = 0;
    sff = _sff;
    
	sffScene = new QGraphicsScene;    
    sffScene->setSceneRect(-800,-600,1600,1200);
    {
	  QGraphicsPixmapItem * item = new QGraphicsPixmapItem;
	  item->setPixmap(QPixmap(":/assi.png"));
	  item->setPos(-10,-10);
	  item->setZValue(100);
	  //item->setFlag(QGraphicsItem::ItemIsMovable, true);
	  sffScene->addItem(item);
    }
    ui.sffView->setScene(sffScene);
    sffScene->setBackgroundBrush(QBrush(Qt::black));
    sffScene->addItem(actualSffItem);
    
    //signals/slots mechanism in action (menu items)
    //connect(ui.actionAbout, SIGNAL( triggered() ), this, SLOT( About1() ) );
    
    connect(sffScene, SIGNAL( changed (const QList<QRectF> &) ), this, SLOT( sffSceneChanged(const QList<QRectF> &) ) );
    connect(ui.spinSffX, SIGNAL( valueChanged(int) ), this, SLOT(  slotUpdateX(int) ) );
    connect(ui.spinSffY, SIGNAL( valueChanged(int) ), this, SLOT(  slotUpdateY(int) ) );
    connect(ui.spinSffGroup, SIGNAL( valueChanged(int) ), this, SLOT( slotUpdateGroupno(int) ) );
    connect(ui.spinSffImage, SIGNAL( valueChanged(int) ), this, SLOT( slotUpdateImageno(int) ) );
    
    connect(ui.btnZoomIn, SIGNAL( clicked() ), this, SLOT( slotZoomIn() ) );
    connect(ui.btnZoom1, SIGNAL( clicked() ), this, SLOT( slotZoom1() ) );
    connect(ui.btnZoomOut, SIGNAL( clicked() ), this, SLOT( slotZoomOut() ) );
    connect(ui.bgsList, SIGNAL( currentIndexChanged (int) ), this, SLOT( slotBg(int) ) );
    
    connect(ui.imgscroll, SIGNAL( valueChanged(int) ), this, SLOT( slotScrollImage(int) ) );
    connect(ui.btnAddFrame, SIGNAL( clicked() ), this, SLOT( slotAddFrame() ) );
    connect(ui.btnRemoveFrame, SIGNAL( clicked() ), this, SLOT( slotRemoveFrame() ) );
    connect(ui.btnSearchFrame, SIGNAL( clicked() ), this, SLOT( slotSearchImage() ) );
    connect(ui.btnCurrentSpriteChangePal, SIGNAL( clicked() ), this, SLOT ( slotCurrentSpriteChangePal() ) );
    
    connect(ui.btnPalSection, SIGNAL( clicked() ), this, SLOT( slotPalSection() ) );
}

 
SffWidget::~SffWidget() {
  actualSffItem->setNull();
  delete sffScene;
}


void SffWidget::refreshScene() {
  if(actualSffItem->sffdata != NULL) actualSffItem->setVal( actualSffItem->sffdata );
  else actualSffItem->setNull();
}


void SffWidget::sffSceneChanged(const QList<QRectF> & region) {
  if(actualSffItem!=NULL) {
    ui.spinSffX->setValue(actualSffItem->intX());
    ui.spinSffY->setValue(actualSffItem->intY());
  }
}


void SffWidget::slotUpdateX(int value) {
  if(actualSffItem!=NULL) {
	 actualSffItem->setIntX(value);	
	 if(actualSffItem->sffdata != NULL) actualSffItem->sffdata->x = value;
  }
}


void SffWidget::slotUpdateY(int value) {
  if(actualSffItem!=NULL) {
	actualSffItem->setIntY(value);
	if(actualSffItem->sffdata != NULL) actualSffItem->sffdata->y = value;
  }
}


void SffWidget::slotUpdateGroupno(int value) {
  if(actualSffItem!=NULL) {
	actualSffItem->groupno = value;	
	if(actualSffItem->sffdata != NULL) actualSffItem->sffdata->groupno = value;
  }
}


void SffWidget::slotUpdateImageno(int value) {
  if(actualSffItem!=NULL) {
	actualSffItem->imageno = value;
	if(actualSffItem->sffdata != NULL) actualSffItem->sffdata->imageno = value;	
  }
}


void SffWidget::slotZoomIn() {
  ui.btnZoomOut->setEnabled(true);
  zoomfactor ++;
  if(zoomfactor >= 4) ui.btnZoomIn->setEnabled(false);
  ui.sffView->scale(2, 2);
}


void SffWidget::slotZoom1() {
  ui.btnZoomIn->setEnabled(true);
  ui.btnZoomOut->setEnabled(true);
  while(zoomfactor < 0) {
    zoomfactor++;ui.sffView->scale(2,2);
  }
  while(zoomfactor > 0) {
	zoomfactor--;ui.sffView->scale(0.5,0.5);
  }
}


void SffWidget::slotZoomOut() {
  ui.btnZoomIn->setEnabled(true);
  zoomfactor --;
  if(zoomfactor <= -2) ui.btnZoomOut->setEnabled(false);
  ui.sffView->scale(0.5, 0.5);
}


void SffWidget::slotBg(int value) {
  switch(value) {
    case 0: sffScene->setBackgroundBrush(QBrush(Qt::black)); break;
    case 1: sffScene->setBackgroundBrush(QBrush(Qt::white)); break;
    case 2: sffScene->setBackgroundBrush(QBrush(Qt::magenta)); break;
    case 3: sffScene->setBackgroundBrush(QBrush(Qt::cyan)); break;
    case 4: sffScene->setBackgroundBrush(QBrush(Qt::darkCyan)); break;
    case 5: sffScene->setBackgroundBrush(QBrush(Qt::darkYellow)); break;
    default: sffScene->setBackgroundBrush(QBrush(Qt::black));
  }	
}


void SffWidget::slotScrollImage(int value) {
  sff->actualImage = value -1; //updates sff->actualImage (used by frmMain to extract a single image)
  if(value > 0) { //don't execute if no images: (value == 0 means empty sff)
    actualSffItem->setVal( sff->item(value-1) ); 
    ui.spinSffGroup->setValue(actualSffItem->sffdata->groupno);
    ui.spinSffImage->setValue(actualSffItem->sffdata->imageno);
    ui.spinSffX->setValue(actualSffItem->sffdata->x);
    ui.spinSffY->setValue(actualSffItem->sffdata->y);
    int k = actualSffItem->sffdata->palindex;
    QString tmp = QString("%1, %2") .arg(sff->paldata[k].groupno) .arg(sff->paldata[k].itemno);
    ui.lePalno->setText(tmp);
  }
  if(value == 0) { //if value==0 (emtpy sff -> no frames) than set all values to 0
    actualSffItem->setNull();
    ui.spinSffGroup->setValue(0);
    ui.spinSffImage->setValue(0);
    ui.spinSffX->setValue(0);
    ui.spinSffY->setValue(0);
    ui.lePalno->setText("");
  }
  
  //set ui.le_scroll
  { 
	QString str = QString("%1 / %2") .arg(value) .arg( sff->sffdata.size() );
	ui.le_scroll->setText(str);
  }
}


void SffWidget::slotAddFrame() {
  QStringList filelist;
  filelist = QFileDialog::getOpenFileNames(this, tr("Step 1: Select one or more images"),
                "", tr("Images (*.png *.pcx *.bmp)") );
  if(filelist.count() > 0) {
    dlgAddImage * aim = new dlgAddImage(this, filelist, ui.imgscroll->value());
    aim->setAttribute(Qt::WA_DeleteOnClose);
    aim->show();
  }
}


void SffWidget::slotRemoveFrame() {
  QMessageBox msgBox;
  msgBox.setIcon(QMessageBox::Question);
  msgBox.setText(tr("Are you sure you want to remove current image?"));
  msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
  msgBox.setDefaultButton(QMessageBox::No);
  int ret = msgBox.exec();
  switch (ret) {
   case QMessageBox::Yes: {  //if "yes" is selected than remove image
     sff->isSaved=false;
     if(ui.imgscroll->value() == ui.imgscroll->maximum()) { //if the actual item is the last in list, than the imgscroll.value will be decreased by 1
	   if(ui.imgscroll->value() == 1) {
		 //if the actual item is also the first one (and so it is the only one) than we need to allow value 0 to imgscroll before removing image 
		 ui.imgscroll->setMinimum(0); actualSffItem->setNull();
       }
       actualSffItem->setNull(); sff->sffdata.removeAt( ui.imgscroll->value() -1);
       sff->resyncPaletteAfterRemoveItem(ui.imgscroll->value() -1);
       ui.imgscroll->setMaximum(ui.imgscroll->maximum() -1);
     }
     else { //if, instead, the actual item is NOT the last one
	   ui.imgscroll->setValue(ui.imgscroll->value() +1); //move cursor 1 element next
       sff->sffdata.removeAt( ui.imgscroll->value() -2);
	   sff->resyncPaletteAfterRemoveItem(ui.imgscroll->value() -2);
       if(ui.imgscroll->maximum() > ui.imgscroll->value()) { //if after moving cursor 1 element next LAST ELEMENT NOT reached
	     ui.imgscroll->setMaximum(ui.imgscroll->maximum() -1);
	     ui.imgscroll->setValue(ui.imgscroll->value() -1);
       }
       else { //after moving cursor 1 element actual item was last. Changing maximum will change value
	     ui.imgscroll->setMaximum(ui.imgscroll->maximum() -1);  
       }
     }
     
     break; 
   } //end case "yes"   
 } //end switch
 //todo
 
}


void SffWidget::slotSearchImage() {
  dlgSearchImage * sim = new dlgSearchImage(this);
  sim->setAttribute(Qt::WA_DeleteOnClose);
  sim->show();
}


void SffWidget::slotPalSection() {
  DlgPalSection * psec = new DlgPalSection(this, sff);
  psec->setAttribute(Qt::WA_DeleteOnClose);
  psec->show();
}


void SffWidget::slotCurrentSpriteChangePal() {
  if(actualSffItem->sffdata != NULL) {
	int id = actualSffItem->sffdata->palindex;
    DlgCurrentSpriteChangePal * scp = new DlgCurrentSpriteChangePal(this, id);
    scp->setAttribute(Qt::WA_DeleteOnClose);
    scp->exec();
  }
  else { QMessageBox::warning(this, tr("Warning:"), tr("There is NO image here. You cannot edit palette of non-existing image!") ); }
}

