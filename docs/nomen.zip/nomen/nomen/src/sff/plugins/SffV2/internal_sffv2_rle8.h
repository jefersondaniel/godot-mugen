/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/
 
// SFFv2 INTERNAL ONLY. DON'T USE THIS HEADER OUTSIDE sffv2

//rle8 in sffv2 is different than normal rle8. Infact we must use an
// if((ch & 0xc0) == 0x40) instead of an if((ch & 0xc0) == 0xc0)

void _sffv2_rle8Decode( QByteArray &src )
{
  QDataStream in(src);
  QByteArray dest;
  quint8 ch, color;
  {quint32 i; in>>i; } //undocumented: first 4 bytes = len of image
  
  while(!in.atEnd()) {
    in>>ch;
    if((ch & 0xc0) == 0x40) { //=0x40
	  in>>color;
	  for(quint8 a=0; a< ((ch & 0x3f)); a++) { dest.append(color); }  
    }	  
    if((ch & 0xc0) != 0x40) { dest.append(ch); }
  }
  src = dest;  
}


void _sffv2_rle8Encode( QByteArray &src )
{
  //idea suggested by KdeLibs pcx.cpp
  QByteArray dest;
  QBuffer destbuffer(&dest);
  destbuffer.open(QIODevice::WriteOnly);
  QDataStream out(&destbuffer);
  
  {
    long dim = src.size();
    out.writeRawData((char *) &dim, 4);
  }
  
  quint32 i = 0;
  quint32 size = src.size();
  quint8 count, data;
  char byte;

  while ( i < size )
  {
    count = 1;
    byte = src[ i++ ];

    while ( ( i < size ) && ( byte == src[ i ] ) && ( count < 63 ) )
    {
      ++i;
      ++count;
    }

    data = byte;

    if ( count > 1 || (data & 0xc0) == 0x40 )
    {
      count |= 0x40;
      out << count;
    }

    out << data;
  }
  
  src = dest;
} //end rle8Encode

