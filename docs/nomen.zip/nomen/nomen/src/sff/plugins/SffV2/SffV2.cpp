/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#include "../../SffHandler.h"
#include "../../SffItem.h"
#include "SffV2.h"
//Qt included: QString, QList, QGraphicsPixmapItem

#include <QByteArray>
#include <QDataStream>
#include <QFile>
#include <QImage>
//...

#include <QBuffer>
#include <QByteArrayMatcher>
#include <QProgressDialog>
#include <QPushButton>
#include <QMessageBox>
#include <QTextStream>
#include "internal_sffv2_structs.h"
#include "internal_sffv2_rle5-lz5_decode.h"
#include "internal_sffv2_rle8.h"
#include "internal_sffv2_matrix-image.h"
#include "internal_sffv2_matrix-pal.h"
#include "internal_sffv2_lz5_encode.h"
#include "internal_sffv2_wText_calc.h"

#include <string>


void SffV2::wText(QString & snapdest, const QString & imgf, const QString & palf, QList<SffData> & _sffdata, QList<SffPal> & _paldata) { 
  if((imgf == "pcx" || imgf == "png") && (palf == "PalAct" || palf == "act") ) {
    QString filename = snapdest; filename.append("/SffV2.txt");
    QFile txtfile(filename);
    txtfile.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&txtfile);
    out<<";Created with Nomen - Remember to rename \"SffV2.sff\" with the name you prefer\n\n";
    out<<"[Output]\nfilename = SffV2.sff\n\n";
    out<<"[Option]\n";
    out<<"sprite.compress.5 = lz5\n";
    out<<"sprite.compress.8 = rle8\n";
    out<<"sprite.compress.24 = none\n";
    out<<"sprite.decompressonload = 0\n";
    out<<"sprite.detectduplicates = 0\n";
    out<<"sprite.autocrop = 1\n";
    out<<"pal.detectduplicates = 1\n";
    out<<"pal.discardduplicates = 1\n";
    out<<"pal.reverseact = 0\n";
    out<<"pal.reversepng = 0\n\n";
    out<<"[Pal]\n";
    int last_palindex = -1;
    for(int a = 0; a < _paldata.size(); a++) {
	  const QString ActFmt = QString("act");
	  QString fname = _sffv2_wText_file_calc(_paldata[a].groupno, _paldata[a].itemno, ActFmt);
	  //setting len_of_pal (the last 2 parameters for pal -> 0,255 if 255 colors; 0,y if colors <=32)
	  QString len_of_pal;
	  if(_paldata[a].pal.size() > 32) len_of_pal = "0,255";
	  else len_of_pal = QString("0,%1") .arg(_paldata[a].pal.size() -1); 
	  
	  QString value = QString ("%1,%2, %3, %4\n") .arg(_paldata[a].groupno) .arg(_paldata[a].itemno) .arg(fname) .arg(len_of_pal);  
	  out<<value;
    }
    
    for(int a = 0; a < _sffdata.size(); a++) {
	  QString val;
	  if(_sffdata[a].palindex != last_palindex) {
	    last_palindex = _sffdata[a].palindex;
	    out<<"\n[Option]\n";
	    //sprite.usepal = ?
	    if (last_palindex > -1) val = QString("sprite.usepal = %1,%2") .arg(_paldata[last_palindex].groupno) .arg(_paldata[last_palindex].itemno);
	    else val = QString("sprite.usepal = -1");
	    out<<val<<"\n";
	    //sprite.removecolors = ?
	    if(last_palindex > -1) {
		  if(_paldata[last_palindex].pal.size() > 32) val = QString("sprite.removecolors = -1");
		  else val = QString("sprite.removecolors = %1,255") .arg(_paldata[last_palindex].pal.size());
	    }
	    else val = QString("sprite.removecolors = -1");
	    out<<val<<"\n\n[Sprite]\n"; 
      }
      
      QString fname = _sffv2_wText_file_calc(_sffdata[a].groupno, _sffdata[a].imageno, imgf);
      
      val = QString("%1,%2, %3, %4,%5\n") .arg(_sffdata[a].groupno) .arg(_sffdata[a].imageno)
                                          .arg(fname) .arg(_sffdata[a].x) .arg(_sffdata[a].y);
      out<<val;
    }
    
    txtfile.close();   
  } //end if PAL = (act || PalAct) && IMG = (png || pcx)
  
  
  else { //unsupported formats for sprmaker so don't create txt
    Q_UNUSED(snapdest); Q_UNUSED(imgf); Q_UNUSED(palf);	Q_UNUSED(_sffdata); Q_UNUSED(_paldata);
  }	
}









bool SffV2::read(QString & filename) {
  _SFFV2_SFF_HEADER head;
  QList<_SFFV2_SPRITE_NODE_HEADER> sprnode;
  QList<_SFFV2_PAL_NODE_HEADER> palnode;
  
  QFile sffFile(filename);
  if(!sffFile.open(QIODevice::ReadOnly)) return false;
  QDataStream in(&sffFile);
  in.setByteOrder(QDataStream::LittleEndian);
  in>>head;
    if(strcmp(&head.signature[0], "ElecbyteSpr")!=0) return false;
    if(head.verhi!=2) return false;
  
  //reading palnodes
  in.device()->seek((qint64) head.first_palnode_offset);
  for(long a=0; a<head.total_palettes; a++) {
    _SFFV2_PAL_NODE_HEADER tmp_palnode;
    in>>tmp_palnode; palnode.append(tmp_palnode);	  
  }
  //reading sprnodes
  in.device()->seek((qint64) head.first_sprnode_offset);
  for(long a=0; a<head.total_frames; a++) {
    _SFFV2_SPRITE_NODE_HEADER tmp_sprnode;
    in>>tmp_sprnode; sprnode.append(tmp_sprnode);    	  
  }
  
  //reading pals
  for(int a = 0; a < palnode.size(); a++) {
     SffPal sffpal; 
     sffpal.groupno = (int) palnode[a].groupno;
     sffpal.itemno = (int) palnode[a].itemno;
     if(palnode[a].len == 0) { //linked pal
	   sffpal.pal.clear(); sffpal.pal += paldata[palnode[a].linked].pal;
     }
     if(palnode[a].len > 0) { //"normal" pal
	   sffpal.pal.clear();
	   qint64 offset = (qint64) head.ldata_offset;
	   offset += (quint64) palnode[a].offset;
	   in.device()->seek(offset);
	   
	   int k = (int) palnode[a].numcols;
	   k = k * 4;
	   char * tmpStr = new char[k];
	   in.readRawData(tmpStr, k);
	   QByteArray tmpArr; tmpArr.append(tmpStr, k);
	   k = k / 4;
	   sffpal.pal += _sffv2_matrixToPal(tmpArr, k); 
	   delete [] tmpStr;
	   tmpArr.clear();
     }
     paldata.append(sffpal); 
  }
    
  //reading images
  for(int a = 0; a < sprnode.size(); a++) {
	SffData sffitem;
    sffitem.groupno = (int) sprnode[a].groupno;
    sffitem.imageno = (int) sprnode[a].imageno;
    sffitem.x = (int) sprnode[a].x;
    sffitem.y =(int) sprnode[a].y;
    sffitem.palindex = (int) sprnode[a].palindex;
    if(sprnode[a].len == 0) { //linked image
	  sffitem.linked = -1;
	  sffitem.image = sffdata[sprnode[a].linked].image;    
    }
    if(sprnode[a].len != 0) { //"normal" image
	   qint64 offset = 0;
	   if(sprnode[a].flags == 0) offset = (qint64) head.ldata_offset;
	   if(sprnode[a].flags != 0) offset = (qint64) head.tdata_offset;
	   offset += (qint64) sprnode[a].offset;
	   in.device()->seek(offset);
	   
       QImage img;
	   char * tmpStr = new char[sprnode[a].len];
	   QByteArray tmpArr;
	   in.readRawData(tmpStr, ((int) sprnode[a].len) );
	   tmpArr.append(tmpStr, ((int) sprnode[a].len) );
	   
	   //decoding encoded data
	   if(sprnode[a].fmt == 2) _sffv2_rle8Decode(tmpArr);
       if(sprnode[a].fmt == 3) _sffv2_rle5Decode(tmpArr);
       if(sprnode[a].fmt == 4) _sffv2_lz5Decode(tmpArr);
       
       //adding image
       if(sprnode[a].colordepth == 5 || sprnode[a].colordepth == 8) {
          img = _sffv2_matrixToImage8(tmpArr, ((int) sprnode[a].w), 
                   ((int) sprnode[a].h), paldata[sffitem.palindex].pal);
       }
	   //altri casi da aggiungere (immagini a colori reali 16,24 e 32) qui
	   //al momento non vengono aggiunti perch� non supportati
	   
	   sffitem.image = img;
	   sffitem.linked = -1;
	   delete [] tmpStr;
	   tmpArr.clear();
    }
    sffdata.append(sffitem);
  }
  
  //last step: matching for paldata isUsed and usedby
  for(int a = 0; a < sffdata.size(); a++) {
    int b = sffdata[a].palindex;
    if(paldata[b].isUsed == false) {
	  paldata[b].isUsed = true;
	  paldata[b].usedby = a;
    }	  
  }
  
  return true;
}



bool SffV2::write(QString & filename) {
	//manca il controllo assenza errori interni (tipo due immagini con stesso groupno, imageno)
	
  { //testing chances to open file
    QFile sffFile(filename);
    if(!sffFile.open(QIODevice::WriteOnly)) {
	   QMessageBox::warning((QWidget *) 0, QMessageBox::tr("Error!"), 
	      QMessageBox::tr("Unable to Write File. Perhaps you are trying to write in a read-only folder?") );
	   return false;
    }
    QDataStream out(&sffFile);
    out.setByteOrder(QDataStream::LittleEndian);
  }
  //Progress Bar...
    QProgressDialog progress(QDialog::tr("Searching Errors..."),
                             QString::null, 0, 101);
    progress.setWindowTitle(QDialog::tr("Wait..."));
    QPushButton * progress_cancel_btn = new QPushButton (&progress);
    {
	  Qt::WindowFlags flags = 0;
      flags = Qt::WindowTitleHint;
      flags |= Qt::Dialog;
      progress.setWindowFlags(flags);   
    }
    progress_cancel_btn->setObjectName(QString::fromUtf8("progress_cancel_btn"));
    progress_cancel_btn->setEnabled(false);
    progress_cancel_btn->setText(QWidget::tr("Cancel"));
    progress_cancel_btn->setObjectName(QString::fromUtf8("progress_cancel_btn"));
    progress.setCancelButton(progress_cancel_btn);
    progress.setMinimumDuration(0);
    progress.setValue(0);

  //checking for errors
  {
	progress.setLabelText("Searching Errors...");
    QString errorStr = this->scanSff(false); //(false) marks that this sff format DOESN'T support images NOT indexed
    if(this->scanSff(false) != "") {
      progress.setValue(101);
      delete progress_cancel_btn;
      QMessageBox::warning((QWidget *) 0, QMessageBox::tr("Error!"), errorStr);
      return false;
    }
    progress.setLabelText(QObject::tr("Writing Sff..."));		
  }
  //Start File Creation
  _SFFV2_SFF_HEADER head; //512
  QList<_SFFV2_SPRITE_NODE_HEADER> sprnode; //28
  QList<_SFFV2_PAL_NODE_HEADER> palnode; //16
  
  //setting head const values
  strcpy(&head.signature[0], "ElecbyteSpr");
  head.signature[11] = 0;
  head.verlo3 = 0; head.verlo2 = 0;
  head.verlo1 = 0; head.verhi = 2;
  for(int a = 0; a < 4; a++) { 
    head.reserved1[a] = 0; head.reserved2[a] = 0; head.reserved3[a] = 0;  
    head.reserved4[a] = 0; head.reserved5[a] = 0; head.reserved6[a] = 0;
  }
  for(int a = 0; a < 436; a++) head.unused[a] = 0;
  head.compatverlo3 = 0; head.compatverlo2 = 0;
  head.compatverlo1 = 0; head.compatverhi = 2;
  
  //if "Removed Duplicates" is cheched, than check for images equal to other ones 
  //  and mark cloned images in the parameter "linked"
  if(removeDuplicates == true) {
	 progress.setLabelText("Checking Duplicate Images... Please wait...");
	 this->searchDuplicateImages(); //call SffHandler::searchDuplicateImages()
	 progress.setLabelText("Writing Sff...");
  }
  
  //Writing ldata as ByteArray  
  QByteArray ldata; ldata.clear(); 
  
  //writing pals in ldata  
  for(int a = 0; a < paldata.size(); a++) {
	//block
	QByteArray arrPal = _sffv2_palToMatrix(paldata[a].pal);
	//set node
    _SFFV2_PAL_NODE_HEADER node;
    node.groupno = paldata[a].groupno;
    node.itemno = paldata[a].itemno;
    node.numcols = paldata[a].pal.size();
    node.linked = 0;
    node.offset = ldata.size();
    node.len = arrPal.size();
    //add node in palnode list
    palnode.append(node);
    //add pal in ldata
    ldata.append(arrPal);
  }
  
  //writing sprites in ldata
  for(int a = 0; a < sffdata.size(); a++) {
	_SFFV2_SPRITE_NODE_HEADER node;
	//block
	QByteArray arrSpr; arrSpr.clear();
	if(sffdata[a].linked == -1) { //real image	  
	  arrSpr = _sffv2_image8ToMatrix (sffdata[a].image, sffdata[a].image.width(), sffdata[a].image.height() );
	  int colors = paldata[sffdata[a].palindex].pal.size();
	  if(colors <= 32) { //5bit image
		_sffv2_lz5Encode(arrSpr);
		node.linked = 0;  
		node.fmt = 4; //fmt = 4 = LZ5 compression
		node.colordepth = 5; 
		node.offset = ldata.size();
		node.len = arrSpr.size();
      }
      if(colors > 32) {
	    _sffv2_rle8Encode(arrSpr);
	    node.linked = 0;  
		node.fmt = 2; //fmt = 2 = RLE8 compression
		node.colordepth = 8; 
		node.offset = ldata.size();
		node.len = arrSpr.size();
      }
      ldata.append(arrSpr); //add sprite to ldata
    }
    else { //linked image
      int k = sffdata[a].linked;
      node.linked = k;
      node.fmt = sprnode[k].fmt;
      node.colordepth = sprnode[k].colordepth;
      node.offset = 0; 
      node.len = 0;
    }
    //setting remaining "node" values
    node.groupno = sffdata[a].groupno;
    node.imageno = sffdata[a].imageno;
    node.w = sffdata[a].image.width();
    node.h = sffdata[a].image.height();
    node.x = sffdata[a].x;
    node.y = sffdata[a].y;
    node.palindex = sffdata[a].palindex;
    node.flags = 0;
    //adding node in sprnode list
    sprnode.append(node); 
    
    progress.setValue( (((a+1) * 100) / sffdata.size()) );
  }
  
  //now setting the remaining values for head
  head.first_palnode_offset = 512;
  head.total_palettes = palnode.size();
  head.first_sprnode_offset = 512 + (head.total_palettes * 16);
  head.total_frames = sprnode.size();
  head.ldata_offset = head.first_sprnode_offset + (head.total_frames * 28);
  head.ldata_length = ldata.size();
  head.tdata_offset = head.ldata_offset + head.ldata_length;
  head.tdata_length = 0;
  
  //And finally..... writing file
 
  QFile sffFile(filename);
  sffFile.open(QIODevice::WriteOnly);
  QDataStream out(&sffFile);
  out.setByteOrder(QDataStream::LittleEndian);
  //writing header
  out<<head;
  //writing palnodes
  for(int a = 0; a < palnode.size(); a++) out<<palnode[a];
  //writing sprnodes
  for(int a = 0; a < sprnode.size(); a++) out<<sprnode[a];
  //writing tdata
  out.writeRawData(ldata.data(), ldata.size());
  sffFile.close();
  
  //close progress bar
  progress.setValue(101);
  delete progress_cancel_btn;
  return true;
}

