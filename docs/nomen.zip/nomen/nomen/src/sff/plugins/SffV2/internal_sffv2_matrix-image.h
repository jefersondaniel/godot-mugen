/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/
 
// SFFv2 INTERNAL ONLY. DON'T USE THIS HEADER OUTSIDE sffv2

//matrixToImage*. Convert a QByteArray "raw" to a QImage. 
//               * will be replaced by 8, 24 or 32 depending of bit per pixel

//image*ToMatrix reverse conversion

QImage _sffv2_matrixToImage8 (QByteArray &src, int w, int h, QVector <QRgb> & colors) {
  QImage img(w, h, QImage::Format_Indexed8);
  int k = 0;
  for(int y=0; y<h; y++) {	  
    uchar *p = img.scanLine(y);
    for(int x=0; x<w; x++) {
	  p[x] = src[k]; k++;
    }    
  }
  img.setColorTable(colors);
  return img;
}


QByteArray _sffv2_image8ToMatrix (QImage &img, int w, int h) {
  QByteArray dest;
  for(int y=0; y<h; y++) {
    uchar *p = img.scanLine(y);
    for(int x=0; x<w; x++) {
	  dest.append((char) p[x]);
    }	  
  }
  return dest;	
}


//image16, image24 and image32 will be implemented later

