/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/
 
// SFFv2 INTERNAL ONLY. DON'T USE THIS HEADER OUTSIDE sffv2

enum _SFFV2_LZ5_NOMEN_PACKER__NAME {
  rle, short_lz, long_lz
};


struct _SFFV2_LZ5_NOMEN_PACKER {
  _SFFV2_LZ5_NOMEN_PACKER__NAME type;
  int value1; int value2;
  //LZ5_RLE packet:  value1 = color,  value2 = numtimes
  //LZ5_LZ  packet:  value1 = len  ,  value2 = offset
};


// while we have an unique _SFFV2_LZ5_LZ_PACKET for reading, we have 2 indipendent LZ5_LZ_PACKET writers:
// _SFFV2_LZ5_LZ_LONG_PACKET for long lz packets and _SFFV2_LZ5_LZ_SHORT_PACKET for short lz packets


struct _SFFV2_LZ5_LZ_LONG_PACKET {
  int len;
  int offset;
};


struct _SFFV2_LZ5_LZ_SHORT_PACKET {
  int len;
  int offset;
  quint8 recycled;
  quint8 recycled_bits;
};




QDataStream &operator<<( QDataStream &ds, const _SFFV2_LZ5_CONTROL_PACKET &pack ) 
{
  {
    quint8 byte = 0; 
    byte += pack.flags[7] * 0x80;
    byte += pack.flags[6] * 0x40;
    byte += pack.flags[5] * 0x20;
    byte += pack.flags[4] * 0x10;
    byte += pack.flags[3] * 0x08;
    byte += pack.flags[2] * 0x04;
    byte += pack.flags[1] * 0x02;
    byte += pack.flags[0] * 0x01;
    ds<<byte;
  }
  return ds;	
}


QDataStream &operator<<( QDataStream &ds, _SFFV2_LZ5_RLE_PACKET &pack ) 
{
  if(pack.numtimes <= 7) {
	  //short lz_rle packet
	  quint8 ch = (quint8) pack.numtimes;
	  ch = ch << 5;
	  ch += (quint8) pack.color;
	  ds<<ch;
  }  
  if(pack.numtimes >= 8) {
	  //long lz_rle packet 
	  pack.numtimes -= 8;
	  quint8 ch1 = (quint8) pack.color;
	  quint8 ch2 = (quint8) pack.numtimes;
	  ds<<ch1; ds<<ch2;   
  }
  return ds;	
}


QDataStream &operator<<( QDataStream &ds, const _SFFV2_LZ5_LZ_LONG_PACKET &pack )
{
  int temp = pack.offset / 256; //prende solo i 2 bits superiori. Valori possibili: 0-3
  quint8 ch1 = (quint8) temp;
  ch1 = ch1 << 6;
  
  temp = pack.offset - ((pack.offset / 256) * 256); //pack.offset / 256 prende i 2 bit superiori. Rimoltiplicando si perdono i bit inferiori. Con la differenza si riottengono solo i bit inferiori
  quint8 ch2 = (quint8) temp;
  
  quint8 ch3 = (quint8) pack.len;
  
  ds<<ch1; ds<<ch2; ds<<ch3;
                         
  return ds;
}


QDataStream &operator<<( QDataStream &ds, const _SFFV2_LZ5_LZ_SHORT_PACKET &pack )
{
  quint8 ch = (quint8) pack.len;
  ch += pack.recycled;
  ds << ch;
  if(pack.offset != -5) {
    ch = (quint8) pack.offset;
    ds << ch;
  }
  return ds;
}




void _sffv2_lz5Decode_internal_search_lz_candidate(QByteArray & src, int & lz_dimension, int & index, const int maxoff, const int maxdim)
{
  bool while_match = true;
  lz_dimension = 1; index = -1;
	//try to find the longest LZ candidate possible
	while (while_match == true && lz_dimension < maxdim) {
		
		//va migliorato: non comtempla il caso di match ricorsivi
		
	  QByteArrayMatcher search(src.right(lz_dimension +1));
	  int indexToVer = search.indexIn(src, (src.size() - maxoff));
      if( indexToVer < (src.size() - lz_dimension -1)) { //LZ CANDIDATE FOUND
	    //if string finded (and not the same at end) will verify if the string contains 
	    //more than a single color value. If only a color value rle_match = true
	    // If 2 or more different color values finded lz_match = true
	    lz_dimension++; index = indexToVer;
      }
      else {
	     //before saying that we haven't a LZ CANDIDATE we must try to see if an end-recursive candidate can be found
	     QByteArray stringToMatch = src.right(lz_dimension +1);
	     int recursive_len = stringToMatch.size() / 2;
		 bool recursive_match = false;
	     // now we match the longest recurse possible (more longer is recurse, more shorter string to match => more chance to find)
		 while(recursive_len > 0 && recursive_match == false) {
		   QByteArray alfa = stringToMatch.left(recursive_len);
		   QByteArray beta = stringToMatch.right(recursive_len);
		   if(alfa == beta) recursive_match = true;
		   else recursive_len--;
	     }
		 //now trying to identify the recursive match if there is a recursivity in string to match  
		 
	     if(recursive_match == true) {
		   //tmpArr is the array without the entire result string to add with lz candidate
		   QByteArray tmpArr = src;
		   tmpArr.resize(tmpArr.size() - stringToMatch.size()); //stringToMatch at this point is not yet reduced to recursivity so we can emulate a right check
		   //now stringToMatch will be the string to find at end of tmpArr (string without recursivity)
		   stringToMatch.resize(stringToMatch.size() - recursive_len);
		   // tmpArr is the string where (unrecursive) stringToMatch should be find at end
		   if(tmpArr.endsWith(stringToMatch) == true) { //match works so we found a recursive LZ candidate
		     lz_dimension++; index = tmpArr.size() - stringToMatch.size() -1;
	       }
		   else while_match = false;
	     }
	     if(recursive_match == false) while_match = false;
      }
    }	
}





void _sffv2_lz5Encode(QByteArray &src) {
  
  //step1: create a list of SFFV2_LZ5_NOMEN_PACKER. This will contain temp data structured in units
  //       any unit will be "rle" or "lz"
  //       if unit type = rle -------------------> value1 = color, value2 = numtimes.
  //       if unit type = short_lz or long_lz : -> value1 = len  , value2 = offset.
	
  QList<_SFFV2_LZ5_NOMEN_PACKER> work;
  long original_size = src.size();
  while(src.size() > 0) { //src will be destryed until empty and "work" will be filled
	/* 
	   trying to find a possible lz packed: we are trying to find recursively the longest 
	   array of characters possible that occurs inside the array and in the end of the array itself
	*/
    int lz_dimension = 1;
    int index = -1; 
	bool lz_match = false; 
	bool justdone = false;
	
	_sffv2_lz5Decode_internal_search_lz_candidate(src, lz_dimension, index, 1024, 258);
	
    //if the lz_dimension is greater than 1 then a LZ CANDIDATE FOUND. The code inside will decide if it is a good candidate or not
    //if the lz candidate data is composed by all bytes of the same value (same color) than candidate not good => we procede with rle packet 
    if(lz_dimension >= 2) {
	  char ch, ch2; ch = src[index];
	    for(int a = (index+1); a < (index+lz_dimension); a++) {
	   	  ch2 = src[a];
	   	  if(ch2 != ch) { lz_match = true; break; }
	  } 
    }
    
    {
      _SFFV2_LZ5_NOMEN_PACKER t;
      
      if(lz_match == true) { //determines a long_lz or short_lz unit      
	    t.value1 = lz_dimension; //value1 = len
	    t.value2 = src.size() - lz_dimension - index; //value2 = offset  
	    if( t.value1 > 64 || t.value2 > 256) {  //if len > 64 || offset > 256
		   if(t.value1 < 3) lz_match = false; //strange case but possible (if offset = 257 or 258): we are outside both long lz and short lz so we must proceed to rle5 and abandone lz
		   if(t.value1 >=3 && t.value1 < 66) {
			   //valid long lz candidate
			   //a long lz packet can be not convenient becouse it is 3bytes long.
			   //expecially if len is not at least 66 (1 + max_short_lz_len = 65)
			   
			   //long_lz EFFICIENCY VERIFICATION
			   //Step1: emulate result with n rle candidates 
			   
			   int saved_space_with_rle_only = 0;
			   {
				 _SFFV2_LZ5_NOMEN_PACKER t2;
			     quint8 k = 0;
			     QByteArray tmp = src;
			     while (k < 3) {
				   t2.type = rle;
				   t2.value1 = (int) tmp[tmp.size() -1]; //value1 = color
                   t2.value2 = 1;
                   bool end = false;
                   while(end == false) {
	                 if( (tmp.size() -1 -t2.value2) >=0) {
	                   if(tmp[tmp.size() -1] == tmp[tmp.size() -1 - t2.value2]) t2.value2++;
	                   else end = true;
                     }
                     else end = true;
                   }
                   if(t2.value2 <=7) k+=1;
                   if(t2.value2 >=8) k+=2;
                   tmp.resize( tmp.size() - t2.value2 );
			     }
			     saved_space_with_rle_only = src.size() - tmp.size();
		       }
			   
		       //long_lz EFFICIENCY VERIFICATION
			   //Step2: emulate the result with 2 short lz packet (if exist and longest possible) + rle
			     
			     QList<_SFFV2_LZ5_NOMEN_PACKER> tmpList2;
			     int lz_dimension2 = 1;
			     int index2 = -1; 
	             bool lz_match2 = false; 
	             int saved_space_with_2 = 0;
	             QByteArray result2 = src;
	             
	             for(int unusedval = 0; unusedval < 2; unusedval ++) {
	               lz_match2 = false;
		             
	               _sffv2_lz5Decode_internal_search_lz_candidate(result2, lz_dimension2, index2, 256, 64); //try to find a short lz candidate
				 
		             _SFFV2_LZ5_NOMEN_PACKER t2;
			         if(lz_dimension2 >= 2) {
	                    char ch, ch2; ch = src[index];
	                    for(int a = (index+1); a < (index+lz_dimension); a++) {
	   	                  ch2 = src[a];
	   	                  if(ch2 != ch) { lz_match2 = true; break; }
	                    }                    
			         }
			         if(lz_match2 == true) {
				        t2.type = short_lz;
				        t2.value1 = lz_dimension2; //value1 = len
	                    t2.value2 = result2.size() - lz_dimension2 - index2; //value2 = offset  
	                    result2.resize( result2.size() - lz_dimension2 );
	                    saved_space_with_2 += lz_dimension2;
			         }
			         if(lz_match2 == false) {
				        t2.type = rle;
				        t2.value1 = (int) result2[result2.size() -1]; //value1 = color
                        t2.value2 = 1;
                        bool end = false;
                        while(end == false) {
	                      if( (result2.size() -1 -t2.value2) >=0) {
	                        if(result2[result2.size() -1] == result2[result2.size() -1 - t2.value2]) t2.value2++;
	                        else end = true;
                          }
                          else end = true;    
                        }
                        result2.resize( result2.size() - t2.value2 ); 
                        saved_space_with_2 += t2.value2;  
			         }
			         tmpList2.append(t2); //reverse order with prepend (like "work" - see further)
                 } //end for (2 times)
                 
                 //long_lz EFFICIENCY VERIFICATION
                 //step 3: compare results
                 
                 if(lz_dimension >= saved_space_with_rle_only && lz_dimension >= saved_space_with_2) t.type = long_lz;
                 else {
	               //if you reach this point "saved_space_with_rle_only" or "saved_space_with_2" is >= than saved space with long lz
	               if(saved_space_with_rle_only > saved_space_with_2) {
		             lz_match = false;  //abandone lz to rle
	               }
	               else { //saved_space_with_2 >= with rle
		             if(tmpList2[0].type == rle) {
			           lz_match = false; //abandone lz to rle
		             }
		             else {
			           work.prepend(tmpList2[0]);
		               src.resize(src.size() - tmpList2[0].value1);
		               justdone = true; //will mark that work is just modifyed
	                 } //end else [ type != rle]
	               } //end else [ space_with_2 >= with_rle
                 } //end else [ actual long_lz_candidate is not an efficient choice ]
	       } //end if t.value1 >=3 && t.value1 <66 [actual_long_lz_candidate can be efficient or not so is tested - end of test]
	       
	       if(t.value1 >= 66) t.type = long_lz; //if len >= 66 we assume that long lz pack is convenient 
	       
	    } //end case long lz packet candidate (t.value1 > 64 || t.value2 > 256)
	    
	    
	    if( t.value1 <= 64 && t.value2 <= 256)  { //case: short_lz
	      //testing if short_lz is efficient
	      //emulating a result with 2 rle
		         _SFFV2_LZ5_NOMEN_PACKER t2;
			     quint8 k = 0;
			     QByteArray tmp = src;
			     while (k < 2) {
				   t2.type = rle;
				   t2.value1 = (int) tmp[tmp.size() -1]; //value1 = color
                   t2.value2 = 1;
                   bool end = false;
                   while(end == false) {
	                 if( (tmp.size() -1 -t2.value2) >=0) {
	                   if(tmp[tmp.size() -1] == tmp[tmp.size() -1 - t2.value2]) t2.value2++;
	                   else end = true;
                     }
                     else end = true;
                   }
                   if(t2.value2 <=7) k+=1;
                   if(t2.value2 >=8) k+=2;
                   tmp.resize( tmp.size() - t2.value2 );
			     }
			     int saved_space_with_rle_only = src.size() - tmp.size();
		    //now we have emulated how many space we would save if we would continue with rle only
		    //this value is stored to saved_space_with_rle_only to know if lz candidate is efficient or not
	        if(t.value1 >= saved_space_with_rle_only) t.type = short_lz;
	        else lz_match = false; //if short_lz candidate is not efficient abandone it to rle
	    }
	    
	    if(lz_match == true && justdone == false) src.resize( src.size() - lz_dimension ); //this avoid the resize if we must abandone lz_candidate for a rle pack. Also avoid resize if we did just the work inside long_lz_candidate evaluation
      }
      
      if(lz_match == false) { //determines a rle unit
        t.type = rle;
        t.value1 = (int) src[src.size() -1]; //value1 = color
        t.value2 = 1;
        bool end = false;
        while(end == false) {
	      if( (src.size() -1 -t.value2) >=0) {
	        if(src[src.size() -1] == src[src.size() -1 - t.value2]) t.value2++;
	        else end = true;
          }
          else end = true;    
        }
        //value2 = numtimes
        src.resize( src.size() - t.value2 );
      } //end lz_match = false
      
      if(justdone == false) work.prepend(t); //the list must be reversed becouse we are proceding from end to beginning. This why "prepend" and not "append"
                                             //work.prepend will not work here if justdone = true (= case long_lz_candidate_unefficient: work is modifyed inside that case)
    } //destroy t  
  } //end while src.size() > 0
  
  //step2: analyze _SFFV2_LZ5_NOMEN_PACKER. 
  //       we must find all short lz packet inside _SFFV2_LZ5_NOMEN_PACKER to individuate items for recicled bits
  //       short_lz_values_to_recycle will memorize every 4th short lz offset
  
  QByteArray short_lz_values_to_recycle;
  {
    int num_short_lz = 0;
    for(int a = 0; a < work.size(); a++) {
	  if(work[a].type == short_lz) {
	    num_short_lz++;
	    if(num_short_lz == 4) {
		  num_short_lz = 0; quint8 b = (quint8) (work[a].value2 -1);
		  short_lz_values_to_recycle.append((char) b); 
	    }
      }
    } 
    short_lz_values_to_recycle.append((char) 0); //this last item (=0) is to avoid possible SISVEG errors
  }
  
  //step3: writing lz5 encoded array in src
  //       
  //
  src.clear();
  QBuffer destbuffer(&src);
  destbuffer.open(QIODevice::WriteOnly);
  QDataStream out(&destbuffer);
  _SFFV2_LZ5_CONTROL_PACKET ctrl;
  _SFFV2_LZ5_RLE_PACKET rlepack;
  _SFFV2_LZ5_LZ_SHORT_PACKET lzShort;
  _SFFV2_LZ5_LZ_LONG_PACKET lzLong;
  int recycled_index_list = 0;
  
  //init values for ctrl, lzShort
  for(int a = 0; a < 8; a++) ctrl.flags[a] = 0;
  lzShort.recycled = 0; lzShort.recycled_bits = 0;
  
  out.writeRawData((char *) &original_size, 4); //writing first 4 bytes: uncompressed size
  quint8 pack_number = 0;
  for(int a = 0; a < work.size(); a++) {
    pack_number++;
    if(pack_number == 9) pack_number = 1;
    if(pack_number == 1) { //writing control packet every 8 packets
	  int b = a;
	  while(b < work.size() && b < a+8) {
	    if(work[b].type == rle) {
		  ctrl.flags[b-a] = 0;
	    }
	    if(work[b].type == long_lz || work[b].type == short_lz) {
		  ctrl.flags[b-a] = 1;
	    }
		b++;	  
      }
      out<<ctrl;
    }
    
    if(work[a].type == rle) {
	  rlepack.color = (quint8) work[a].value1;
	  rlepack.numtimes = work[a].value2;
	  out<<rlepack;
    }
    if(work[a].type == long_lz) {
	  lzLong.len = work[a].value1 -3;
	  lzLong.offset = work[a].value2 -1;
	  out<<lzLong;    
    }
    if(work[a].type == short_lz) {
	  quint8 ch = short_lz_values_to_recycle[recycled_index_list];
	  if(lzShort.recycled_bits == 0) lzShort.recycled = ch & 0xc0;
	  if(lzShort.recycled_bits == 2) lzShort.recycled = ((ch & 0x30) << 2);
	  if(lzShort.recycled_bits == 4) lzShort.recycled = ((ch & 0x0c) << 4);
	  if(lzShort.recycled_bits == 6) lzShort.recycled = ((ch & 0x03) << 6);
	  lzShort.recycled_bits += 2; lzShort.offset = work[a].value2 -1;
	  if(lzShort.recycled_bits == 8) {
	    lzShort.recycled_bits = 0; lzShort.offset = -5;	  
	    recycled_index_list++;
      }
      lzShort.len = work[a].value1 -1;
      out<<lzShort;
    }
  } //end for work size
}

