/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#include "../../SffHandler.h"
#include "../../SffItem.h"
#include "SffV1.h"
//Qt included: QString, QList, QGraphicsPixmapItem

#include <QTextStream>

#include <QByteArray>
#include <QDataStream>
#include <QFile>
#include <QImage>
#include <QPixmap>
#include <QBuffer>
#include <QString>
#include <QProgressDialog>
#include <QPushButton>
#include <QMessageBox>
#include "../../nomenSffFunctions.h"
#include "internal_sffv1_structs.h"
#include "internal_sffv1_functions.h"

#include <string>



void SffV1::wText(QString & snapdest, const QString & imgf, const QString & palf, QList<SffData> & _sffdata, QList<SffPal> & _paldata) { 
  if(imgf == "pcx" && (palf == "PalAct" || palf == "act") ) {
    Q_UNUSED(_paldata); //paldata is not used in SffV1.txt
    QString filename = snapdest; filename.append("/SffV1.txt");
    QFile txtfile(filename);
    txtfile.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&txtfile);
    
    bool isCharSff = false;
    for(int a=0; a < _sffdata.count(); a++) {
	  if(_sffdata[a].groupno == 9000 && (_sffdata[a].imageno == 0 || _sffdata[a].imageno == 1) ) {
	    isCharSff = true; break;	  
      }
    }
    
    
    if(isCharSff == true) {
	  //write CharSff File
	  out<<";Created with Nomen - Remember to rename \"SffV1.sff\" with the name you prefer\n";
	  out<<"#\n1\n2\nSffV1.sff\n";
	  QString name;
	  QList <SffData> pal1;
	  QList <_SFFV1_NOMEN_STRUCT> palx;
	  SffData shortp; //short portrait
	  shortp.groupno = -1;
	  for(int a = 0; a < _sffdata.size(); a++) {
	    if(_sffdata[a].palindex == 0 && !(_sffdata[a].groupno == 9000 && _sffdata[a].imageno == 0)) {
		  //add all images with pal 1,1 (except for 9000,0) into "pal1"
		  pal1.append(_sffdata[a]);    
	    }
	    else if(_sffdata[a].groupno == 9000 && _sffdata[a].imageno == 0) {
		  //when encountered 9000,0
		  shortp = _sffdata[a];    
        }
        else if(_sffdata[a].palindex != 0) {
	      //add all images with pal x,y where x != 1 (except for 9000,0) into palx
	      int whereToAdd = -1;
          for(int b = 0; b < palx.size(); b++) {
	        int val1 = _sffdata[a].palindex;
	        int val2 = palx[b].palindex;
	        if(val1 == val2) whereToAdd = b;
          }
    
          if(whereToAdd == -1) { //pal is new so list must expanded
	         _SFFV1_NOMEN_STRUCT tmp;
	         tmp.palindex = _sffdata[a].palindex;
	         palx.append(tmp);
	         whereToAdd = palx.size() -1; //now whereToAnd points to last 
          }
    
          //here whereToAdd marks the point where to add
          palx[whereToAdd].sffdata.append(_sffdata[a]);
        } 
      }
    
      if(shortp.groupno != -1) {
	    //a 9000,0 image exists... write it as first image
	    out<<"#\n1\n1\n";
	    out<<"9000-00.pcx\n";
	    out<<"9000\n0\n0\n0\n";
	    if(shortp.palindex != 0) out<<"#\n1\n1\n";
      }
    
      if(shortp.groupno == -1) {
	    //a 9000,0 image NOT exist.... first image is however individual
	    out<<"#\n1\n1\n";
      }
    
      for(int a = 0; a < pal1.size(); a++) {
	    //writing pal 1,1 images
	    if(a != 0 && pal1[a].groupno == 0 && pal1[a].imageno == 0) {
	      //image 0,0 always individual (case 1: if in middle of other 1,1 images)
	      out<<"#\n1\n1\n";	  
        }
        if(a == 0 && pal1[a].groupno == 0 && pal1[a].imageno == 0 && shortp.groupno != -1) {
	      //image 0,0 always individual (case 2: if immediatly after image 9000,0 with pal 1,1)
	      out<<"#\n1\n1\n";    
        }
        name = _sffv1_wText_file_calc(pal1[a].groupno, pal1[a].imageno, imgf);
        out<<name<<"\n";
        out<<pal1[a].groupno<<"\n";
        out<<pal1[a].imageno<<"\n";
        out<<pal1[a].x<<"\n";
        out<<pal1[a].y<<"\n";
      }
    
      for(int a = 0; a < palx.size(); a++) {
	    for(int b = 0; b < palx[a].sffdata.size(); b++) {
	      out<<"#\n1\n1\n";
	      name = _sffv1_wText_file_calc(palx[a].sffdata[b].groupno, palx[a].sffdata[b].imageno, imgf);
	      out<<name<<"\n";
	      out<<palx[a].sffdata[b].groupno<<"\n";
	      out<<palx[a].sffdata[b].imageno<<"\n";
	      out<<palx[a].sffdata[b].x<<"\n";
	      out<<palx[a].sffdata[b].y<<"\n";	  
        }
      }
    } //end isCharSff == true
    
    
    if(isCharSff == false) {
	  //write NON-Char Sff File
	  out<<";Created with Nomen - Remember to rename \"SffV1.sff\" with the name you prefer\n";
	  out<<"#\n1\n1\nSffV1.sff\n";
	  QString name;
	  QList <_SFFV1_NOMEN_STRUCT> data;
	  for(int a = 0; a < _sffdata.size(); a++) {
	      //reordering all images by palette
	      int whereToAdd = -1;
          for(int b = 0; b < data.size(); b++) {
	        int val1 = _sffdata[a].palindex;
	        int val2 = data[b].palindex;
	        if(val1 == val2) whereToAdd = b;
          }
    
          if(whereToAdd == -1) { //pal is new so list must expanded
	         _SFFV1_NOMEN_STRUCT tmp;
	         tmp.palindex = _sffdata[a].palindex;
	         data.append(tmp);
	         whereToAdd = data.size() -1; //now whereToAnd points to last 
          }
    
          //here whereToAdd marks the point where to add
          data[whereToAdd].sffdata.append(sffdata[a]);
      } 
    
      for(int a = 0; a < data.size(); a++) {
	    out<<"#\n1\n1\n";
	    for(int b = 0; b < data[a].sffdata.size(); b++) {
	      if(b > 0) out<<"#\n1\n2\n";
	      name = _sffv1_wText_file_calc(data[a].sffdata[b].groupno, data[a].sffdata[b].imageno, imgf);
	      out<<name<<"\n";
	      out<<data[a].sffdata[b].groupno<<"\n";
	      out<<data[a].sffdata[b].imageno<<"\n";
	      out<<data[a].sffdata[b].x<<"\n";
	      out<<data[a].sffdata[b].y<<"\n";	  
        }
      }
    } //end isCharSff == false
    
        
    txtfile.close();    
  } //end if PAL == (act || palact) && IMG == pcx
  
  
  
  else { //unsupported formats for sprmaker so don't create txt
    Q_UNUSED(snapdest); Q_UNUSED(imgf); Q_UNUSED(palf);	Q_UNUSED(_sffdata); Q_UNUSED(_paldata);
  }	
}







bool SffV1::read(QString & filename) {
  _SFFV1_SFF_HEADER head;
  _SFFV1_SFF_SPRITE_HEADER spr;
  
  QFile sffFile(filename);
  if(!sffFile.open(QIODevice::ReadOnly)) return false;
  QDataStream in(&sffFile);
  in.setByteOrder(QDataStream::LittleEndian);
  in>>head;
  if(strcmp(&head.signature[0], "ElecbyteSpr")!=0) return false;
  if(head.verhi!=0 && head.verlo!=1 && head.verlo2!=0 && head.verlo3!=1) return false;
  
  long actual_offset = head.first_offset;
  //bool first_sprite = true;
  QByteArray palref;
  int counter = -1;
  int actual_palindex = 0;
  QList <int> sharedImage; //used only in charecter sff decoding
  QList <int> indImage; //indivudual images list - used only in character sff decoding
  
  while(!in.atEnd()) {	  
	SffData sffitem; counter++;
	in>>spr; long arraySize = spr.offsetNextSprite - actual_offset - 32;
    if(arraySize > 0) { //normal image
      char * tmpStr = new char[arraySize];
      QByteArray tmpArr;
	  in.readRawData(tmpStr, ((int) arraySize) );
	  tmpArr.append(tmpStr, ((int) arraySize) );

	  if(head.isShared == true && spr.isShared == true) {
	    sharedImage.append(counter); //add current image index to "sharedImages" list if it is a shared image and if it is a char-sff
	    for(int a = 0; a < 768; a++) { quint8 ch = 0; tmpArr.append(ch); }
	    /*QByteArray tref = tmpArr; tref = tref.right(768);
	    tmpArr.append(tref); tref.clear();*/
      }
	  
	  if(head.isShared == false && spr.isShared == true) { //if the sff is a non-char one (and image is shared), mantain original reading approach like v. 0.1
	    tmpArr.append(palref); //if sff is non-char sff append palref and NOT use sharedImages list
      }
      
      if(spr.isShared == false) {
	      indImage.append(counter);
	      actual_palindex = paldata.size(); //actual pal index for this sff item. Starts as a new value to take if uses a new pal. Will change if the pal used is not new
          palref = tmpArr; palref = palref.right(768);          
          tmpArr.append(palref);
          SffPal sffpal;
	      sffpal.pal = _sffv1_matrixToPal(palref);
	      sffpal.groupno = paldata.size() +1;
	      sffpal.itemno = 1;
	      sffpal.isUsed = true;
	      sffpal.usedby = counter;	      
	      { //check if this pal is already present and if new add it to paldata
	          bool checked = false;
		      for(int k=0; k<paldata.size(); k++) {
			    if(nomenComparePalettes(sffpal.pal, paldata[k].pal) == true) {
				   checked = true; actual_palindex = k; break;
			     }
		      }
		      if(checked == false) paldata.append(sffpal); //append only if paldata is new
	      } 
      }  
      //assigning palindex to sffimage
      sffitem.palindex = actual_palindex;
      //setting image:
      {
        QBuffer buffer(&tmpArr);
        buffer.open(QIODevice::ReadOnly);
        sffitem.image.load(&buffer, "pcx"); // read image from tmpArr in pcx format
      }
      delete [] tmpStr; tmpArr.clear();
    }
    
    else { //linked image
      sffitem.image = sffdata[spr.linked].image;
      sffitem.palindex = sffdata[spr.linked].palindex;
      if(head.isShared == true && spr.isShared == true) sharedImage.append(counter);
    }
    
    sffitem.groupno = (int) spr.groupno;
    sffitem.imageno = (int) spr.imageno;
    sffitem.x = (int) spr.x;
    sffitem.y = (int) spr.y;
    sffitem.linked = -1;
    if(head.isShared == true && spr.isShared == true) sffitem.palindex = 0;
    
    sffdata.append(sffitem);
    actual_offset = spr.offsetNextSprite;
    
    /*{ 
	  QFile outdebugfile("debug.txt");
	  outdebugfile.open(QIODevice::Append | QIODevice::Text);
	  QTextStream outdebug(&outdebugfile);
	  outdebug<<"Image: "<<sffitem.groupno<<", "<<sffitem.imageno<<"\n";
	  outdebug<<"Shared Attributes -> SharedSff = ";
	  if(head.isShared==true) outdebug<<"Yes";
	  if(head.isShared==false) outdebug<<"No";
	  outdebug<<";  SharedImage = ";
	  if(spr.isShared==true) outdebug<<"Yes\n";
	  if(spr.isShared==false) outdebug<<"No\n";
	  outdebug<<"------------------------\n\n";
	  outdebugfile.close();
    }*/
    
  }
  
  
  
  //final step... reapply palette for char-sff shared images - needed in order to avoid possible problems
  if(head.isShared) {  
	QVector<QRgb> forcePal;
	//setting forcepal
	  bool have0 = false; //have0 = checking if there is a 0,x individual image
	  //verify if there is a 0,x individual
	  for(int k = 0; k < indImage.size(); k++) {
	    if(sffdata[indImage[k]].groupno == 0) {
		  have0 = true;
		  forcePal = sffdata[indImage[k]].image.colorTable();
		  break;    
	    }	  
      }
      //if there isn't a 0,x individual check other
      if(have0 == false) {
	    bool have90; // have90 = check 9000,0    
	    for(int k = 0; k < indImage.size(); k++) {
		  int alfa = indImage[k];
	      if(sffdata[alfa].groupno == 9000 && sffdata[alfa].imageno == 0) {
		    have90 = true;
		    forcePal = sffdata[indImage[k]].image.colorTable();
		    break;    
	      }	  
        }
        if(have90 == false) { //if no 0,x neither 9000,0 individual image (nearly impossible) than check for first non-9000,1 individual image
	      forcePal = sffdata[indImage[0]].image.colorTable(); //default value in case only one color
          /*if(indImage.size() >=2) {
	        if(sffdata[0].groupno == 9000 && sffdata[0].imageno == 1) {
		      forcePal = sffdata[indImage[1]].image.colorTable();    
	        }
          } */   
        }  
      }
	      
	//now forcePal is assigned. A)Swap Palettes if forcepal != (palindex = 0 / 1,1)
	{
	  int k = 0;
	  for(k = 0; k < paldata.size(); k++) {
	    if(nomenComparePalettes(forcePal, paldata[k].pal) == true) break;	  
      }
      
      if(k > 0) { //forcePal is not palindex = 0 than not 1,1. Swap forcePal with the current palindex = 0
        for(int w = 0; w < sffdata.size(); w++) {
	      //update palindex to the image that were linked to the palindex = 0 or palindex = k and swap them
	      if(sffdata[w].palindex == 0) sffdata[w].palindex = k;
	      else if(sffdata[w].palindex == k) sffdata[w].palindex = 0;
        }
        paldata[0].groupno = paldata[k].groupno;
	    paldata[0].itemno = paldata[k].itemno;
	    paldata[k].groupno = 1;
	    paldata[k].itemno = 1;
	    paldata.swap(0, k);
      } 
    } 
	
	//B) Reassigning images palettes to shared images
	for(int k = 0; k < sharedImage.size(); k++) {
	  sffdata[sharedImage[k]].image.setColorTable(forcePal);
	  sffdata[sharedImage[k]].palindex = 0;
    }
  }
  
  return true;
}


bool SffV1::write(QString & filename) {
  //Progress Bar...
    QProgressDialog progress(QDialog::tr("Searching Errors..."),
                             QString::null, 0, 101);
    progress.setMinimum(0);
    progress.setMaximum(101);
    progress.setWindowTitle(QDialog::tr("Wait..."));
    QPushButton * progress_cancel_btn = new QPushButton (&progress);
    {
	  Qt::WindowFlags flags = 0;
      flags = Qt::WindowTitleHint;
      flags |= Qt::Dialog;
      progress.setWindowFlags(flags);   
    }
    progress_cancel_btn->setObjectName(QString::fromUtf8("progress_cancel_btn"));
    progress_cancel_btn->setEnabled(false);
    progress_cancel_btn->setText(QWidget::tr("Cancel"));
    progress_cancel_btn->setObjectName(QString::fromUtf8("progress_cancel_btn"));
    progress.setCancelButton(progress_cancel_btn);
    progress.setMinimumDuration(0);
    progress.setValue(0);
  
  //...	
  _SFFV1_SFF_HEADER head;
  int actualItem = 0;
  
    QFile sffFile(filename);
    if(!sffFile.open(QIODevice::WriteOnly)) {
	   QMessageBox::warning((QWidget *) 0, QMessageBox::tr("Error!"), 
	      QMessageBox::tr("Unable to Write File. Perhaps you are trying to write in a read-only folder?") );
	   return false;
    }
    QDataStream out(&sffFile);
    out.setByteOrder(QDataStream::LittleEndian);
    
  //checking for errors
  {
	progress.setLabelText(QObject::tr("Searching Errors..."));
    QString errorStr = this->scanSff(false); //(false) marks that this sff format DOESN'T support images NOT indexed
    if(this->scanSff(false) != "") {
      progress.setValue(101);
      delete progress_cancel_btn;
      QMessageBox::warning((QWidget *) 0, QMessageBox::tr("Error!"), errorStr);
      return false;
    }
    progress.setLabelText(QObject::tr("Reordering Images..."));		
  }
  
  //setting head const values
  strcpy(&head.signature[0], "ElecbyteSpr");
  head.signature[11] = 0;
  head.verhi = 0;
  head.verlo = 1;
  head.verlo2 = 0;
  head.verlo3 = 1;
  head.numGroups = this->sffGroupCount();
  head.numImages = sffdata.size();
  head.first_offset = 512;
  head.subheader_size = 32;
  head.isShared = false; //later will become true if 9000,0 or 9000,1 image found
  for(int a = 0; a < 3; a++) head.reserved[a] = 0;
  for(int a = 0; a < 476; a++) head.comments[a] = 0;
  
  //Part 1:
  //reordering images...
  QList <SffData> group0; //images groupno = 0 (multilist by pal)
  SffData short_portrait; //image 9000,0 (if present)
  SffData big_portrait; //image 9000,1 (if present)
  short_portrait.groupno = -1; big_portrait.groupno = -1; //init groupno = -1 (marks that big and short potrait actually not present)
  QList <_SFFV1_NOMEN_STRUCT> list; //list of other images (multilist by pal)
   
  for(int a = 0; a < sffdata.size(); a++) {
	if(sffdata[a].groupno == 9000 && sffdata[a].imageno == 0) {
	  head.isShared = true; short_portrait = sffdata[a];
    }
	  
    else if(sffdata[a].groupno == 9000 && sffdata[a].imageno == 1) {
	  head.isShared = true; big_portrait = sffdata[a];    
    }
    
    else if(sffdata[a].groupno == 0) { group0.append(sffdata[a]); }
    
    else {
        int whereToAdd = -1;
        for(int b = 0; b < list.size(); b++) {
	      int val1 = sffdata[a].palindex;
	      int val2 = list[b].palindex;
	      if(val1 == val2) whereToAdd = b;
        }
    
        if(whereToAdd == -1) { //pal is new so list must expanded
	      _SFFV1_NOMEN_STRUCT tmp;
	      tmp.palindex = sffdata[a].palindex;
	      list.append(tmp);
	      whereToAdd = list.size() -1; //now whereToAnd points to last 
        }
    
        //here whereToAdd marks the point where to add
        list[whereToAdd].sffdata.append(sffdata[a]);
    }
  }
  progress.setLabelText(QObject::tr("Writing Sff..."));  
  
  //Part2:
  //Matching duplicates
  if(removeDuplicates == true) {
	 progress.setLabelText(QObject::tr("Checking Duplicate Images..."));
	 _sffv1_searchDuplicates(paldata, group0, &list);
	 progress.setLabelText(QObject::tr("Writing Sff..."));
  }
    
  //Part3: 
  //writing File...
  
  
  //header
  out<<head; long offset = 512;
  //image 9000,0 (if present)
  if(short_portrait.groupno == 9000) { 
	short_portrait.image.setColorTable(paldata[short_portrait.palindex].pal);
	_sffv1_writeImage(out, short_portrait, offset, false);
	_sffv1_updateProgress(&progress, actualItem, sffdata.count());
  }
  
  //group0 images (if it is a char image)
  if(head.isShared == true) {
    for(int a = 0; a<group0.size(); a++) { 
	  group0[a].image.setColorTable(paldata[group0[a].palindex].pal);
	  _sffv1_writeImage(out, group0[a], offset, true);
	  _sffv1_updateProgress(&progress, actualItem, sffdata.count());
    }
  }
  //other images except 9000,1
  //	A. pal 1,1
  { 
	QList <SffData> sim;
    for(int a = 0; a<list.size(); a++) { //find pal 1,1 images in list, and move them from list to sim
      if(paldata[list[a].palindex].groupno == 1 && paldata[list[a].palindex].itemno == 1) {
	    sim = list[a].sffdata; list.removeAt(a);
      }
    }
    for(int a = 0; a<sim.size(); a++) {
	  bool k;
	  if(a > 0) k = true;
	  if(a == 0) k = head.isShared;
	  //don't write group 0 image if char image (becouse just added before, in that case)
	  if(head.isShared == false || sim[a].groupno != 0) {
		sim[a].image.setColorTable(paldata[sim[a].palindex].pal);
	    _sffv1_writeImage(out, sim[a], offset, k); 
	    _sffv1_updateProgress(&progress, actualItem, sffdata.size());
      }
	    
    }
  }
  
  //   B. other pals (now list doesn't contain images with pal = 1,1)
  for(int a = 0; a < list.size(); a++) {
	QList <SffData> dat = list[a].sffdata;
    for(int b = 0; b < dat.size(); b++) {
	  bool k;
	  if(b == 0) k = false; //mark as individual if first item (in any case)
	  else {
	    if(head.isShared == true) k = false; //mark as individual every non-pal1,1 images if we are writing a char sff
	    if(head.isShared == false) k = true; //share images by pal groups if a sff is a non-char one
      }
      dat[b].image.setColorTable(paldata[dat[b].palindex].pal);
	  _sffv1_writeImage(out, dat[b], offset, k);
	  _sffv1_updateProgress(&progress, actualItem, sffdata.size());
    }
  }
  
  //And, finally, image 9000,1 (if present)
  if(big_portrait.groupno == 9000) { 
	big_portrait.image.setColorTable(paldata[big_portrait.palindex].pal);
	_sffv1_writeImage(out, big_portrait, offset, false);
	_sffv1_updateProgress(&progress, actualItem, sffdata.size());
  }
  
  
  sffFile.close();	  
  progress.setValue(101);
  delete progress_cancel_btn;
  return true; //todo
}

