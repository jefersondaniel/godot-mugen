/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/
 
#include "dlgPaletteSection.h"
#include "dlgPaletteSection__sd.h"
#include <QMessageBox>
#include <QFileDialog>


DlgPalSection::DlgPalSection(SffWidget * _parent, Sff * __sff) {
  ui.setupUi(this);
  parent = _parent;
  _sff = __sff;
  this->initPaletteSection();
  
  
  connect(ui.btnOk, SIGNAL( clicked() ), this, SLOT( slotOk() ) );
  connect(ui.btnHelp, SIGNAL( clicked() ), this, SLOT( slotQuickHelp() ) );
  connect(ui.btnEditUsedPal, SIGNAL( clicked() ),this, SLOT( slotEditUsedPal() ) );
  connect(ui.btnRemove, SIGNAL( clicked() ), this, SLOT( slotRemoveExtraPaletteSelection() ) );
  connect(ui.btnReduce5bit, SIGNAL( clicked() ), this, SLOT( slotReduce5bit() ) );
  connect(ui.btnAdd, SIGNAL( clicked() ), this, SLOT( slotAddExtraPalette() ) );
  
  connect(ui.listExtraPal, SIGNAL( currentRowChanged(int) ), this, SLOT( slotManageEnableRemove(int) ) );
  connect(ui.tableUsedPal, SIGNAL( currentCellChanged(int, int, int, int) ), this,
          SLOT(slotManageEnableEdit(int, int, int, int) ) );
}


void DlgPalSection::initPaletteSection() {
  somethingChanged = false;
  //part 1: set <PalData> extraPal and <PalData> tablePal
  for(int a = 0; a < parent->sff->paldata.count(); a++) {
	SffPal tmp = parent->sff->paldata[a];
	tmp.reserved = a;
    if(tmp.isUsed == true) tablePal.append(tmp);
    if(tmp.isUsed == false) extraPal.append(tmp);
  }
  //part 2: set <List> extrapal
  for(int a = 0; a < extraPal.count(); a++) {
    QString tmpstr = QString ("%1, %2") .arg(extraPal[a].groupno) .arg(extraPal[a].itemno);	  
    ui.listExtraPal->addItem(tmpstr);
  }
  //part 3: set <Table> tablePal
  ui.tableUsedPal->setRowCount(tablePal.count());
  for(int a = 0; a < tablePal.count(); a++) {
	QString tmp; tmp = QString ("%1, %2") .arg(tablePal[a].groupno) .arg(tablePal[a].itemno);
    QTableWidgetItem * itemA = new QTableWidgetItem(tmp);
    { int b, c, k;
      k = tablePal[a].usedby;
      b = parent->sff->sffdata[k].groupno;
      c = parent->sff->sffdata[k].imageno;
      tmp = QString ("%1, %2") .arg(b) .arg(c);
    }
    QTableWidgetItem * itemB = new QTableWidgetItem(tmp);
    ui.tableUsedPal->setItem(a, 0, itemA);
    ui.tableUsedPal->setItem(a, 1, itemB);
  }
}


void DlgPalSection::slotManageEnableRemove(int val) { //will work also for "Reduce 5bit" button
  if(val >=0) { ui.btnRemove->setEnabled(true); ui.btnReduce5bit->setEnabled(true); }
  if(val < 0) { ui.btnRemove->setEnabled(false); ui.btnReduce5bit->setEnabled(false); }
}


void DlgPalSection::slotManageEnableEdit(int val, int un1, int un2, int un3) {
  Q_UNUSED(un1);Q_UNUSED(un2);Q_UNUSED(un3);
  if(val >=0) ui.btnEditUsedPal->setEnabled(true);
  if(val < 0) ui.btnEditUsedPal->setEnabled(false);
}


void DlgPalSection::slotAddExtraPalette() {
  QStringList filenames = QFileDialog::getOpenFileNames(this, tr("Load Pal"), QString::null,
                          tr("Supported Palette/Image formats (*.pal *.act *.png *.pcx *.bmp)"));
  if(filenames.count() > 0) {
    DlgPalSection__sd * sd = new DlgPalSection__sd(this, filenames); //first constructor: Add Extra Pal
    sd->setAttribute(Qt::WA_DeleteOnClose);
    sd->show();
  }
}


void DlgPalSection::slotRemoveExtraPaletteSelection() {
  //step 1: re-update "reserved" values in extraPal and tablePal 
  int idremoved = extraPal[ui.listExtraPal->currentRow()].reserved;
  for(int a = 0; a<extraPal.size(); a++) {
	if(extraPal[a].reserved > idremoved) extraPal[a].reserved--;	
  }
  for(int a = 0; a<tablePal.size(); a++) {
	if(tablePal[a].reserved > idremoved) tablePal[a].reserved--;	
  }
  
  //step 2: re-update IMG.palindex of images that uses palindex > idremoved
  for(int a = 0; a<parent->sff->sffdata.size(); a++) {
    if(parent->sff->sffdata[a].palindex >= idremoved) parent->sff->sffdata[a].palindex --;	  
  }
  
  //step 3: delete item
  extraPal.removeAt(ui.listExtraPal->currentRow());
  QListWidgetItem * item;
  item = ui.listExtraPal->takeItem(ui.listExtraPal->currentRow());
  delete item;
  ui.listExtraPal->setCurrentRow(-1);
  
  //step 4: somethingChanged
  somethingChanged = true;
}


void DlgPalSection::slotReduce5bit() {
  QMessageBox msgBox;
  msgBox.setIcon(QMessageBox::Question);
  msgBox.setText(tr("If you continue, the selected palette will be reduced to a 5bit (32 colors) palette, discarding any color from index 32 to index 255. Are you sure that you want to continue?") );
  msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
  msgBox.setDefaultButton(QMessageBox::No);
  int ret = msgBox.exec();
  switch (ret) {
   case QMessageBox::Yes: { extraPal[this->ui.listExtraPal->currentRow()].pal.resize(32); 
                            break; }
  }	
}


void DlgPalSection::slotEditUsedPal() {
  int index = ui.tableUsedPal->currentRow();
  int val = tablePal[index].groupno;
  DlgPalSection__sd * sd = new DlgPalSection__sd(this, index, val); //second constructor: Edit Table Pal
  sd->setAttribute(Qt::WA_DeleteOnClose);
  sd->show();
}


void DlgPalSection::slotQuickHelp() {
  QMessageBox::information(this, tr("Quick Help"), tr("(*) \"Extra Palettes\" is the editable section. It is for Sffv2 Characters and to insert alternate colors\n"
                "\"Extra Pals\" not used in Sffv1 and have effect only character\n"   
                "Typically is palette 1,x where x is a value from 2 to 6. This becouse palette 1,1 is particular (see documentation)\n"
                "Palette 1,1 is a used pal and, in the same time, it is used as color 1 of chars in Sffv2\n"
                "You can Add one or more extra palettes in the same time and load them from Palette (*.pal, *.act) or Image (*.png, *.pcx, *.bmp)\n"
                "You can select one element and remove it from list using \"Remove\" Button\n\n"
                "(**) \"Palette Used...\" is a list created automaticly by Nomen. When you import an image, Nomen will see if the palette of the image is already present or not, and if new it will be added in this list\n"
                "The table shows the \"palno, itemno\" for used palettes (Nomen automaticly create values if from sffv1)\n"
                "You can see also the \"groupno, imageno\" of the first image that uses this palette. Typically, for palette 1,1 first image should be 9000,0 or 0,x - where x can be any value\n"
                "Tipically you don't need do do nothing in this section (managed directly by Nomen) but, seeing how important is that palette 1,1 is associated correctly, you can edit the \"groupno, itemno\" of a palette inserted here\n"
                "This can be useful if palette 1,1 is associated wrongly. See documentation for more details\n\n"
                "Note: When Opening this window the \"Remove Selection\" and the \"Edit Selected Palno\" buttons are disabled\n"
                "      To enable \"Remove Selection\" you must select one element from \"Extra Palettes\". \"Remove Selection\" will remove the selected item\n"
                "      To enable \"Edit Selected Palno\" you must select one element from \"Palette Used...\". \"Edit...\" will allow you to edit the groupno of the palette showed in the row of the actual selected cell" ));
}


void DlgPalSection::slotOk() {
  if(somethingChanged==true) {
	parent->sff->isSaved = false;
	parent->sff->paldata.clear();
	for(int a=0; a< (extraPal.size() + tablePal.size()); a++) {
	  SffPal tpal; parent->sff->paldata.append(tpal); //add empty pals for replace them	
    }
    for(int a=0; a<extraPal.size(); a++) {
	  int val = extraPal[a].reserved;
	  extraPal[a].reserved = -1;
	  parent->sff->paldata[val] = extraPal[a];    
    }
    for(int a=0; a<tablePal.size(); a++) {
	  int val = tablePal[a].reserved;
	  tablePal[a].reserved = -1;
	  parent->sff->paldata[val] = tablePal[a];    
    }
  }
  this->accept();
}

