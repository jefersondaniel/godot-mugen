/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#ifndef SFF_DLG_PALETTE_SECTION_H
#define SFF_DLG_PALETTE_SECTION_H
 

#include "../SffWidget.h"
#include "ui_dlgPaletteSection.h"


//! The palette Section Dialog
class DlgPalSection : public QDialog
{
    Q_OBJECT
    
private:
    void initPaletteSection();
    
public:
    SffWidget * parent;
    
public:
    QList<SffPal> extraPal; //"extra" pals list
    QList<SffPal> tablePal; //"used" pals list
    Sff * _sff;
    bool somethingChanged;

public:
    Ui::DlgPalSectionDLG ui;
    DlgPalSection(SffWidget * _parent, Sff * __sff);
    
public slots:
    void slotOk();
    void slotAddExtraPalette();
    void slotRemoveExtraPaletteSelection();
    void slotReduce5bit();
    void slotEditUsedPal();
    void slotQuickHelp();
    
private slots:
    void slotManageEnableRemove(int val); //will work also for "Reduce 5bit" button
    void slotManageEnableEdit(int val, int un1, int un2, int un3);

};

#endif

