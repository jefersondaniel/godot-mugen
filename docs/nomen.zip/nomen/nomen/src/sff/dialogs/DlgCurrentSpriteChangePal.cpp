

#include "DlgCurrentSpriteChangePal.h"
#include "../nomenSffFunctions.h"
#include <QFileDialog>


DlgCurrentSpriteChangePal::DlgCurrentSpriteChangePal(SffWidget * _parent, int _palid) {
  parent = _parent;
  palid = _palid;
  ui.setupUi(this);
  QString text = QString("<h1><b>Warnings:</b></h1>\n\nWarning</b>: any modification will be applied <b><u>NOT ONLY</u></b> to the current image, but also to all other images that shares the same palette configuration\n");
  text.append("(for example if the current image has palette 1,1 any modification will be applied to ALL images that use palette 1,1)\n\n");
  text.append("There two different kind of operations you can do here: 1) Apply Alternate Pal (2) Change Pal Configuration\n\n");
  text.append("<h1><b>Choice 1) Apply Alternate Pal</b1></h1>\n\n");
  text.append("With \"Apply Alternate Pal\" (default choice) you can select one of alternate palettes for that palette group. Alternate palettes <b>MUST</b> be present in current palette list. If not you must quit here and use \"Palette Section\" in order to add extra Palettes\n\n");
  text.append("Note: with \"Apply Alternate Pal\" you are <b>NOT</b> changing images but you will ask Nomen to show you images with a different color from available ones\n");
  text.append("Note: if you change palette from \"Apply Alternate Pal\" this can be effect if you are trying to extract images (untested)\n\n\n");
  text.append("<h1><b>Choice 2) Change Pal Configuration</b1></h1>\n\n");
  text.append("With \"Change Pal Configuration\" you will be able to load another palette configuration from a supported file (*.pal, *.act, *.png, *.bmp, *.pcx) and change palette setting\n");
  text.append("unlike before with this option <b>YOU WILL CHANGE THE IMAGE(s)</b>. So... In this way you will do the same operation of \"Palette Section->Edit Used Pal->Edit Pal Setting\n");
  text.append("this operation can be useful in some case when images with palette 1,1 appear weird (if you loaded an SffV1) becouse you will be allowed to apply a different pal from another file (for example: from act palette)\n\n");
  text.append("Note: if you don't load any file OR if you encontering any problem during loading NO CHANGE will be done\n");
  text.append("Note: if you loaded a file, the change will be applied immediately and this dialog will be closed");
  
  ui.infos->setText(text);
  ui.groupBox_3->setTitle("");
  ui.btnOpenFile->setVisible(false);
  this->setList();
  
  connect(ui.raApply, SIGNAL( clicked() ), this, SLOT( slotCheckRadio() ) );
  connect(ui.raChange, SIGNAL( clicked() ), this, SLOT( slotCheckRadio() ) );
  connect(ui.btnApply, SIGNAL( clicked() ), this, SLOT( slotApplyAlternate() ) );
  connect(ui.btnOpenFile, SIGNAL( clicked() ), this, SLOT( slotOpenPalFile() ) );
}


void DlgCurrentSpriteChangePal::setList() {
  int palgroup = parent->sff->paldata[palid].groupno;
  for(int a = 0; a < parent->sff->paldata.size(); a++) {
    if(parent->sff->paldata[a].groupno == palgroup) {
	  values.append(a);
	  QString tmp = QString("Pal %1,%2") .arg(palgroup) .arg(parent->sff->paldata[a].itemno);
	  ui.comboBox->addItem(tmp);
    }	  
  }
}


void DlgCurrentSpriteChangePal::slotCheckRadio() {
  if(ui.raApply->isChecked() == true) {
	ui.groupBox_2->setTitle(tr("Choose Alternate Pal"));
	ui.comboBox->setVisible(true);
	ui.btnApply->setVisible(true);
    ui.groupBox_3->setTitle("");
    ui.btnOpenFile->setVisible(false);
  }
  else {
	ui.groupBox_2->setTitle("");
	ui.comboBox->setVisible(false);
	ui.btnApply->setVisible(false);
    ui.groupBox_3->setTitle(tr("Open new Pal config"));
    ui.btnOpenFile->setVisible(true);
  }	
}


void DlgCurrentSpriteChangePal::slotApplyAlternate() {
  int newpalid = values[ui.comboBox->currentIndex()];
  for(int a = 0; a < parent->sff->sffdata.size(); a++) {
    if(parent->sff->sffdata[a].palindex == palid) {
      parent->sff->sffdata[a].image.setColorTable(parent->sff->paldata[newpalid].pal);
    }	  
  }
  parent->refreshScene();
  this->accept();	
}


void DlgCurrentSpriteChangePal::slotOpenPalFile() {
  QString filename = filename = QFileDialog::getOpenFileName(this, tr("Load Pal"), QString::null,
                          tr("Supported Palette/Image formats (*.pal *.act *.png *.pcx *.bmp)"));
  if(filename != "") {
    QVector <QRgb> palette;
    if(filename.endsWith(".act")==true) palette = nomenLoadPal_act(filename);
	else if(filename.endsWith(".pal")==true) palette = nomenLoadPal_pal(filename);
	else if(filename.endsWith(".bmp")==true || filename.endsWith(".pcx")==true || 
	   filename.endsWith(".png")==true) {
	      QImage img(filename);
	      palette = img.colorTable();
    }
    
    if(palette.size() > 0) {
	  for(int a = 0; a < parent->sff->sffdata.size(); a++) {
	    if(parent->sff->sffdata[a].palindex == palid) parent->sff->sffdata[a].image.setColorTable(palette);
      }
      parent->sff->paldata[palid].pal = palette;
      parent->refreshScene();
	  this->accept();
    }//end if palette.size > 0
  }//end if filename != ""
}

