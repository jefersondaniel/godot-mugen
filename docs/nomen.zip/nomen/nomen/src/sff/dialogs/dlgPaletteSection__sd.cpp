/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/
 
#include "dlgPaletteSection__sd.h"
#include "../nomenSffFunctions.h"
#include <QMessageBox>
#include <QImage>
#include <QFileDialog>


DlgPalSection__sd::DlgPalSection__sd(DlgPalSection * _parent, int _itemid, int startvalue) {
  //first type of call: the window will be Edit Table Pal
  this->setWindowTitle(tr("Edit selected pal"));
  filelist.clear();
  parent = _parent;
  itemid = _itemid;
  this->commonInit();
  btnChangePal->setEnabled(true);
  spin->setValue(startvalue);
  connect(btnOk, SIGNAL( clicked() ), this, SLOT( slotEditTablePal() ) );
  connect(btn5bit, SIGNAL( clicked() ), this, SLOT( slot5bit_caseEditTable() ) );
  connect(btnChangePal, SIGNAL( clicked() ), this, SLOT( slotChangePal_TablePal() ) );
}


DlgPalSection__sd::DlgPalSection__sd(DlgPalSection * _parent, QStringList _filelist) {
  //second type of call: the window will be Add Extra Pal
  this->setWindowTitle(tr("Step 2/2: Select Pal Groupno to use "));
  filelist = _filelist;
  filelist.sort(); //order in alphabetic order
  parent = _parent;
  this->commonInit();
  itemid = -1; //unused by Add Extra Pal
  connect(btnOk, SIGNAL( clicked() ), this, SLOT( slotAddExtraPal() ) );
  connect(btn5bit, SIGNAL( clicked() ), this, SLOT( slot5bit_caseAdd() ) );
}


void DlgPalSection__sd::commonInit() {
  is5bit = false;
  this->resize(323, 136);
  btnOk = new QPushButton(this);
  btnOk->setGeometry(QRect(200, 100, 101, 23));
  btnOk->setText(tr("&Ok"));
  btnCancel = new QPushButton(this);
  btnCancel->setGeometry(QRect(20, 100, 101, 23));
  btnCancel->setText(tr("&Cancel"));
  label = new QLabel(this);
  label->setGeometry(QRect(20, 20, 121, 16));
  label->setText(tr("Palette(s) group no:"));
  spin = new QSpinBox(this);
  spin->setGeometry(QRect(136, 20, 56, 22));
  spin->setRange(0, 9999);
  spin->setValue(1);
  btnChangePal = new QPushButton(this);
  btnChangePal->setGeometry(QRect(210, 20, 91, 23));
  btnChangePal->setText(tr("Change Pal"));
  btnChangePal->setEnabled(false);
  btn5bit = new QPushButton(this);
  btn5bit->setGeometry(103,60,121,23);
  btn5bit->setText(tr("Convert to 5bit"));
  
  connect(btnCancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
}


QVector<QRgb> DlgPalSection__sd::loadPal(QString & filename) {
	QVector<QRgb> palette;
	if(filename.endsWith(".act")==true) palette = nomenLoadPal_act(filename);
	if(filename.endsWith(".pal")==true) palette = nomenLoadPal_pal(filename);
	if(filename.endsWith(".bmp")==true || filename.endsWith(".pcx")==true || 
	   filename.endsWith(".png")==true) {
	      QImage img(filename);
	      palette = img.colorTable();
    }
    return palette;
}


void DlgPalSection__sd::slot5bit_caseAdd() {
  QMessageBox msgBox;
  msgBox.setIcon(QMessageBox::Question);
  msgBox.setText(tr("If you continue, the palettes you are trying to load will be stored as 5bit (32 colors) palettes, discarding any color from index 32 to index 255. Are you sure that you want to continue?"));
  msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
  msgBox.setDefaultButton(QMessageBox::No);
  int ret = msgBox.exec();
  switch (ret) {
   case QMessageBox::Yes: {  is5bit = true; break; }
  }
}


void DlgPalSection__sd::slot5bit_caseEditTable() {
  QMessageBox msgBox;
  msgBox.setIcon(QMessageBox::Question);
  msgBox.setText(tr("If you continue, the palette %1, %2 will be reduced to a 5bit (32 colors) palette, discarding any color from index 32 to index 255. Are you sure that you want to continue?") 
                    .arg(parent->tablePal[itemid].groupno) .arg(parent->tablePal[itemid].itemno) );
  msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
  msgBox.setDefaultButton(QMessageBox::No);
  int ret = msgBox.exec();
  switch (ret) {
   case QMessageBox::Yes: { parent->tablePal[itemid].pal.resize(32); break; }
  }
}


void DlgPalSection__sd::slotAddExtraPal() {
  QList <int> usedval; usedval.clear();
  QList <SffPal> listpal;
  int reserved = parent->extraPal.size() + parent->tablePal.size(); //internal "reserved" value start with the first id free. Than will be incremented for every item entered
  	
  for(int a = 0; a < parent->extraPal.size(); a++) { //check for used itemno in group selected. Checking extrapals
    if(parent->extraPal[a].groupno == spin->value()) usedval.append(parent->extraPal[a].itemno);
  }
  for(int a = 0; a < parent->tablePal.size(); a++) { //check for used itemno in group selected. Checking tablepals
    if(parent->tablePal[a].groupno == spin->value()) usedval.append(parent->tablePal[a].itemno);
  }
	
  for(int a=0; a<filelist.count(); a++) { //creating a templist 
	SffPal tpal;
    tpal.groupno = spin->value(); //groupno is the selected one
	tpal.reserved = -1; //will be assigned later if the palette is new
    tpal.itemno = -1; //will be assigned later if the palette is new
	tpal.isUsed = false; tpal.usedby = -1;
	tpal.pal = this->loadPal(filelist[a]);
	if(is5bit == true) tpal.pal.resize(32);
	listpal.append(tpal);
  }
  
  //verify if palettes are already present and if not assign the value for listpal[a].itemno (else itemno remains -1 and item will be not added becouse already existing)
  for(int a=0; a<listpal.size(); a++) {
	bool match = false;
    for(int b=0; b<parent->extraPal.size(); b++) {
	  if(nomenComparePalettes(listpal[a].pal, parent->extraPal[b].pal) == true) {
		 match = true; break;
      }
    }
    if(match == false) { //avoid to check in tablePal if pal is present in extraPal
      for(int b=0; b<parent->tablePal.size(); b++) {
	    if(nomenComparePalettes(listpal[a].pal, parent->tablePal[b].pal) == true) {
		   match = true; break;
        }
      }
    }
    if(match == false) { //if no match neither in tablePal nor in extraPal then assign "itemno" and "reserved"
	  bool itemnoFinded = false;
	  int b = 0;
	  while (itemnoFinded == false) {
	    b++; //first item to search is 1 not 0 so incremental added immediatly and not at end
	    bool itemMatch = false;
	    for(int c=0; c<usedval.size(); c++) { 
	      if(b == usedval[c]) { itemMatch = true; break; }	    
	    }
	    if(itemMatch == false) { //itemno unused value finded
		  itemnoFinded = true; //allert "while" that itemno finded. So "while loop" ends
		  usedval.append(b); //add itemno value to usedval list
		  listpal[a].itemno = b; //assign itemno to palette in list
		  listpal[a].reserved = reserved; //reserved will be the future index of this pal in SffWidget->Sff
		  reserved++; //incremental: internal reserved re-update value
	    }
      } //end while	      
    } //end itemno assignment      	  
  } //end for listpal
  
  //last: add listpal (only new items) to extraPal
  for(int a = 0; a<listpal.size(); a++) {
    if(listpal[a].itemno > -1) { 
	  parent->extraPal.append(listpal[a]);	  
	  QString tmpstr = QString("%1, %2") .arg(listpal[a].groupno) .arg(listpal[a].itemno);
	  parent->ui.listExtraPal->addItem(tmpstr);  
    }
  }
  
  //end...
  parent->somethingChanged = true; //allerts dlgPaletteSection that something is changed
  this->accept(); //close dialog
}


void DlgPalSection__sd::slotEditTablePal() {
  QList <int> usedval; usedval.clear();
  QList <SffPal> listpal;
  
  bool match = false;	
  int refGrp = spin->value();
  int refItm = parent->tablePal[itemid].itemno;
  for(int a = 0; a < parent->extraPal.size(); a++) { //check if groupno, (itemno) is already used in extrapal
    if(parent->extraPal[a].groupno == refGrp && parent->extraPal[a].itemno ==refItm) {
	  match = true; break;
    }
  }
  if(match == false) { //if pal "gruop, item" is already used in extrapal avoids check in tablepal
    for(int a = 0; a < parent->tablePal.size(); a++) { //check if groupno, (itemno) is already used in tablepal
      if(parent->tablePal[a].groupno == refGrp && parent->tablePal[a].itemno == refItm
         && a!=itemid ) { //&& a!= itemid -> avoid to check the same item you are trying to edit
	    match = true; break;
      }
    }
  }
  //search process ended. Now match has the definitive value
  if(match == true) { //case 1: "group, item" is already used so cannot proceed
    QMessageBox::warning(this, tr("WARNING!"), tr("Cannot Change selected usedpal to %1, %2\n"
                               "this groupno, itemno is already used. Try another groupno or consider to click \"Cancel\" and to left unchanged the groupno of the selected pal")
                               .arg(refGrp) .arg(refItm) );
  }
  
  if(match == false) { //case 2: "group, item" is unused: edit can be done with success
	parent->tablePal[itemid].groupno = spin->value();
	QString tmpstr = QString("%1, %2") .arg(spin->value()) .arg(parent->tablePal[itemid].itemno);
	parent->ui.tableUsedPal->itemAt(itemid,0)->setText(tmpstr);
    parent->somethingChanged = true;
    this->accept();
  }
}


void DlgPalSection__sd::slotChangePal_TablePal() {
  //this function is used only inside "Edit TablePal"  
  QString filename;
  QVector<QRgb> pal;
  filename = QFileDialog::getOpenFileName(this, tr("Load Pal"), QString::null,
                          tr("Supported Palette/Image formats (*.pal *.act *.png *.pcx *.bmp)"));
  if(filename != "") {
    pal = this->loadPal(filename);
    if(pal.size() > 0) {
	  parent->tablePal[itemid].pal = pal;
      for(int a = 0; a < parent->_sff->sffdata.size(); a++) {
	    if(parent->_sff->sffdata[a].palindex == parent->tablePal[itemid].reserved) {
	      parent->_sff->sffdata[a].image.setColorTable(pal);	  
        }
      }
      parent->parent->refreshScene();
    } //end if pal.size() > 0
  } //end if filename != ""
               
}

