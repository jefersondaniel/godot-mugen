/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#ifndef SFF_DLG_PALETTE_SECTION___SUBDIALOGS_H
#define SFF_DLG_PALETTE_SECTION___SUBDIALOGS_H
 

#include "dlgPaletteSection.h"

#include <QDialog>
#include <QLabel>
#include <QSpinBox>
#include <QPushButton>
#include <QHBoxLayout>
#include <QStringList>


//! The sub-dialogs of Palette Section (Add Extra Palettes or Edit Used Palette)
class DlgPalSection__sd : public QDialog
{
    Q_OBJECT
    
private:
    DlgPalSection * parent;
    QStringList filelist;
    void commonInit();
    QVector<QRgb> loadPal(QString & filename);

private:
    QLabel * label;
    QSpinBox * spin;
    QPushButton * btnOk;
    QPushButton * btnCancel;
    QPushButton * btn5bit;
    QPushButton * btnChangePal;
    
private:
    int itemid; //used only by Edit tablePal Item
    bool is5bit;

public:
    //! This constuctor is called if dialog is "Add Palettes"
    DlgPalSection__sd(DlgPalSection * _parent, QStringList _filelist);
    //! This constructor is called if dialog is "Edit Used Palette"
    DlgPalSection__sd(DlgPalSection * _parent, int _itemid, int startvalue);
    
private slots:
    void slot5bit_caseAdd(); //button 5bit. Case: Add Palettes
    void slot5bit_caseEditTable(); //button 5bit. Case: Edit Tablepal
    void slotEditTablePal();
    void slotAddExtraPal();
    void slotChangePal_TablePal(); //button "Edit Pal". Case: Edit Tablepal
};

#endif

