/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/
 
#include "dlgAddImage.h"
#include "../nomenSffFunctions.h"
#include <QMessageBox>


dlgAddImage::dlgAddImage(SffWidget * _parent, QStringList _filelist, int _insertTo) {
  parent = _parent;
  filelist = _filelist;
  insertTo = _insertTo;
  filelist.sort(); //order in alphabetic order  
  ui.setupUi(this);
  
  if(parent->ui.imgscroll->value() == 0) {
    ui.groupBox->setVisible(false);
    ui.radioAfter->setChecked(false);
    ui.radioBefore->setChecked(true); insertTo++;
  }
  
  connect(ui.btnOk, SIGNAL( clicked() ), this, SLOT( slotOk() ) );
}


void dlgAddImage::slotOk() {
  if(ui.radioBefore->isChecked()==true) insertTo--;
  int newPals = 0;
  for(int a=0; a<filelist.count(); a++) {
	bool thereIsNewPal = false;
    QImage img(filelist[a]);
    SffPal sffpal; sffpal.pal = img.colorTable();
    sffpal.groupno = parent->sff->paldata.size() +1; sffpal.itemno = 0;
    SffData item; item.image = img;
    //step 1: match for paldata. If compared paldata is shorter than image paldata ->
    //                           comparison will be true if colors in compared paldata and
    //                           the relative colors in image paldata matches
    //                           If compared paldata is longer than no match
    {
      bool match=false; int b=0;
      for(b=0; b<parent->sff->paldata.size(); b++) { //check all palettes
	    if(parent->sff->paldata[b].pal.size() <= sffpal.pal.size()) { 
		  //compare palettes only if compared paldata shorter or equal than image paldata
		  if(nomenComparePalettes(parent->sff->paldata[b].pal, sffpal.pal) == true) {
		    match = true; break;	  
          }
	    }
      }
      if(match==true) { 
	      item.palindex = b; //if palette matches than palette recognized
	      if(parent->sff->paldata[item.palindex].isUsed == false) {
		    parent->sff->paldata[item.palindex].isUsed = true;
	      }    
      }
      if(match==false) {
	    //if no match -> heuristic add palette 
	    thereIsNewPal = true; //will mark the fact that a new palette is reading to be inserted in parent->sffpal
	    QList <int> palgroups = parent->sff->usedPalGroups();
	    b = 1; bool is_used = true;
	    while(is_used==true) {
		  is_used=false;
		  for(int k = 0; k < palgroups.count(); k++) {
			if(b==palgroups[k]) { is_used=true; b++; break; }  
	      }    
	    }
	    sffpal.groupno = b; sffpal.itemno = 1; sffpal.isUsed = true;
	    //sffpal.usedby will be setted later
	    item.palindex = parent->sff->paldata.count(); //new sffpal is not already added in this point 
	      //but the image will use the new sffpal, so palindex = number of palettes (= last index of 
	      //    paldata when the new sffpal will be added
      }
    }
    
    //Step 2: match for image group. If it is used there will be two cases:
    //        if you are trying to add a single image, image will be added at the first group,image free
    //        if you are trying to add multiple images, than images will be added to tmp groupno = -1 and a warning will be displayed  
    
    {
	   if(filelist.count() == 1) {
	     bool used = true; int k = 0;
		 while(used == true) {
		   if(parent->sff->searchItem(ui.spinBox->value(), k) == -1) { used=false; }
		   else k++;
	     }
	     item.groupno = ui.spinBox->value(); item.imageno = k;
	   }
	   if(filelist.count() > 1) {
		 item.groupno = ui.spinBox->value(); item.imageno = a;
	     if(parent->sff->searchItem(ui.spinBox->value()) != -1) {
		   //if group is already used show a warning message and apply temporary groupno = -1
		   if(a==0) {
		     //effect applied only one-time-only. After: cuncatenation
		     QMessageBox::warning(this, tr("WARNING!"), tr("Group %1 is already used!\n Images will be stored as group = -1 and YOU MUST change groupno manually for that images after they been added!") 
		                                .arg(ui.spinBox->value()) );
		     item.groupno = -1; ui.spinBox->setMinimum(-1); ui.spinBox->setValue(-1);
	       }    
	     }
       }    
    }
    
    //Step 3:  Define missing parameters for "item" (x, y, linked) and add item in sffdata
    item.x = 0; item.y = 0; item.linked = -1;
    parent->sff->sffdata.insert(insertTo, item);
    
    //Step 4: if New Palette, than add it in paldata
    if(thereIsNewPal == true) {
	  parent->sff->paldata.append(sffpal); newPals++;
    }
    
    //Step 5: update imgscroll.maximum and update insertTo value for next image add
    parent->ui.imgscroll->setMaximum( parent->ui.imgscroll->maximum() +1);
    if(parent->ui.imgscroll->minimum() ==0) parent->ui.imgscroll->setMinimum(1);
    insertTo++;
  }
  
  //Images are added.
  //Step6: re-update usedby paldata values
    //6A: mark used pals (PAL.isUsed == true) with PAL.reserved = -5
    for(int a=0; a < parent->sff->paldata.size(); a++) {
	  if(parent->sff->paldata[a].isUsed == true) parent->sff->paldata[a].reserved = -5; //-5 marks that it is an usedby - unassigned
    }
    //6B: re-assign usedby values. PAL.reserved = -5 marks unassigned usedby values for used pals
    for(int a=0; a < parent->sff->sffdata.size(); a++) {
  	  int actualPal = parent->sff->sffdata[a].palindex;
  	  if(parent->sff->paldata[actualPal].reserved == -5) {
	    parent->sff->paldata[actualPal].reserved = -1;
	    parent->sff->paldata[actualPal].usedby = a; 	  
      }
    }
    
  //Now final step
  //Step7: check the first image and update imgscroll.value (so le_scroll will be updated itself)
  parent->sff->isSaved=false; 
    //case A: images inserted Before
    if(ui.radioBefore->isChecked()==true) {
	  int k = parent->ui.imgscroll->value();
	  parent->ui.imgscroll->setValue(k +1); //this "wrong value" pre-setted is needed. In this way SffWidget will call slotScrollImage
	  parent->ui.imgscroll->setValue(k);
    }
    //case B: images inserted After
    if(ui.radioAfter->isChecked()==true) {
	  int k = parent->ui.imgscroll->value() +1;
	  parent->ui.imgscroll->setValue(k);  
    }
  
  this->accept();
}

