ADD_SFF_PLUGIN(SffV2,"Sff v 2.0 - (Mugen 1.0 RC and following)")
ADD_SFF_PLUGIN(SffV1,"Sff v 1.0 - (All Mugen versions including olders)")
ADD_SFF_PLUGIN(NomSpr,"-------------- (NOMEN RESERVED FORMAT)")

