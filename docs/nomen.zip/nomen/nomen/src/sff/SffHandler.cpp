/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/
 
 
#include "SffHandler.h"
#include "SffPlugins__headers.h"
#include <QTranslator>
#include <QApplication>

/*
  Here stands the definition for select_sff_plugin_reader and select_sff_plugin_writer
  Those two functions interacts with plugins throughout "SffPlungins__headers.h" and
  "SffPluginsList.h"
  
  In "SffPlugins__headers.h" you must add the main header for every single "sff plugin"
  In "SffPluginsList.h" you must add a macro ADD_SFF_PLUGIN(class) for every single "sff plugin"
*/
 
SffHandler * select_sff_plugin_reader(QString &filename) {
  #ifdef ADD_SFF_PLUGIN
  #undef ADD_SFF_PLUGIN
  #endif
  
  #define ADD_SFF_PLUGIN(SFF_PLUGIN_CLASS, SFF_PLUGIN_DESCRIPTION) \
    { SFF_PLUGIN_CLASS * pointer = new SFF_PLUGIN_CLASS; \
      if(pointer->read(filename) == true) return pointer; \
      else delete pointer; }
      
  #include "SffPluginsList.h"
  #undef ADD_SFF_PLUGIN
  
  return NULL;
}


SffHandler * select_sff_plugin_writer(QString &filename, char sff_type) {
  QList <SffHandler *> templist; char plugin_count = 0;
  
  #ifdef ADD_SFF_PLUGIN
  #undef ADD_SFF_PLUGIN
  #endif
  
  #define ADD_SFF_PLUGIN(SFF_PLUGIN_CLASS, SFF_PLUGIN_DESCRIPTION) \
    { SFF_PLUGIN_CLASS * pointer = new SFF_PLUGIN_CLASS; \
      templist.append(pointer);plugin_count++; }
      
  #include "SffPluginsList.h"
  #undef ADD_SFF_PLUGIN
  
  SffHandler * pointer = templist[sff_type-1];
  
  for(char ch=1; ch<sff_type; ch++) delete templist[ch-1]; //remove unused pointers BEFORE chosen sff_type
  for(char ch=(sff_type+1); ch <=plugin_count; ch++) delete templist[ch-1]; //remove unused pointers AFTER chosen sff_type
  
  templist.clear(); return pointer;
}



void exec_sff_plugin_wText(QString & _snapdest, const QString & _imgf, const QString & _palf, QList<SffData> & _sffdata, QList<SffPal> & _paldata) {
  #ifdef ADD_SFF_PLUGIN
  #undef ADD_SFF_PLUGIN
  #endif
  
  #define ADD_SFF_PLUGIN(SFF_PLUGIN_CLASS, SFF_PLUGIN_DESCRIPTION) \
    { SFF_PLUGIN_CLASS * pointer = new SFF_PLUGIN_CLASS; \
      pointer->wText(_snapdest, _imgf, _palf, _sffdata, _paldata); \
      delete pointer; }
      
  #include "SffPluginsList.h"
  #undef ADD_SFF_PLUGIN
}


/*
  Here stands the definition for non-virtual functions of SffHandler class
  
  SffHandler::sffGroupCount() counts how many groups are used in sff and returns that value
*/


SffHandler::SffHandler() {
   this->removeDuplicates = true;	
}


const int SffHandler::sffGroupCount() {
  QList <int> values;
  for(int a=0; a<sffdata.size(); a++) {
	bool new_value=true;
    for(int b=0; b<values.size(); b++) {
	  if(sffdata[a].groupno == values[b]) { new_value=false; break; }
    }
    if(new_value==true) { values.append(sffdata[a].groupno); }
  }
  return values.size();	
}


void SffHandler::searchDuplicateImages() {
  for(int a = 0; a < sffdata.size(); a++) {
     for(int b = a+1; b < sffdata.size(); b++) {
	   if(sffdata[a].image == sffdata[b].image && sffdata[a].linked == -1) sffdata[b].linked = a;    
	     //&& sffdata[a].linked == -1 -> if false it avoid a re-check of a image just linked before
     }
  }
}


QString SffHandler::scanSff(bool rgbSupported) { 
  QString str; str.clear();
  for(int a = 0; a < sffdata.size(); a++) {
	 //if rgb is not supported, return an error if an Rgb Image found
	 if(rgbSupported == false) {
	   if(sffdata[a].image.format() != QImage::Format_Indexed8) {
		   
		 str = qApp->translate("SffHandler", "This sff format doesn't support Rgb Images\n\n"
		                              "Found Rgb Image at position %1 (image %2,%3)") 
		                              .arg(a+1) .arg(sffdata[a].groupno) .arg(sffdata[a].imageno);
		 return str;   
       }
     }
	 
	 //check for duplicate infos....
     for(int b = a+1; b < sffdata.size(); b++) {
	   if(sffdata[a].groupno == sffdata[b].groupno && sffdata[a].imageno == sffdata[b].imageno)
	   {
	     str = qApp->translate("SffHandler", "Two or more images with same groupno, imageno\n\n"
	                                  "Found image %1,%2 at position %3 and at position %4") 
	               .arg(sffdata[a].groupno) .arg(sffdata[a].imageno)
	               .arg(a+1) .arg(b+1); 
	     return str;
       }
     }
  }
  
  return str;
}

