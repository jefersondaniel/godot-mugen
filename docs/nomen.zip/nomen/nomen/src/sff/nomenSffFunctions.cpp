/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

//#include <QGraphicsPixmapItem>

#include "nomenSffFunctions.h"
#include <QFile>
#include <QTextStream>
#include <QDataStream>
#include <QStringList>
 

bool nomenComparePalettes(QVector<QRgb> &pal1, QVector<QRgb> &pal2) {
  bool match = true;
  quint8 r, g, b;
  quint8 r2, g2, b2;
  for(int a = 0; a<pal1.size(); a++) {
     r = qRed(pal1[a]); g = qGreen(pal1[a]); b = qBlue(pal1[a]);
     r2 = qRed(pal2[a]); g2 = qGreen(pal2[a]); b2 = qBlue(pal2[a]);
     if(r != r2 || g != g2 || b!= b2) { match = false; break; }
  }
  return match;
}


QVector<QRgb> nomenPalFiller(QVector<QRgb> &param) {
  QVector<QRgb> pal = param;
  for(int a = pal.size(); a < 256; a++) {
    pal.append( qRgb(0,255,0) );	  
  }
  return pal;	
}


//loading / saving Palettes:


QVector<QRgb> nomenLoadPal_pal(QString & filename) {
	QVector<QRgb> pal;
	QFile infile(filename);
	infile.open(QIODevice::ReadOnly | QIODevice::Text);
	QTextStream in(&infile);
	QString tmp = in.readLine(); //JASC-PAL
	if(tmp.compare(QString("JASC-PAL")) != 0) return pal;
	tmp = in.readLine(); //0100
	tmp = in.readLine(); //256 (colori palette)
	while(!in.atEnd()) {
	  tmp = in.readLine(); //R G B -> valore numerico R, G, B del colore
	  QStringList strcolor = tmp.split(" ");
	  strcolor[0] = strcolor[0].trimmed(); //remove spaces and returns
	  strcolor[1] = strcolor[1].trimmed(); 
	  strcolor[2] = strcolor[2].trimmed();
	  quint8 r = (quint8) strcolor[0].toInt();
	  quint8 g = (quint8) strcolor[1].toInt();
	  quint8 b = (quint8) strcolor[2].toInt();
	  pal.append( qRgb(r,g,b) );
    }
    infile.close();
	return pal;
}


QVector<QRgb> nomenLoadPal_act(QString & filename) {
  QVector<QRgb> pal;
  QFile infile(filename);
  infile.open(QIODevice::ReadOnly);
  QDataStream in(&infile);
  quint8 r, g, b;
   
  for(int a = 0; a < 256; a++) {
    in>>r; in>>g; in>>b;
    pal.prepend( qRgb(r,g,b) ); //act reverse the color order
  }
  infile.close();
  return pal;
}


void nomenSavePal_pal(QString & filename, QVector<QRgb> & originalParam) {
  QVector<QRgb> param = nomenPalFiller(originalParam);
  
  QFile outfile(filename);
  outfile.open(QIODevice::WriteOnly | QIODevice::Text);
  QTextStream out(&outfile);
  out<<"JASC-PAL"<<QChar(0x0d)<<QChar(0x0a);
  out<<"0100"<<QChar(0x0d)<<QChar(0x0a);
  out<<"256"<<QChar(0x0d)<<QChar(0x0a);
  quint8 r,g,b;
  for(int a = 0; a < 256; a++) { 
    r = qRed(param[a]); g = qGreen(param[a]); b = qBlue(param[a]);
    QString tmp = QString("%1 %2 %3") .arg(r) .arg(g) .arg(b);
    out << tmp << QChar(0x0d) << QChar(0x0a);
  }
  outfile.close();	
}


void nomenSavePal_act(QString & filename, QVector<QRgb> & originalParam) {
  QVector<QRgb> param;
  //param will be a "filled" reversed version of originalParam (act reverse the color order)
  {
	QVector<QRgb> p = nomenPalFiller(originalParam);
    for(int a = 0; a< 256; a++) {
      param.append(p[255-a]);
    }
  } 
  
  QFile outfile(filename);
  outfile.open(QIODevice::WriteOnly);
  QDataStream out(&outfile);
  quint8 r,g,b;
  for(int a = 0; a < 256; a++) { 
    r = qRed(param[a]); g = qGreen(param[a]); b = qBlue(param[a]);
    out << r; out << g; out << b;
  }
  outfile.close();	
  
}

