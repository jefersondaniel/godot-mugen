/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#include <QVariant>
#include "SffItem.h"



SffItem::SffItem() {
  groupno = -1; imageno = -1;
  this->setFlag(QGraphicsItem::ItemIsMovable, true);
  sffdata = NULL;
}


void SffItem::setVal(SffData * _sffdata) {
  this->sffdata = _sffdata;
  groupno = _sffdata->groupno;
  imageno = _sffdata->imageno;
  this->setIntAxis(_sffdata->x, _sffdata->y);
  this->setPixmap(QPixmap::fromImage(_sffdata->image));
}


void SffItem::setNull() {
  this->sffdata = NULL;
  groupno = 0;
  imageno = 0;
  this->setIntAxis(0,0);
  this->setPixmap(QPixmap());
}


void SffItem::mouseReleaseEvent (QGraphicsSceneMouseEvent * event) {
  QGraphicsItem::mouseReleaseEvent(event);
  int xx = this->intX();
  int yy = this->intY();
  this->setIntAxis(xx, yy);	
  this->sffdata->x = xx;
  this->sffdata->y = yy;
}

 
const int SffItem::intX() {
  QPointF point = this->pos();
  int x = (int) point.x();
  return (x * -1);
  /*QVariant var = this->x();
  return ( -1 * var.toInt() );	 */
}


const int SffItem::intY() {
  QPointF point = this->pos();
  int y = (int) point.y();
  return (y * -1);
  /*
  QVariant var = this->y();
  return ( -1 * var.toInt() );*/
}


void SffItem::setIntAxis(int xx, int yy) {
  xx = xx * -1; yy = yy * -1;
  qreal varX = (qreal) xx; qreal varY = (qreal) yy;
  this->setPos(varX, varY);
  /*xx = xx * -1; yy = yy * -1;
  QVariant varX = xx; QVariant varY = yy;
  this->setPos(varX.toReal(), varY.toReal());*/
}


void SffItem::setIntX(int xx) {
  QPointF point = this->pos();
  xx = xx * -1;
  qreal varX = (qreal) xx;
  point.setX(varX);
  this->setPos(point); 
  /*
  xx = xx * -1;
  QVariant var = xx;
  this->setX(var.toReal()); */
}


void SffItem::setIntY(int yy) {
  QPointF point = this->pos();
  yy = yy * -1;
  qreal varY = (qreal) yy;
  point.setY(varY);
  this->setPos(point); 
  /*
  yy = yy * -1;
  QVariant var = yy;
  this->setY(var.toReal()); */
}

