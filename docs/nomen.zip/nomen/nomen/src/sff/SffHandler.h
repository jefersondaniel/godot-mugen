/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#ifndef SFF_HANDLER_H
#define SFF_HANDLER_H

#include "SffItem.h"
#include <QList>
#include <QString>

/*************************************
 * Doxygen Extra Pages: 
 *
 *  - Nomen Coding Policies
 *  - Tricky SffV1 Parser
 *  - The Sff Plugin System
 *
 ************************************/

/*! \page pageNomenPolicies Nomen Coding Policies

I am not a professional programmer so I decided to adopt some coding policies that are confortable to me, regardless of the fact that they are probably not in general considered good

\section sec1NomenPolicies 1. Abuse of "public" into classes

As you can see my classes have a lot of public members even when probably was better to use "private" or "protected".
In general it is strictly NOT suggested to "abuse of public" when you write an OOP C++ program and it is generally not considered a good choice. I know it.
Now I will explain why I did this choice

First of all I will explain why in general "abusing of public" is not suggested: becouse grant access to critical members of a class to extern routines is very risky. You should avoid uncontrolled changes

But... Nomen code structure has a lot of complex cross-manipulation-system throughout modules. So seeing I am not a pro I wanted to allow myself to allow any module to comunicate to the others in the easiest way for me
I have also to add.... I am the only one developer of this program, so I know what I am doing. Even if a lot of members are public, I know WHEN and IF I must let external change or WHEN I must read-only (and in this case I am very careful about avoiding unwanted changes)

So those are the reasons why I did this choice. I don't mind if "it is not the good way to do". My objective is to create something that works and that works well, taking care of my limited skills.


\section sec2NomenPolicies 2. Code Redundancy

If you analyze well my code you will find probably a lot of Code Redundancies. For example: _sffv1_wText_file_calc(...) (plugin SffV1) and _sffv2_wText_file_calc(...) (Plugin SffV2) are identical and they have the same code internally by "Extract All" to calculate the name of every image / pal to extract.
In this particular case (redundancy inside SffHandler::wText(...)) the "Choice for Redundancy" is somewhat forced. Every plugin must be independent from the rest of the code, so it cannot inherit code from other classes (otherwhise unwanted complex cross dependencies would be created - and this is not the scope of the Plugin System that is already complex enough).
So why this choose (the "name calculation" is re-copied into an internal function - I choosed not to add in SffHandler becouse it is needed only by wText(...) and wText(...) is needed only by SffV1 and SffV2 and not nedded by other possible plugins).

You could find probably other examples of Redundancies into Nomen Code. If there are ones, probably their existance is explained by a general intention to avoid cross-dependencies througout modules
I think I will make an intensive use of Code Redundancy when I will code the "air" module becouse "Air" widget will be very different from SffWidget even if it will mantain some features exactly intact
I have to think about it, but it is very early to talk about it now
*/

/*! \page pageTrickySffV1Parser The External Tool "Tricky &SffV1 Parser"

With Nomen 0.1.1 a new (external) tool will be available: "Tricky &SffV1 Parser" (under linux: nomen-tpar)
Unlike Nomen itself, The source of "Tricky &SffV1 Parser" (from now on "the tool") will not be document deeply. Into this page I will report the most important things to know about the code of that tool"

Note about step names: if you use the tool like a normal user you will see those step numbers: 1,2,3,4 (this is the REAL values)
 if you read the sources wil will see those step numbers (if you check function names) 1, 1bis, 2, 3
 (1bis = 2; 2 = 3; 3 = 4)
 This becouse the step2 (1bis in code) was originally not present and added a very few time before official release

\section sec1TrickySffV1Parser 1. Directory Structure

"images"    : Contains the images for Zooming Buttons used by the tool (called by qrc.qrc)
"dlgcompare": The code of the Window used at step3 (called step2 in sourcecode). This will interact with formMain to determine the final Sff
"minsff"    : minimal Sff Support for the tool. In the following paragraphs we explain something about files in that directory

\section sec2TrickySffV1Parser 2. The Minimal Sff Support for the tool

The sourcecode of the tool contains a lot of files that are keeped from Nomen with some (or a lot) modifications in order to balance two opposite requirements:
1) Managing Sff coherently with Nomen structure
2) Trying to reduce Sff management complexity erasing useless features for the scope of the tool (I think about, for example, the Nomen &Sff Plugin System)

for example "frmMain" (path: /src mainpath) is similar to SffWidget used in Nomen but has a lot of differences (for example 2 Scenes instead of one, no manipulation allowed other than zooming and scrolling images, etc)

\subsection sec2sub1TrickySffV1Parser 2.1 The Files in /src/minsff

Files here mantain the same names used by the original NOMEN files that do the same job.
However here there are a lot of differences that I will briefly describe

Sff.* -> this module is changed erasing "loading", "saving" and other things related to the Plugin System or to other modules not needed by "the tool"

SffHandler.* -> This module does not contain reference to "plugin dinamic load"... so functions like "plugin reader" or includes that are referred to "plugin dinamic load" are erased here
In addition of that, SffHandler here is NOT a virtual class so DOESN'T have the virtual functions "bool read" "bool write" and "void wText"
This becouse the "plugins" are managed directly (and not dinamicly becouse here we don't need an expandible plugin system)
And also to allow a more flexyble management (infact SffV1.read() here uses 3 parameters and not only one like in Nomen)

SffItem.* -> I don't remember what changes has. Probably I removed something that is useless for "the tool"

nomenSffFunctions.* -> untouched. It is exactly like NOMEN original one. Used when one of the function defined there are needed.


\subsection sec2sub2TrickySffV1Parser 2.2 The Files in /src/minsff/SffV1

The subdirectory "SffV1" contains the class SffHandler::SffV1 and all related code
this "plugin" however is coded in a complete different way than in NOMEN. The function SffV1::read() was completely rewritten for "the tool" scopes and also requires 3 parameters instead of one only

\subsection sec2sub2TrickySffV1Parser 2.2 The Files in /src/minsff/NomSpr

The subdirectory "NomSpr" contains the class SffHandler::NomSpr
this "plugin" is (more or less) the same as the one used in Nomen. "the tool" used only the "write" function and not the "read" one
*/

/*! \page pageSffPluginSystem The SffPlugin System

Nomen can be easily expanded with different Sff formats. Seeing the fact that actually 
exist two (totally) different Sff formats I decided to create this SffPlugin System
    

\section secIntroSffPluginSystem Introduction. SffPlugin: What is it?

An &Sff Plugin is basicly a subclass of SffHandler. You need to re-implement \link SffHandler::read() bool read(QString & filename) \endlink and \link SffHandler::write() bool write(QString & filename) \endlink .

"Read" and "Write" are used by \link Sff::read() Sff::read() \endlink and \link Sff::write() Sff::write() \endlink to load (read) or save (write) the "filename" using that specify sff format that the plugin manages.
The following instruction of the page will show you the steps to create an SffPlugin


    \section sec1SffPluginSystem 1. Step1: Creating an Empty SffPlugin

     In those examples we are assuming we need to create a plugin for an Sff 3.0 (that actually doesn't exist).
    First of all we have to declare the "external" header (this header will be visible and must be the only header visible to external code)
    \code
      #ifndef _PLUGIN_SFFV3_H
      #define _PLUGIN_SFFV3_H

      class SffV3 : public SffHandler {
      public:
        bool read(QString & filename);
        bool write(QString & filename);
      };

      #endif
    \endcode
    We assume that our plugin will be called SffV3. The firsts line are the preprocessor condition. I suggest to set this macro to _PLUGIN_[CLASSNAME]_H so, in this example, the macro will be _PLUGIN_SFFV3_H
    After that we have declared SffV3 as a subclass of \link SffHandler SffHandler. \endlink
    Finally we re-declare bool read and bool write as showed before

    Now we have to write the .cpp file
    \code
      #include "../../SffHandler.h"
      #include "SffV3.h"
      //Qt included: QString, QList, QGraphicsPixmapItem

      #include <QByteArray>
      #include <QDataStream>
      #include <QFile>
      #include <QImage>

      //...
      bool SffV3::read(QString & filename) {
        //todo
        return false;
      }

      bool SffV3::write(QString & filename) {
        //todo
        return false;
      }
    \endcode

    First #include is mandatory. SffHandler is required before loading our own header
    Second #include is mandatory. You need to include the header you have created before (in our example (SffV3.h)
    QByteArray, QDataStream and QFile are includes that you almost certainly need
    QImage is mandatory

    As you can see, at this step, both "read" and "write" must return false (becouse actlually they don't work becouse empty). See \ref xxx for more details

    Note: SffPlugins must saved in /src/sff/plugins/FOLDER where FOLDER is the plugin name (in this way code is easyer to understand). So, if your plugin name is SffV3 the SffV3.cpp and SffV3.h must be saved in /src/sff/plugins/SffV3

    \section sec2SffPluginSystem 2. Step2: Make Your Plugin Visible
    In order to make your plugin visible you must follow those sub-steps
    \subsection sec2sub1SffPluginSystem 2.1. Modify "/src/sff/SffPlugins__headers.h"
    The first thing to do is to modify this file, adding the path of your plugin header
    \code
      #include "plugins/SffV1/SffV1.h"
      #include "plugins/SffV2/SffV2.h"
      #include "plugins/SffV3/SffV3.h"
    \endcode
    here we added "plugins/SffV3/SffV3.h" (the header of our new SffPlugin)


    \subsection sec2sub2SffPluginSystem 2.2. Modify "/src/sff/SffPluginsList.h"

    this file is a list of MACROS that defines the plugin list
    every SffPlugin is installed with an istruction
    \code
    ADD_SFF_PLUGIN(Plugin_Class_Name,"description")
    \endcode
    where "Plugin_Class_Name" is the Class name of our plugin (in our example will be SffV3) and "description" is the text that the "Select Sff Output Format" will show to identify that particular type of sff format
    so in our case the macro could appear like this
    \code
    ADD_SFF_PLUGIN(SffV3,"Sffv3: A New Plugin created by Me")
    \endcode
    It is important to remember that you must add only one ADD_SFF_PLUGIN for every single line and you must must terminate line WITHOUT using commas (;)
    Note: the first ADD_SFF_PLUGIN in list describes what plugin is considered the default one for saving.


    \subsection sec2sub3SffPluginSystem 2.3. Add new files to Nomen.pro

    Nomen.pro must be filled with the new file names (see where other plugins added and add your new plugin similary in that point)
    example:
    \code
      ... //find the point where is SffV2.h
      src/sff/plugins/SffV2/SffV2.h
      src/sff/plugins/SffV3/SffV3.h
    \endcode
    \code
      ... //find the point where is SffV2.cpp
      src/sff/plugins/SffV2/SffV2.cpp
      src/sff/plugins/SffV3/SffV3.cpp
    \endcode


    \section sec3SffPluginSystem 3. Final Step: Write your SffPlugin

    Finally you need to fill the reimplemented functions \link SffHandler::read() read() \endlink and \link SffHandler::write() write() \endlink that we left empty until now. There are some things to take care of when writing your own SffPlugin


    \subsection sec3sub1SffPluginSystem 3.1 General things to care of

    First of all you must remember that only read() and write() must be visible externally. If you need your own substructures or sub-functions, remember they must be visible internally only. Usually you must write all in the ".cpp" file. If you look at official Nomen plugins (SffV1 and SffV2) you probably will note some "internal..." includes. This headers are internal only. It would be the same thing if I added all code in the ".cpp" file. I decided to split code in some "internal headers" (leaving inside the ".cpp" only the functions "read" and "write") for a better readability.
    For the same reason, if you need some internal structs or functions, I suggest you to use some unique name that surely cannot conflict with other functions/classes. Official Nomen SffPlugins name functions as _pluginname_function (ex. _sffv2_lz5Decode) and structs as _PLUGINNAME_STRUCT (ex. _SFFV1_NOMEN_STRUCT) to avoid any type of risk of conflict


    \subsection sec3sub2SffPluginSystem 3.2 Things to care of in read() function

    Read function is used to load \link SffHandler::sffdata sffdata \endlink and \link SffHandler::paldata paldata \endlink (and pass them to Sff) and MUST return false in those cases:
    1) Reading File fails (for example becouse you don't have read permissions)
    2) this SffPlugin is not the right one
    The second case is also very important. So the read function MUST contain a verification of header file of Sff file you are opening. If the header contains data different than expected you must return false (see SffV1 and SffV2 code)
    In other cases you must load from your Sff the "paldata" and "sffdata" infos and return true


    \subsection sec3sub3SffPluginSystem 3.3 Things to care of in write() function

    Write function is used to save an sff file. You will use \link SffHandler::sffdata sffdata \endlink, \link SffHandler::paldata paldata \endlink and (if you need) \link SffHandler::removeDuplicates bool removeDuplicates \endlink passed from Sff. You can use those infos to write your own Sff file.
    Write must return false in those cases
    1) Writing File fails (for example becouse you don't have write permissions)
    2) Sff File you are trying to save contains error
    The second case happens when the Sff Contains more than an image with same groupno, imageno. You can use \link SffHandler::scanSff this->scanSff(bool) \endlink

    SffV1 and SffV2 contains also this control check.
    If you don't encounter those cases, than you can write your Sff file (and, at the end, you must return true)
    
    \subsection sec3sub4SffPluginSystem 3.4 the optional wText(...) function

    As showed before, when writing a plugin (i.e. a class derived from SffHandler) you MUST reimplement "bool read" and "bool write"
    There is another virtual function you CAN reimplement (unlike read() and write() this one is NOT mandatory): the function wText(...)
    This function should be useful only for the (already existing) SffV1 and SffV2 plugins (becouse currently it has sense only to allow to use "sprmaker" or "sprmake2"
    In order to have some details more about this function you are invited to read the documentation about wText(...) [class SffHandler]
*/



/*****************************************************************************
 *  END OF DOXYGEN EXTRA-PAGES
 * ------------------------------------------------------------
 *  HERE STARTS THE REAL SffHandler CLASS (including doxygen documentation)
 ****************************************************************************/



/*
class SffHandler is the pure virtual class to subclass for reading sff 
files throughout "sff plugins".
  
Every "sff plugin" is a subclass of SffHandler.

For details about select_sff_plugin_reader and select_sff_plugin_writer
see "SffHandler.cpp" for more details about them
*/
//! Class that defines an Sff_Plugin
/*!
   \sa \ref pageSffPluginSystem 
   \sa \ref pageNomenPolicies
*/
class SffHandler {
  public:
    SffHandler();
    //! sprite list to load with PLUGIN or to save from SFF
    QList<SffData> sffdata;
    //! pal list to load with PLUGIN or to save from SFF
    QList<SffPal> paldata;
    //! used by PLUGIN::write to mark if linking images or not during Sff saving process
    bool removeDuplicates;
    
  public:
    //! pure virtual function. Must be reimplemented in your own SffPlugin
    /*!
       \sa \ref pageSffPluginSystem
       
    */
    virtual bool read(QString & filename) = 0;
    //! pure virtual function. Must be reimplemented in your own SffPlugin
    /*!
       \sa \ref pageSffPluginSystem
    */
    virtual bool write(QString & filename) = 0; 
    
    //! virtual function. Can be reimplemented if needed. By default does nothing
    /*!
       Introduced in version 0.1.1
       this function will receive from "frmMain" some informations you need in order to know IF you can write the txt file for PLUGIN and WHERE to write it
       
       Note about Code Reduncancy: if you use this function remember you must re-use (copy) the same code use by "frmMain->ExtractAll" in order to know filenames of every sprite/palette
       This is a sort of forced Code Redundancy. Read about "Code Redundancy" into the "Nomen Coding Policies"
       
       Here some details about informations passed by "frmMain" (or better: passed by exec_sff_plugin_wText(...) used by frmMain)
              
       @param snapdest Path where to save the Text file (example .../snap/KFM)
       @param imgf image format choosed by "Extract All". Can be "pcx", "png" or "bmp"
       @param palf palette format choosed by "Extract All". Can be "PalAct", "pal" or "act"
       @param _sffdata keeps "sffdata" infos from frmMain->Sff
       @param _paldata keeps "paldata" infos from frmMain->Sff
       
       Note: "imgf" and "palf" are important to know IF you can produce that txt (for example DON'T produce SffV1.txt if imgf != "pcx")
       Note: "imgf" is also important to know extensions used by image files (useful for SffV2.txt that can refers to PCX or PNG images) 
       \sa \ref pageSffPluginSystem
    */
    virtual void wText(QString & snapdest, const QString & imgf, const QString & palf, QList<SffData> & _sffdata, QList<SffPal> & _paldata) {
	  Q_UNUSED(snapdest); Q_UNUSED(imgf); Q_UNUSED(palf); Q_UNUSED(_sffdata); Q_UNUSED(_paldata);   
    }
    
  public:
    //! returns how many different groupno used in sff (useful only for sffv1 at the moment)
    const int sffGroupCount();
    QList<int> usedPalGroups();
    //! Checks for duplicate images. Actually used only by sffv2 (sffv1 has a different internal function for the same work)
    void searchDuplicateImages();
    //! Check Sff for errors (for example if two or more images with same groupno, imageno)
    /*!
       @param rgbSupported set to true only if your Sff format supports Rbg Images. If your Sff format doesn't support Rgb Images set it to false.
       \return a QString value corresponding to error message. Empty if no errors.
    */
    QString scanSff(bool rgbSupported);
};

//! Selects the SffPlugin reader to Use
/*! \relates Sff
   This function is used internally by Sff::read()
   \return a pointer to the plugin selected
   \sa \ref pageSffPluginSystem
*/
SffHandler * select_sff_plugin_reader(QString &filename);

//! Selects the SffPlugin writer to Use
/*! \relates Sff
    This function is used internally by Sff::write()
   \return a pointer to the plugin selected
   \sa \ref pageSffPluginSystem
*/
SffHandler * select_sff_plugin_writer(QString &filename, char sff_type = 1);

//! Manage all SffPlugin(s) wText() function (to extract txt during "extract all")
/*! \relates Sff
    This function is used internally by "extract_all" (mainwindow -> extract all)
    @param _snapdest mainwindow must pass here where the images (and the text) will be extracted (complete path)
    @param _imgf mainwindow must say what image format is used for saving (possible values: pcx, png, bmp)
    @param _palf mainwindow must say what pal format is used for palette extract (possible values: palact, pal, act)
   \sa \ref pageSffPluginSystem
*/
void exec_sff_plugin_wText(QString & _snapdest, const QString & _imgf, const QString & _palf, QList <SffData> & _sffdata, QList <SffPal> & _paldata);


#endif

