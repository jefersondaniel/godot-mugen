libpcx library
-----------------------

libpcx is a stand-alone version of the "pcx.cpp" and "pcx.h" components of kdelibs4.
"pcx.cpp" and "pcx.h" of libpcx are a little different than the original version contained in kdelibs4
This to allow to make a stand-alone plugin that doesn't require to use other components of kdelibs4.

This is usefull for the windows (and probably for mac?) version of N.E.M.O.
Infact, while kdelibs is used normally on linux, it is not the same for windows 
(even if exists a windows port of the kdelibs).

So it could be not clever to add a dependency (in windows) to kdelibs only to add a support for PCX.
It would be an useless vaste of resource.

So why this stand-alone (static) version of libpcx "made" by me 

however, for a unix (linux) application it is better to dynamic link against kdelibs4. 
Kdelibs4 is used often in linux, so a dynamic link against kdelibs4 should have more benefits
than use this stand-alone plugin derived from kdelibs


You can find the original version of this plugin in the kdelibs4 sources
(subdir kimgio)



-----------------------------------------------------
Credits:

1) Pcx Plugin into Kde Libs 4 original Copyright: 

   Copyright (C) 2002-2005 Nadeem Hasan <nhasan@kde.org>



2) (very little) Modifications to make Pcx Plugin a stand-alone plugin Copyright:
   
   Copyright (C) 2010 Nobun

-----------------------------------------------------


Terms of License for libpcx

libpcx is a derivative work that uses the code contained in kdelibs, so it is released under
the same terms of license (LGPL version 2)


This program is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License (LGPL) as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later version.