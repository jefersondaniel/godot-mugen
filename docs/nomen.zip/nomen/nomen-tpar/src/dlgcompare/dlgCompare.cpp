/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#include <QtGui>
#include <QApplication>
//#include <QtCore/QTranslator>
//#include "frmMain.h"
#include "../minsff/SffItem.h"
#include "../minsff/SffHandler.h"
#include "../minsff/Sff.h"
#include "dlgCompare.h"



DlgCompare::~DlgCompare() {
  SffItem_scene1->setNull();
  SffItem_scene2->setNull();
  delete scene1; delete scene2;
}



DlgCompare::DlgCompare(QWidget * parent, Sff * _sff1, Sff * _sff2, Sff * _sff3, QProgressBar * _pbar, Sff * _sff4, Sff * _sff5) : QDialog(parent)
{
    ui.setupUi(this);
    allowclose = false;_parent_= parent;
    SffItem_scene1 = new SffItem;
    SffItem_scene2 = new SffItem;
    ui.pbar->setValue(_pbar->value());
   
    {
	    int val = _sff4->sffdata.size();
	    if(val > 0) { //should always be true
	      ui.imgscroll->setRange(1, _sff4->sffdata.size() );
	      {
		    QString str = QString("1 / %1") .arg( _sff4->sffdata.size() );
	        ui.le_scroll->setText(str);
	        SffItem_scene1->setVal( _sff4->item(0) ); 
            SffItem_scene2->setVal( _sff5->item(0) ); 
            
            str = QString("(Analizing Group: %1)") .arg( _sff4->sffdata[0].groupno );
            if( _sff4->sffdata[0].groupno == 9000 ) {
	          str = QString("(Analizing Spriteno: %1, %2)") .arg( _sff4->sffdata[0].groupno ) .arg( _sff4->sffdata[0].imageno);
            }	                        
            ui.le_grp->setText(str);
          }
          ui.imgscroll->setValue(1);
        }
        if(val == 0) { //should never be true
	      ui.imgscroll->setRange(0,0);
	      ui.le_scroll->setText("0 / 0");
          ui.imgscroll->setValue(0);
          ui.rb_left->setEnabled(false);
          ui.rb_right->setEnabled(false);
          ui.rb_both->setEnabled(false);
          ui.le_grp->setText("(Error)");
        }
    }
  
    zoomfactor = 0;
    orgsff1 = _sff1;
    orgsff2 = _sff2;
    sff = _sff3;
    cutted_sff1 = _sff4;
    cutted_sff2 = _sff5;
    
	scene1 = new QGraphicsScene;    
    scene1->setSceneRect(0,0,300,200);
    scene2 = new QGraphicsScene;    
    scene2->setSceneRect(0,0,300,200);
    
    ui.graph1->setScene(scene1);
    ui.graph2->setScene(scene2);
    
    scene1->setBackgroundBrush(QBrush(Qt::black));
    scene1->addItem(SffItem_scene1);
    scene2->setBackgroundBrush(QBrush(Qt::black));
    scene2->addItem(SffItem_scene2);
    
    
    connect(ui.btnZoomIn, SIGNAL( clicked() ), this, SLOT( slotZoomIn() ) );
    connect(ui.btnZoom1, SIGNAL( clicked() ), this, SLOT( slotZoom1() ) );
    connect(ui.btnZoomOut, SIGNAL( clicked() ), this, SLOT( slotZoomOut() ) );
    connect(ui.bgsList, SIGNAL( currentIndexChanged (int) ), this, SLOT( slotBg(int) ) ); 
    connect(ui.imgscroll, SIGNAL( valueChanged(int) ), this, SLOT( slotScrollImage(int) ) );
    
    connect(ui.rb_left, SIGNAL( clicked() ), this, SLOT( slot1() ) );
    connect(ui.rb_right, SIGNAL( clicked() ), this, SLOT( slot2() ) );
    connect(ui.rb_both, SIGNAL( clicked() ), this, SLOT( slot1() ) );
    connect(ui.rb_none, SIGNAL( clicked() ), this, SLOT( slot4() ) );
}



void DlgCompare::closeEvent(QCloseEvent * event) {
  if(allowclose == true) event->accept(); //window will be closed using "Next"
  if(allowclose == false) event->ignore(); //forbids you to close the window using "x"
}

 

void DlgCompare::slotZoomIn() {
  ui.btnZoomOut->setEnabled(true);
  zoomfactor ++;
  if(zoomfactor >= 4) ui.btnZoomIn->setEnabled(false);
  ui.graph1->scale(2, 2);
  ui.graph2->scale(2, 2);
}



void DlgCompare::slotZoom1() {
  ui.btnZoomIn->setEnabled(true);
  ui.btnZoomOut->setEnabled(true);
  while(zoomfactor < 0) {
    zoomfactor++;
    ui.graph1->scale(2, 2);
    ui.graph2->scale(2, 2);
  }
  while(zoomfactor > 0) {
	zoomfactor--;
	ui.graph1->scale(0.5, 0.5);
	ui.graph2->scale(0.5, 0.5);
  }
}



void DlgCompare::slotZoomOut() {
  ui.btnZoomIn->setEnabled(true);
  zoomfactor --;
  if(zoomfactor <= -2) ui.btnZoomOut->setEnabled(false);
  ui.graph1->scale(0.5, 0.5);
  ui.graph2->scale(0.5, 0.5);
}



void DlgCompare::slotBg(int value) {
  switch(value) {
    case 0: scene1->setBackgroundBrush(QBrush(Qt::black)); scene2->setBackgroundBrush(QBrush(Qt::black)); break;
    case 1: scene1->setBackgroundBrush(QBrush(Qt::white)); scene2->setBackgroundBrush(QBrush(Qt::white)); break;
    case 2: scene1->setBackgroundBrush(QBrush(Qt::magenta)); scene2->setBackgroundBrush(QBrush(Qt::magenta)); break;
    case 3: scene1->setBackgroundBrush(QBrush(Qt::cyan)); scene2->setBackgroundBrush(QBrush(Qt::cyan)); break;
    case 4: scene1->setBackgroundBrush(QBrush(Qt::darkCyan)); scene2->setBackgroundBrush(QBrush(Qt::darkCyan)); break;
    case 5: scene1->setBackgroundBrush(QBrush(Qt::darkYellow)); scene2->setBackgroundBrush(QBrush(Qt::darkYellow)); break;
    default: scene1->setBackgroundBrush(QBrush(Qt::black)); scene2->setBackgroundBrush(QBrush(Qt::black));
  }	
}



void DlgCompare::slotScrollImage(int value) {
  if(value > 0) { //don't execute if no images: (value == 0 means empty sff)
    SffItem_scene1->setVal( cutted_sff1->item(value-1) ); 
    SffItem_scene2->setVal( cutted_sff2->item(value-1) ); 
  }
  
  if(value == 0) { //if value==0 (emtpy sff -> no frames) than set all values to 0
    SffItem_scene1->setNull();
    SffItem_scene2->setNull();
  }
  
  //set ui.le_scroll
  { 
	QString str = QString("%1 / %2") .arg(value) .arg( cutted_sff1->sffdata.size() );
	ui.le_scroll->setText(str);
  }
}



void DlgCompare::slot1() {
    for(int a = 0; a < cutted_sff1->sffdata.size(); a++) {
	  sff->sffdata.append(cutted_sff1->sffdata[a]);
    }  
 
  allowclose = true;
  this->accept();
}



void DlgCompare::slot2() {
    for(int a = 0; a < cutted_sff2->sffdata.size(); a++) {
	  sff->sffdata.append(cutted_sff2->sffdata[a]);
    }  
  
  allowclose = true;
  this->accept();
}



void DlgCompare::slot4() {
    allowclose = true;
    QMessageBox::critical(this,"PROGRAM WILL STOP!",
                QString("It is useless to continue: it is absolutely impossible to fix this sff!") );	  
    QApplication::quit();
}

