/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *  MODIFYED VERSION FOR PERFECT_SFFv1
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#include "../SffHandler.h"
#include "../SffItem.h"
#include "SffV1.h"
//Qt included: QString, QList, QGraphicsPixmapItem

#include <QTextStream>

#include <QByteArray>
#include <QDataStream>
#include <QFile>
#include <QImage>
#include <QPixmap>
#include <QBuffer>
#include <QString>
#include <QProgressDialog>
#include <QPushButton>
#include <QMessageBox>
#include "../nomenSffFunctions.h"
#include "internal_sffv1_structs.h"
#include "internal_sffv1_functions.h"

#include <string>



int _sffv1_search_palindex(QList<SffPal> &list,  QVector <QRgb> & pal) {
  int value = 0;
  for(int a = 0; a < list.count(); a++) {
    if(nomenComparePalettes(list[a].pal, pal) == true) { value = a; break; }
  }
  return value;
}


void _trick(SffPal * data1, SffPal * data2) {
  data1->groupno = data2->groupno;
  data1->itemno = data2->itemno;
  data2->groupno = 1;
  data2->itemno = 1;
}



/****************************
 *
 *  READING...
 *
 ***************************/


bool SffV1::read(QString & filename, QVector<QRgb> & pal, const char metodo) { //this SffV1 loading routing is completely different from Nomen one
  _SFFV1_SFF_HEADER head;
  _SFFV1_SFF_SPRITE_HEADER spr;
  
  QList <_SFFV1_TRICKYSFF_SPR> sprites;
  
  //routine TOTALLY DIFFERENT FROM NOMEN (needs a complete different approach)
  
  int bless = -1; //tiene traccia dell' indice della immagine che contiene la palette 1,1    
  
  { //part1: load paldata
    QFile sffFile(filename);
    int have00 = -1; //>=0 if individual 0,0 found (false if not found or not individual)
    int have90 = -1; //>=0 if individual 9000,0 found (false if not found or not individual)
    int have0 = -1; //>=0 if individual 0,x found (false if not found or not individual)
    
    if(!sffFile.open(QIODevice::ReadOnly)) return false;
    QDataStream in(&sffFile);
    in.setByteOrder(QDataStream::LittleEndian);
    in>>head;
    if(strcmp(&head.signature[0], "ElecbyteSpr")!=0) return false;
    if(head.verhi!=0 && head.verlo!=1 && head.verlo2!=0 && head.verlo3!=1) return false;
  
    long actual_offset = head.first_offset;
    //bool first_sprite = true;
    int counter = -1;
      
    while(!in.atEnd()) {	  
	  //this routine in rewritten by 0: Nomen One was not good for the purpose of this too
	  in>>spr; long arraySize = spr.offsetNextSprite - actual_offset - 32;
	  
	  { 
		_SFFV1_TRICKYSFF_SPR __spr__;
		__spr__.groupno = (int) spr.groupno;
		__spr__.imageno = (int) spr.imageno;
		__spr__.linked = (int) spr.linked;
		__spr__.x = (int) spr.x;
		__spr__.y = (int) spr.y;
		__spr__.isShared = spr.isShared;
		__spr__.data = QByteArray();
		sprites.append(__spr__);
      }
      
	  counter ++;
	  
	  if(spr.groupno == 0 && spr.imageno == 0 && spr.isShared == false)  { have00 = counter; bless = counter; }
	  else if(spr.groupno == 0 && spr.isShared == false && have00 < 0) { have0 = counter; bless = counter; }
	  else if(spr.groupno == 9000 && spr.imageno == 0 && spr.isShared == false && have00 < 0 && have0 < 0) { have90 = counter; bless = counter; }
	  
      if(arraySize > 0) { //normal image
        char * tmpStr = new char[arraySize];
        QByteArray tmpArr;
	    in.readRawData(tmpStr, ((int) arraySize) );
	    tmpArr.append(tmpStr, ((int) arraySize) );
	    
	    {
		  int k = sprites.count() -1;
		  sprites[k].data = tmpArr;    
	    }
	    
	    if(spr.isShared == false) {
	      QByteArray palref = tmpArr.right(768);
	      SffPal tmppal;
	      tmppal.pal = _sffv1_matrixToPal(palref);
	      tmppal.groupno = paldata.size() +1;
	      tmppal.itemno = 1;
	      tmppal.isUsed = true;
	      tmppal.usedby = counter;
	      bool b = true;
	      	      
	      for(int a = 0; a < paldata.count(); a++) { 
	        if(nomenComparePalettes(tmppal.pal, paldata[a].pal) == true) {
		      b = false; a = paldata.count();    
	        } //end if
          } //end for (controllo che non ci sia gi� la palette in lista
          
          if(b == true) { //palette non inserita
            paldata.append(tmppal);
          }     
        } //end isShared = false 
      } //end arraySize > 0  
      actual_offset = spr.offsetNextSprite;
    } //!in.atEnd
  } //end block PALDATA
  
  //now we have the paldata templist;
  
  {
	//recuperiamo l'indice della palette che dovrebbe essere la 1,1 e la si scambia con la palette[0] se diversa
    int index1 = 0;
    
    //A: take index1: if bless is positive (0 or plus) search the "sprites[bless] palette" in paldata
    //                if bless is -1 search the "extern loaded Mugen act (variable "pal") in paldata or add it if not present
    //A1 - search "sprites[bless] palette"
    if(bless > -1) {
	  QByteArray palref = sprites[bless].data.right(768);
	  QVector <QRgb> _pal1 = _sffv1_matrixToPal(palref);
	  for(index1 = 0; index1 < paldata.count(); index1++) { 
	      if(nomenComparePalettes(_pal1, paldata[index1].pal) == true) {
		     break;    
	       } //end if
      } //end for (controllo che non ci sia gi� la palette in lista      
    }
    //A2 - search "sprites[bless] palette"
    else {
	  bool k = false;
	  //case 1: find "pal" (loaded from MUGEN act) into paldata and return index1 if present
	  for(index1 = 0; index1 < paldata.count(); index1++) { 
	      if(nomenComparePalettes(pal, paldata[index1].pal) == true) {
		     k = true; break;    
	       } //end if
      }
      //case 2: if "pal" (loaded from MUGEN act) is NOT into paldata create a new paldata ITEM and return the index of this new element
      if(k == false) {
	      //update index1 to the last paldata element you are adding
	      index1 = paldata.size();
	      //add "pal" as a paldata element
	      SffPal tmppal;
	      tmppal.pal = pal;
	      tmppal.groupno = paldata.size() +1;
	      tmppal.itemno = 1;
	      tmppal.isUsed = true;
	      tmppal.usedby = -1;
	      paldata.append(tmppal);
      } 
    }
	
	  //B: if index1 (obtained in the "A" step) is not 0 but is > 0, than switch palettes
      if(index1 >= 0) {
	    _trick(&paldata[0], &paldata[index1]);  
	    paldata.swap(0, index1);    
      }      
    //} //end index1 > =0
  } //end block
  
  if(metodo == 1 || metodo == 2) { //mainly for 2nd method
	int palindex = 0;
    for(int a = 0; a < sprites.count(); a++) {
	    
	  if(sprites[a].data.size() > 0) { //real image
	    if(sprites[a].isShared == false) { //individual image
	      QByteArray palref = sprites[a].data.right(768);
          QVector <QRgb> pal;
          pal = _sffv1_matrixToPal(palref);
          palindex = _sffv1_search_palindex(paldata, pal);	    
        }//individual end
        
        //the rest is common to both shared image and individual image
        
        SffData tmpdata;
        tmpdata.groupno = sprites[a].groupno;
        tmpdata.imageno = sprites[a].imageno;
        tmpdata.linked = -1;
        tmpdata.x = sprites[a].x;
        tmpdata.y = sprites[a].y;
        tmpdata.palindex = palindex;
        
        {
          QBuffer buffer(&sprites[a].data);
          buffer.open(QIODevice::ReadOnly);
          tmpdata.image.load(&buffer, "pcx"); // read image from tmpArr in pcx format
        }
        
        tmpdata.image.setColorTable(paldata[palindex].pal);        
        sffdata.append(tmpdata);        
      }//end real image
      
      if(sprites[a].data.size() == 0) { //linked image
        sffdata.append(sffdata[sprites[a].linked]);
        sffdata[a].groupno = sprites[a].groupno;
        sffdata[a].imageno = sprites[a].imageno;
        sffdata[a].linked = -1;
        sffdata[a].x = sprites[a].x;
        sffdata[a].y = sprites[a].y;
      } //end linked image
      
    } //end for a
  }//end metodo 2
  
  if(metodo == 1) {
    for(int a = 0; a < sffdata.size(); a++) {
	  if(sprites[a].isShared == true) {
	    sffdata[a].palindex = 0;
	    sffdata[a].image.setColorTable(paldata[0].pal);	  
      }    
    }
  }
  
  return true; //warning: *.usedby values will be wrong (they will be updated at the end of frmMain.step2()
}//END READ	  
	  
	
	  
	  
	  
