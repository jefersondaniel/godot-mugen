/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/
 
// SFFv1 INTERNAL ONLY. DON'T USE THIS HEADER OUTSIDE sffv2

//matrix-pal.  Convert a QByteArray "raw" to a QVector <QRgb>. 

QVector <QRgb> _sffv1_matrixToPal (QByteArray &src) {
  QVector <QRgb> palette;
  QDataStream in(src);
  quint8 r, g, b;
  for(int a = 0; a < 256; a++) {
    in>>r; in>>g; in>>b;
    palette.append( qRgb(r,g,b) );
  }
  return palette;
}


void _sffv1_updateProgress(QProgressDialog * progress, int & actualItem, const int totalItems) {
  actualItem++;
  progress->setValue( (((actualItem) * 100) / totalItems) );	
}


void _sffv1_searchDuplicates(const QList<SffPal> &paldata, QList<SffData> & group0, QList<_SFFV1_NOMEN_STRUCT> * orglist) 
{		           
  //we will not verify nor big portrait nor short portrait. They should not match any images.
  //If happens, however, they will be an exception of removeDuplicate in sffv1 under Nomen
  
  QList<_SFFV1_NOMEN_STRUCT> list = * orglist;
    
  QList <SffData> imgbase;
    for(int a = 0; a<list.size(); a++) { //find pal 1,1 images in list, and move them from list to sim
      if(paldata[list[a].palindex].groupno == 1 && paldata[list[a].palindex].itemno == 1) {
	    imgbase = list[a].sffdata; list.removeAt(a);
      }
    }
  
  //now we verify group0 against all other images
  int base_link = 0;
  for(int a = 0; a < group0.size(); a++) {
     for(int b = a+1; b < group0.size(); b++) { //group0 against group0 (only to be complete)
	   if(group0[a].image == group0[b].image && group0[a].linked == -1) group0[b].linked = a;    
     }
     for(int b = 0; b < imgbase.size(); b++) { //group0 against imgbase
	   if(group0[a].image == imgbase[b].image && group0[a].linked == -1) imgbase[b].linked = a;
     }
     for(int b = 0; b < list.size(); b++) { //group0 against multi-list
	   QList <SffData> dat = list[b].sffdata;
	   for(int c = 0; c < dat.size(); c++) {
	     if(group0[a].image == dat[c].image && group0[a].linked == -1) dat[c].linked = a;	   
       }    
     }   
  }
  
  //now we verify imgbase against all other images
  base_link += group0.size();
  for(int a = 0; a < imgbase.size(); a++) {
     for(int b = a+1; b < imgbase.size(); b++) { //imgbase against imgbase
	   if(imgbase[a].image == imgbase[b].image && imgbase[a].linked == -1) imgbase[b].linked = a + base_link;
     }
     for(int b = 0; b < list.size(); b++) { //imgbase against multi-list
	   QList <SffData> dat = list[b].sffdata;
	   for(int c = 0; c < dat.size(); c++) {
	     if(imgbase[a].image == dat[c].image && imgbase[a].linked == -1) dat[c].linked = a + base_link;
       }    
     }   
  }
  
  //now we verify multi-list against multi-list
  base_link += imgbase.size();
  for(int a = 0; a < list.size(); a++) { //for every LIST
    if(a > 0) base_link += list[a-1].sffdata.size();
    QList <SffData> dat1 = list[a].sffdata;
    for(int b = 0; b < dat1.size(); b++) { //inside actual list
      for(int c = b+1; c < dat1.size(); c++) { //actual list against actual list
	     if(dat1[b].image == dat1[c].image && dat1[b].linked == -1) dat1[c].linked = b + base_link;
      }
      for(int c = a+1; c < list.size(); c++) { //inside other lists
	      QList <SffData> dat2 = list[c].sffdata;
	      for(int d = 0; d < dat2.size(); d++) { //comparison against elements single list
		    if(dat1[b].image == dat2[d].image && dat1[b].linked == -1) dat2[d].linked = d + base_link;
	      } 
      }	  
    }	  
  }
}




void _sffv1_writeImage(QDataStream & out, SffData & data, long & offset, bool markImageAsShared) {
  _SFFV1_SFF_SPRITE_HEADER spr;
  //"offset" marks actual offset (before adding the image)
  spr.x = data.x;
  spr.y = data.y;
  spr.groupno = data.groupno;
  spr.imageno = data.imageno;
  if(data.linked > -1) spr.linked = data.linked;
  else spr.linked = 0;
  spr.isShared = markImageAsShared;
  for(int a = 0; a < 13; a++) spr.blank[a] = 0;
  //missing next offset and subfile len
  
  if(data.linked > -1) { //linked image
    spr.offsetNextSprite = offset + 32;
    spr.subfileLen = 0;
    out << spr;
  }
  else { //normal image
    QByteArray img; img.clear();
    {
	  QImage tmpImage = data.image;
	  {
		//if 32 bit refill pal to 256 colors
	    QVector<QRgb> pal = tmpImage.colorTable();
	    pal = nomenPalFiller(pal);
	    tmpImage.setColorTable(pal);
      }
	  
      QBuffer imgbuf(&img);
      imgbuf.open(QIODevice::WriteOnly);
      tmpImage.save(&imgbuf, "pcx");
    }
    if(spr.isShared == true) img.resize( img.size() - 768 );
    //now "img" contains image converted in pcx data (decurted by pal if necessary)
    spr.offsetNextSprite = offset + 32 + img.size();
    spr.subfileLen = img.size();
    out << spr; out.writeRawData(img.data(), img.size());
  }
  
  offset = spr.offsetNextSprite; //update offset
}

