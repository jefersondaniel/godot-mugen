/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/
 
// SFFv1 INTERNAL ONLY. DON'T USE THIS HEADER OUTSIDE sffv1


struct _SFFV1_TRICKYSFF_SPR { //used in "tricky_sff" for loading SPR in memory
  QByteArray data;
  int groupno;
  int imageno;
  int x;
  int y;
  bool isShared;
  int linked;
};


struct _SFFV1_NOMEN_STRUCT {
  //this struct is used only internally by Nomen, during writing, to reoder image in the right 
  //order for a good-working sffv1 file
  int palindex;
  QList<SffData> sffdata;	
};


struct _SFFV1_SFF_HEADER {
  char signature[12];
  quint8 verhi; //0
  quint8 verlo; //1
  quint8 verlo2; //0
  quint8 verlo3; //1
  long numGroups;
  long numImages;
  long first_offset;
  long subheader_size; //=32
  bool isShared;
  char reserved[3];
  char comments[476];
};


struct _SFFV1_SFF_SPRITE_HEADER {
  long offsetNextSprite;
  long subfileLen;
  short x;
  short y;
  short groupno;
  short imageno;
  short linked;
  bool isShared;
  char blank[13];
};




QDataStream &operator>>( QDataStream &ds, _SFFV1_SFF_HEADER &header )
{
  ds.readRawData((char *) &header.signature, 12);
  ds>>header.verhi; ds>>header.verlo; ds>>header.verlo2; ds>>header.verlo3;
  ds.readRawData((char *) &header.numGroups, 4);
  ds.readRawData((char *) &header.numImages, 4);
  ds.readRawData((char *) &header.first_offset, 4);
  ds.readRawData((char *) &header.subheader_size, 4);
  {
    quint8 tmp; ds>>tmp;
    if(tmp==0) header.isShared=false;
    if(tmp==1) header.isShared=true;	  
  }
  ds.readRawData((char *) &header.reserved, 3);
  ds.readRawData((char *) &header.comments, 476);
  return ds;
}


QDataStream &operator<<( QDataStream &ds, const _SFFV1_SFF_HEADER &header )
{
  ds.writeRawData((char *) &header.signature, 12);
  ds<<header.verhi; ds<<header.verlo; ds<<header.verlo2; ds<<header.verlo3;
  ds.writeRawData((char *) &header.numGroups, 4);
  ds.writeRawData((char *) &header.numImages, 4);
  ds.writeRawData((char *) &header.first_offset, 4);
  ds.writeRawData((char *) &header.subheader_size, 4);
  {
	quint8 tmp = 0;
    if(header.isShared==true) tmp = 1;
    ds<<tmp;	  
  }
  ds.writeRawData((char *) &header.reserved, 3);
  ds.writeRawData((char *) &header.comments, 476);
  return ds;
}


QDataStream &operator>>( QDataStream &ds, _SFFV1_SFF_SPRITE_HEADER &spr )
{
  ds.readRawData((char *) &spr.offsetNextSprite, 4);
  ds.readRawData((char *) &spr.subfileLen, 4);
  ds.readRawData((char *) &spr.x, 2);
  ds.readRawData((char *) &spr.y, 2);
  ds.readRawData((char *) &spr.groupno, 2);
  ds.readRawData((char *) &spr.imageno, 2);
  ds.readRawData((char *) &spr.linked, 2);
  { 
	quint8 tmp; ds>>tmp;
    if(tmp==0) spr.isShared=false;
	if(tmp==1) spr.isShared=true;
  }
  ds.readRawData((char *) &spr.blank, 13);
  return ds;
}


QDataStream &operator<<( QDataStream &ds, const _SFFV1_SFF_SPRITE_HEADER &spr )
{
  ds.writeRawData((char *) &spr.offsetNextSprite, 4);
  ds.writeRawData((char *) &spr.subfileLen, 4);
  ds.writeRawData((char *) &spr.x, 2);
  ds.writeRawData((char *) &spr.y, 2);
  ds.writeRawData((char *) &spr.groupno, 2);
  ds.writeRawData((char *) &spr.imageno, 2);
  ds.writeRawData((char *) &spr.linked, 2);
  { 
	quint8 tmp = 0;
	if(spr.isShared==true) tmp = 1;
	ds<<tmp;
  }
  ds.writeRawData((char *) &spr.blank, 13);
  return ds;
}

