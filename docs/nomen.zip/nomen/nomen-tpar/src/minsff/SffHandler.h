/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *  MODIFYED VERSION FOR PERFECT_SFFv1
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#ifndef SFF_HANDLER_H
#define SFF_HANDLER_H

#include "SffItem.h"
#include <QList>
#include <QString>

class SffHandler { //this is a little different from Nomen SffHandler: 1) Not a pure-virtual class (read and write not present here) 2) some other issues (useless here) not present
  public:
    SffHandler();
    //! sprite list to load with PLUGIN or to save from SFF
    QList<SffData> sffdata;
    //! pal list to load with PLUGIN or to save from SFF
    QList<SffPal> paldata;
    //! used by PLUGIN::write to mark if linking images or not during Sff saving process
    bool removeDuplicates;
    
  public:
    //! returns how many different groupno used in sff (useful only for sffv1 at the moment)
    const int sffGroupCount();
    QList<int> usedPalGroups();
    //! Checks for duplicate images. Actually used only by sffv2 (sffv1 has a different internal function for the same work)
    void searchDuplicateImages();
    //! Check Sff for errors (for example if two or more images with same groupno, imageno)
    /*!
       @param rgbSupported set to true only if your Sff format supports Rbg Images. If your Sff format doesn't support Rgb Images set it to false.
       \return a QString value corresponding to error message. Empty if no errors.
    */
    QString scanSff(bool rgbSupported);
};


#endif

