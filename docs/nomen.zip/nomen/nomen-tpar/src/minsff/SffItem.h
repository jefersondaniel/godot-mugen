/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#ifndef SFF_ITEM_H
#define SFF_ITEM_H

//this module contains the definition for SffPal, SffData and SffItem
//SffPal is a struct that contains the infos for a single palette (palette, groupno, imageno)
//SffData is a sctruct that contains the infos for a single image (image, x, y, ...)
//SffItem is a subbclass of QGraphicsPixmapItem that allow to edit a SffData element 
//           throughout the scene and the spinboxes contained in the SffWidget
 
#include <QGraphicsPixmapItem>
#include <QVector>
#include <QRgb>

//! Structure that contains the info for a single palette
struct SffPal {
  //! palette data
  QVector <QRgb> pal;
  //! pal itemno
  int itemno;
  //! pal groupno
  int groupno;
  //! indicates if the palette is used at least by a sprite
  bool isUsed;
  //! indicates what image use this pal (-1 if unused)
  int usedby; //ID of first SffData item that uses that image
  //! A special parameter for Nomen internal usage only. When unused it is always == -1
  int reserved; //"reserved" is used internally only. It is a parameter for working under Palette Section
  SffPal() {
    itemno = -1; groupno = -1;
    isUsed = false;
    usedby = -1; reserved = -1;
  }
  // bool isTrueColor; //for true colors image
};

//! Structure that contains the info for a single sprite
struct SffData {
  //! Image Drawing
  QImage image;
  //! image groupno
  int groupno;
  //! image imageno
  int imageno;
  //! image offset x
  int x;
  //! image offset y
  int y;
  //! The index value of palette used by sprite
  int palindex;
  /*!
     This parameter is used in a particular way. Inside Sff is always == -1.
     When SffHandler receives the sffdata(s) all "linked" values will be == -1.
     If removeDuplicates is enabled you need to use palindex as an extra parameter that contains the sprite linked to (if matches any) else it will remain -1
  */
  int linked;
};


//! A Derived Class of QGraphicsPixmapItem used to show a sprite in Scene
class SffItem : public QGraphicsPixmapItem
{ 
	
protected:
  //void mouseReleaseEvent( QGraphicsSceneMouseEvent * event); //useless here!
	
public:
  SffItem();
  
public: 
  //! Pointer used internally to comunicate througout the single sprite you are watching in scene
  SffData * sffdata;
  int groupno; int imageno; //short (2 bytes)
  
  //! Set sffdata to point with GraphicItem
  void setVal(SffData * _sffdata);
  //! Set NULL sffdata to point with GraphicItem
  void setNull();
};


#endif

