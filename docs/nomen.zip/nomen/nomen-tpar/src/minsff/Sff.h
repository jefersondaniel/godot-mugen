/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#ifndef SFF__H
#define SFF__H

#include <QList>
#include <QString>
#include "SffItem.h"
 
/*
class Sff loads and save sff files throughout "sff plugins"
Sff stores data in "data". 

Data can be used in this way:
you can obtain the pointer of a single SffItem inside "data" using function "searchItem"
*/ 

//! This is the class that manages Sff data (palettes and images)
class Sff { 
    
public: //constructors - destructors
  Sff();
  ~Sff();
	
public: //datas 
  //! paldata is a list that contains pal infos
  QList<SffPal> paldata;
  //! sffdata is a list that contains sprite infos
  QList<SffData> sffdata;
  //! this bool marks if "sff" is saved or not. It is public so be careful
  QString filename;
  //! An int value that returns the ID of actual Image (usefull for "Extract Actual Image"
  
public: //relevant return values
  //! It will return a pointer of a single sprite data (useful for SffItem)
  SffData * item(int itemID); //groupno, imageno
  //! It will return an int value corresponding to the ID of the first image with that groupno, imageno (if no errors, there should be only one image with that infos)
  int searchItem(int groupno, int imageno); //itemID
  //! It will return an int value corresponding to the ID of the first image with that groupno
  int searchItem(int groupno); //itemID
  //! It will return a list of PAL.groupno used in paldata. Useful for Palette Section
  QList<int> usedPalGroups(); //list of groups used in palette
  QList<int> usedSprGroups(); //list of groups used in sprites
  QList<int> searchItems(int groupno); //list of itemID with "groupno"
  
public: 
  //! clear all Sff internal datas
  void clear();
  
//public: 

  //bool saveSff(QString & _filename, char sff_type = 1);
  
};

#endif

