/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#include "../SffHandler.h"
#include "../SffItem.h"
#include "NomSpr.h"
//Qt included: QString, QList, QGraphicsPixmapItem

#include <QTextStream>

#include <QDataStream>
#include <QFile>
#include <QImage>
#include <QMessageBox>

#include "../nomenSffFunctions.h"


QDataStream &operator>>( QDataStream &ds, SffData &sffdata )
{
  ds>>sffdata.image;
  ds>>sffdata.groupno;
  ds>>sffdata.imageno;
  ds>>sffdata.x;
  ds>>sffdata.y;
  ds>>sffdata.palindex;
  ds>>sffdata.linked;
  sffdata.linked = -1;
  return ds;
}


QDataStream &operator<<( QDataStream &ds, const SffData &sffdata )
{
  ds<<sffdata.image;
  ds<<sffdata.groupno;
  ds<<sffdata.imageno;
  ds<<sffdata.x;
  ds<<sffdata.y;
  ds<<sffdata.palindex;
  ds<<sffdata.linked;
  return ds;
}
  

QDataStream &operator>>( QDataStream &ds, SffPal &paldata )
{
  ds>>paldata.pal;
  ds>>paldata.itemno;
  ds>>paldata.groupno;
  ds>>paldata.isUsed;
  ds>>paldata.usedby; 
  ds>>paldata.reserved; 
  paldata.reserved = -1; //"reserved" is used internally only. It is a parameter for working under Palette Sectionreturn ds;
  return ds;
}


QDataStream &operator<<( QDataStream &ds, const SffPal &paldata )
{
  ds<<paldata.pal;
  ds<<paldata.itemno;
  ds<<paldata.groupno;
  ds<<paldata.isUsed;
  ds<<paldata.usedby; 
  ds<<paldata.reserved; 
  return ds;
}
 

/******************************************
 * 
 *  Read and Write Functions
 *
 ******************************************/

	
bool NomSpr::read(QString & filename) {
  QFile sffFile(filename);
  if(!sffFile.open(QIODevice::ReadOnly)) return false;
  QDataStream in(&sffFile);
  
  QString signature;
  in>>signature;
  if(signature != "NomenSprFormatByNobun") return false;
  
  in>>sffdata;
  in>>paldata;
  
  sffFile.close();
  return true;
}


bool NomSpr::write(QString & filename) {
  QFile sffFile(filename);
    if(!sffFile.open(QIODevice::WriteOnly)) {
	   QMessageBox::warning((QWidget *) 0, QMessageBox::tr("Error!"), 
	      QMessageBox::tr("Unable to Write File. Perhaps you are trying to write in a read-only folder?") );
	   return false;
    }
    QDataStream out(&sffFile);
    
  QString signature = "NomenSprFormatByNobun";
  out << signature;
  
  out<<sffdata;
  out<<paldata;
  
  sffFile.close();  
  return true;
}

