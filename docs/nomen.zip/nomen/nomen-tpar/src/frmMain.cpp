/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 * Sub-tool: perfect-sffv1 (an invasive character checker for dramatic sffv1 files)
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#include <QtGui> 
//#include <QtCore/QTranslator>
#include "minsff/Sff.h"
#include "frmMain.h"
#include "gvars.h"
#include "minsff/SffV1/SffV1.h"
#include "minsff/NomSpr/NomSpr.h"
#include "minsff/nomenSffFunctions.h"
#include "dlgcompare/dlgCompare.h"

 
frmMain::frmMain()
{
    ui.setupUi(this); pal.clear();
    connect(ui.action_About, SIGNAL( triggered() ), this, SLOT( About() ) );
    connect(ui.btn1, SIGNAL( clicked() ), this, SLOT( step1() ) );
    connect(ui.btn1bis, SIGNAL( clicked() ), this, SLOT( step1bis() ) );
    connect(ui.btn2, SIGNAL( clicked() ), this, SLOT( step2() ) );
    connect(ui.btn3, SIGNAL( clicked() ), this, SLOT( step3() ) );
}


void frmMain::About() {
  QMessageBox::about(this,"About Tricky Sffv1 Parser",
                QString("Tricky Sffv1 Parser - An advanced (and tricky) tool to hardly open dramatic sffv1 files\n"
                "Version  1.0\n\n"
                "Note: this tool is an external component of N.O.M.E.N. and you need to use it in association with N.O.M.E.N. itself\n"
                "      DON'T USE this tool unless you strictly need it and read carefully \"Tricky_Sffv1_Parser Readme\" before using it\n\n"
                "------------------------\n\n"
                "Copyright (C) Nobun  2010-2011\n\n"
                "http://mugenrebirth.forumfree.it\n\n"
                "http://nomeneditor.sourceforge.net\n\n\n"
                "A VERY SPECIAL THANK to serio for his very professional beta-testing and for his ideas that perhaps will be applied in a future\n\n"
                "A VERY SPECIAL THANK to Tunglashor for helping me a lot to understand better Sffv2 and contributing with observations when I reported my problems during sffv2 decoding process\n\n"
                "A VERY SPECIAL THANK also to www.qt-italia.org for answering my questions about qt\n\n"
                "------------------------\n\n"
                "This program is free software: you can redistribute it and/or modify\n"
                "it under the terms of the GNU General Public License as published by\n"
                "the Free Software Foundation, either version 3 of the License, or\n"
                "(at your option) any later version.\n\n"
                "This program is distributed in the hope that it will be useful,\n"
                "but WITHOUT ANY WARRANTY; without even the implied warranty of\n"
                "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the\n"
                "GNU General Public License for more details.\n\n"
                "You should have received a copy of the GNU General Public License\n"
                "along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.\n" ));
}

void frmMain::step1() {
    QMessageBox::warning(this,"WARNING! READ CAREFULLY!",
                QString("Before proceding with \"Step 2\" Read Carefully the README. The Readme will be now opened here. Procede with Step 2 ONLY if you are REALLY REALLY sure you must and can use this tool" ));
                
    QString Readme_File;
    QString Readme_File_context;
    
    #ifdef Q_WS_WIN
    {
      Readme_File = mainpath;
      Readme_File.append("/Tricky_Sffv1_Parser Readme.txt");
    }
    #endif
    
    #ifdef Q_WS_X11
    {
       Readme_File = "/usr/share/nomen/docs/Tricky_Sffv1_Parser Readme.txt";
    }  
    #endif
    
    QWidget * Readme_Widget = new QWidget();
    QTextEdit * Readme_View = new QTextEdit();
    QHBoxLayout * Readme_Layout = new QHBoxLayout();
    
    {
	  QFile QFile_Readme_File(Readme_File);
	  QFile_Readme_File.open(QIODevice::ReadOnly | QIODevice::Text);
	  QTextStream Stream_Readme_File(&QFile_Readme_File);
	  QString temp;
	  do {
	    temp = Stream_Readme_File.readLine();
	    Readme_File_context.append(temp);
	    Readme_File_context.append("\n");
      } while(!temp.isNull());
      QFile_Readme_File.close();
    }
    
    Readme_View->setPlainText(Readme_File_context);
    Readme_View->setReadOnly(true);
    Readme_Layout->addWidget(Readme_View);
    
    Readme_Widget->resize(600,400);
    Readme_Widget->setLayout(Readme_Layout);
    Readme_Widget->setWindowTitle("Read This CAREFULLY before procede further");
    Readme_Widget->setAttribute(Qt::WA_DeleteOnClose);
    Readme_Widget->show();
    
    ui.btn1->setEnabled(false);
    //ui.btn2->setEnabled(true); //now step 2 is different so:
    ui.btn1bis->setEnabled(true); //btn1bis is an addition between btn1 and btn2 (now btn2 is the real step3)
}


void frmMain::step1bis() {
  //in original concept of this software this step didn't exist. So why you will see 1, 1bis, 2, and 3 in source instead of 1,2,3,4 (I am speaking about steps)
  QString filename;
  filename = QFileDialog::getOpenFileName(this, tr("Open a MUGEN CHAR palette"), QString::null, QString("MUGEN .act Palette File (*.act)"));
  if(filename != "") {
    pal = nomenLoadPal_act(filename);
    if(pal.count() > 0) {
	  ui.btn1bis->setEnabled(false);
	  ui.btn2->setEnabled(true);    
    }
    else pal.clear();
  } //END filename != ""
}


void frmMain::step2() {
  QString filename;  
  filename = QFileDialog::getOpenFileName(this, tr("Open a CHARACTER .sff File"), QString::null, QString("Mugen CHARACTER sffv1 File (*.sff *.sffv1)"));
  if(filename != "") {
     QFile QFile_def_file(filename);
     if(QFile_def_file.open(QIODevice::ReadOnly)) {	  
	   QFile_def_file.close();
	   ui.btn2->setEnabled(false);
	   
	   Sff sff1; Sff sff2;
	   Sff * sffp1; Sff * sffp2;
	   
	   QList <int> grp_list;
	   int total_frames;
	   {
	     SffV1 temp; temp.read(filename, pal, 1);
	     sff1.sffdata = temp.sffdata;
	     sff1.paldata = temp.paldata;
	     sff0.paldata = temp.paldata;
	     grp_list = sff1.usedSprGroups();
	     total_frames = temp.sffdata.size();
       }
       {
	     SffV1 temp; temp.read(filename, pal, 2);
	     sff2.sffdata = temp.sffdata;
	     sff2.paldata = temp.paldata;
       }
       
       if(sff1.sffdata.size() > 0) {
	   	  int frames_done = 0;	       
	      for(int a = 0; a < grp_list.count(); a++) {
		    QList <int> images_in_group = sff1.searchItems(grp_list[a]);
	        frames_done += images_in_group.count();
		    sffp1 = new Sff; sffp2 = new Sff;
	        sffp1->paldata = sff1.paldata;
	        sffp2->paldata = sff2.paldata;
	        for(int b = 0; b < images_in_group.count(); b++) {
		      sffp1->sffdata.append(sff1.sffdata[images_in_group[b]]);
		      sffp2->sffdata.append(sff2.sffdata[images_in_group[b]]);
	        }
	        for(int b = (images_in_group.count() - 1); b >=0; b--) {
		      sff1.sffdata.removeAt(images_in_group[b]); //trying to save memory space
		      sff2.sffdata.removeAt(images_in_group[b]); //trying to save memory space
	        }	        
	        
	        if(grp_list[a] != 9000) {
	          DlgCompare * dlgcmp = new DlgCompare(this, &sff1, &sff2, &sff0, ui.pbar, sffp1, sffp2);
	          dlgcmp->setAttribute(Qt::WA_DeleteOnClose);
	          dlgcmp->exec();
            }
            if(grp_list[a] == 9000) {
	          for(int b = 0; b < images_in_group.count(); b++) {
		        Sff * sffx1 = new Sff;
		        Sff * sffx2 = new Sff;
		        sffx1->paldata = sffp1->paldata;
		        sffx2->paldata = sffp2->paldata;
		        sffx1->sffdata.append(sffp1->sffdata[b]);
		        sffx2->sffdata.append(sffp2->sffdata[b]);
		        DlgCompare * dlgcmp = new DlgCompare(this, &sff1, &sff2, &sff0, ui.pbar, sffx1, sffx2);
		        dlgcmp->setAttribute(Qt::WA_DeleteOnClose);
	            dlgcmp->exec();
	            delete sffx1; delete sffx2;
	          }    
            }
             
	        {
		      int val = frames_done * 100 / total_frames;
		      ui.pbar->setValue(val);
	        }
	        
	        images_in_group.clear();
	        delete sffp1; delete sffp2;
	      } 
	      
	      //recheck and fix paldata.usedby values
             {
                //recheck and fix paldata.usedBy values
                for(int a = 0; a < sff0.paldata.size(); a++) { sff0.paldata[a].usedby = -1; }
                int b = 0;
                for(int a = 0; b < sff0.paldata.size(); a++) {
 	                //THE STRUCTURE OF THIS FOR IS NOT WRONG. The progression is by a (sffdata) but 
 	                //the fields to fill is b (paldata)
 	                int val = sff0.sffdata[a].palindex;
 	                if(sff0.paldata[val].usedby == -1) { sff0.paldata[val].usedby = a;  b++; }
                }     	  	  
             }
             
	      
	      //step2 finished :)
	      QMessageBox::information(this,"INFORMATION",
                QString("Step 3 Ended. Ready for Step4" )); //as explained before... this is step 2 for sources but application display it as step3
       
          ui.btn3->setEnabled(true);
       } //end DATA not empty
       
       if(sff0.sffdata.size() == 0) {
	      QMessageBox::information(this,"WARNING",
                QString("Some Problems occurred during Sff reading. You could not have the permissions to read that file or that file could be not a Mugen Sffv1 file" ));
          ui.btn2->setEnabled(true);
       }
    } //end file is Opened
  } //end filname is selected 
} //end step2


void frmMain::step3() {	
  QString filename = QFileDialog::getSaveFileName(this, tr("Save As..."), QString::null, QString("NOMen reserved SPRite file format (*.nomspr)") );
  if(filename != "") {
    NomSpr nomspr;
    nomspr.paldata = sff0.paldata;
    nomspr.sffdata = sff0.sffdata;
    nomspr.write(filename);
    QMessageBox::information(this,"WORK FINISHED! (Finally!!!!)",
                QString("Saved File: %1\n1n"
                "this application will be closed now!")
                .arg(filename) );
    this->close();                
  } //end filename != ""
}

