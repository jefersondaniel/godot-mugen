/*
 * Nomen - a New Opensource Mugen Editor by Nobun
 *
 * Sub-tool: perfect-sffv1 (an invasive character checker for dramatic sffv1 files)
 *
 *
 *  Copyright (C) 2011  Nobun
 *  http://mugenrebirth.forumfree.it
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program (GPL.txt).  If not, see <http://www.gnu.org/licenses/>.
 *
 ******************************************************/

#ifndef FRMMAIN_H
#define FRMMAIN_H
 
#include "ui_frmMain.h"
#include "minsff/Sff.h"
 
class frmMain : public QMainWindow
{
    Q_OBJECT
    
public:
    Ui::frmMainDLG ui;
    frmMain();
    Sff sff0;
    QVector <QRgb> pal;
    
public slots:
    void About();
    void step1();
    void step1bis();
    void step2();
    void step3();
};
 
 
#endif

